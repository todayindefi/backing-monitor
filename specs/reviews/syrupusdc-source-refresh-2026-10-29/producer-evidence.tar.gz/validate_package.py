from pathlib import Path
import json,math
D=Path(__file__).parent
load=lambda p:json.loads(p.read_text())
a=load(D/'after/syrupusdc_backing.json');before=load(D/'before/syrupusdc_backing.json');b=a['asset_specific']['loan_book'];rows=b['loans']
old={r['loan_addr'].lower():r for r in before['asset_specific']['loan_book']['loans']}
for r in rows:
 for k in ['principal','rate_pct','status','borrower','is_impaired','is_called','is_in_default']:
  assert r[k]==old[r['loan_addr'].lower()][k],(r['loan_addr'],k)
assert b['enumeration_residual']==0
assert math.isclose(b['principal_loans_only_usd']+b['principal_liquidity_usd']+b['principal_unknown_usd'],b['principal_total_usd'],abs_tol=.01)
assert b['credit_coverage']['complete'] is False and b['credit_coverage']['collateral_ratio_pct'] is None
assert len(b['credit_coverage']['member_loan_addresses'])==24
assert len(b['concentration_loans_only']['excluded_loan_addresses'])==9
assert a['peg']['source']=='coingecko' and a['peg']['history_ref']=='syrupusdc_backing_history.json'
latest=load(D/'before/peg_tracker_latest_usd.json')['syrupUSDC']
assert a['asset_specific']['peg']['market_price']==latest['market_price']
assert a['asset_specific']['peg']['theoretical_price']==latest['theoretical_price']
assert all(a['asset_specific']['liquidity'][k]==v for k,v in latest['liquidity'].items())
assert latest['liquidity']['source']=='kyberswap' and latest['liquidity']['chain']=='ethereum' and latest['liquidity']['sell_into']=='USDC'
assert a['asset_specific']['multi_chain']['cross_chain_supply_reconciliation_complete'] is False
assert len(a['asset_specific']['multi_chain']['chains_enumerated'])==9
assert a['asset_specific']['multi_chain']['total_supply_usd_across_chains'] is None
family=load(D/'after/syrup_family.json');assert family['combined']['collateral_ratio_loans_only_pct'] is None
# The only numeric score fields in standard backing are held; age/timestamps may advance.
def scores(x,p=''):
 out={}
 if isinstance(x,dict):
  for k,v in x.items():
   key=p+'.'+k
   if ('score' in k or k=='rating') and 'age' not in k and isinstance(v,(int,float)):out[key]=v
   else:out.update(scores(v,key))
 elif isinstance(x,list):
  for i,v in enumerate(x):out.update(scores(v,p+f'[{i}]'))
 return out
assert scores(a)==scores(before),(scores(a),scores(before))
h0={r['timestamp']:r for r in load(D/'before/syrupusdc_backing_history.json')['entries']}
h1={r['timestamp']:r for r in load(D/'after/syrupusdc_backing_history.json')['entries']}
for timestamp in h0.keys() & h1.keys():
 oldrow=h0[timestamp];newrow=h1[timestamp].copy()
 if newrow.get('classification_version') is None:newrow.pop('classification_version',None)
 assert newrow==oldrow,timestamp
new=[r for t,r in h1.items() if t not in h0]
assert len(new)>=1 and all(r['classification_version']==b['classification_version'] for r in new)
result=dict(status='passed',positions=33,credit_members=24,noncredit_members=9,raw_accounting_unchanged=True,score_values_unchanged=scores(a),canonical_peg_and_ladder_unchanged_from_latest=True,history_overlap_rows_unchanged=len(h0.keys() & h1.keys()),new_history_rows=len(new),old_export_rows=len(h0),new_export_rows=len(h1),oldest_history=min(h1),newest_history=max(h1))
(D/'validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
