"""
Phase 1 Syrup multi-chain supply helpers.

Reads per-chain token totalSupply for CCT deployments and values every chain
with the canonical Ethereum pool NAV.  The payload distinguishes known chains
from successfully enumerated chains so reconciliation completeness is visible.
"""

import os
from typing import Any, Dict, List, Optional

import requests
from web3 import Web3

from special_assets.web3_manager import execute_with_fallback


SOLANA_RPC_URL = os.getenv("SOLANA_RPC_URL", "https://api.mainnet-beta.solana.com")

TOTAL_SUPPLY_ABI = [
    {"name": "totalSupply", "type": "function", "stateMutability": "view",
     "inputs": [], "outputs": [{"type": "uint256"}]},
    {"name": "decimals", "type": "function", "stateMutability": "view",
     "inputs": [], "outputs": [{"type": "uint8"}]},
]

SYRUPUSDC_CHAIN_CONFIGS = [
    {
        "chain": "ethereum",
        "kind": "evm",
        "network": "Ethereum Mainnet",
        "token_address": "0x80ac24aA929eaF5013f6436cdA2a7ba190f5Cc0b",
    },
    {
        "chain": "solana",
        "kind": "solana",
        "token_address": "AvZZF1YaZDziPY2RCK4oJrRVrbN3mTD9NL24hPeaZeUj",
    },
    {
        "chain": "arbitrum",
        "kind": "evm",
        "network": "Arbitrum Mainnet",
        "token_address": "0x41CA7586cC1311807B4605fBB748a3B8862b42b5",
    },
    {
        "chain": "base",
        "kind": "evm",
        "network": "Base Mainnet",
        "token_address": "0x660975730059246A68521a3e2FBD4740173100f5",
    },
    {
        # Material and directly held by the portfolio. Omitting this leg made
        # the residual Ethereum calculation absorb Monad supply and left the
        # dashboard blind to the chain where the position actually sits.
        "chain": "monad",
        "kind": "evm",
        "network": "Monad Mainnet",
        "token_address": "0xab6E5a0C3799d020C790d34F7b2c02639e238AF7",
    },
    {"chain": "ink", "kind": "evm", "network": "Ink Mainnet",
     "token_address": "0x3c23e6FB09064e9A64829Fa8FEe27Ad19A27Bfa9"},
    {"chain": "tempo", "kind": "evm", "network": "Tempo Mainnet",
     "token_address": "0x20c0000000000000000000008191667423F70E67",
     "note": "Registry deployment; token observation is not bridge reconciliation"},
    {"chain": "robinhood", "kind": "evm", "network": "Robinhood Mainnet",
     "token_address": "0xC6a4854eeB493224d5f9485E12Dd3A81f22EEE14"},
    {"chain": "arc", "kind": "evm", "network": "Arc Mainnet",
     "token_address": "0x0dC6b79F3c3854E4d74514fD4d29BE6c96Beee39",
     "note": "Registry deployment; token observation is not bridge reconciliation"},
]

SYRUPUSDT_CHAIN_CONFIGS = [
    {
        "chain": "ethereum",
        "kind": "evm",
        "network": "Ethereum Mainnet",
        "token_address": "0x356B8d89c1e1239Cbbb9dE4815c39A1474d5BA7D",
    },
    {
        "chain": "plasma",
        "kind": "evm",
        "network": "Plasma Mainnet",
        "token_address": "0xC4374775489CB9C56003BF2C9b12495fC64F0771",
    },
    {"chain": "mantle", "kind": "evm", "network": "Mantle Mainnet",
     "token_address": "0x051665f2455116e929b9972c36d23070f5054ce0"},
    {"chain": "bnb", "kind": "evm", "network": "BNB Smart Chain Mainnet",
     "token_address": "0x8E9d4cEa39299323FE8eda678cAD449718556c4e"},
    {"chain": "ink", "kind": "evm", "network": "Ink Mainnet",
     "token_address": "0x8A76fe7fA6da27f85a626c5C53730B38D13603d7"},
]

PHASE_2_OPEN_ITEMS = [
    "DEX depth probes on Solana (Jupiter), Arbitrum/Base/Monad (chain-native aggregators)",
    "Registry deployments require measured token supply; bridge reconciliation remains separate",
    "CCT pool rate-limit + bridge headroom per chain",
]


def _round_or_none(value: Optional[float], digits: int = 2) -> Optional[float]:
    if value is None:
        return None
    return round(value, digits)


def _fetch_evm_total_supply(network: str, token_address: str) -> Dict[str, Any]:
    def _query(w3):
        token = w3.eth.contract(Web3.to_checksum_address(token_address), abi=TOTAL_SUPPLY_ABI)
        decimals = token.functions.decimals().call()
        expected_id = {"Tempo Mainnet": 4217, "Arc Mainnet": 5042, "Robinhood Mainnet": 4663}.get(network)
        chain_id = w3.eth.chain_id
        if expected_id is not None and chain_id != expected_id:
            raise RuntimeError(f"Unexpected chain ID {chain_id}, expected {expected_id}")
        block = w3.eth.block_number
        raw_supply = token.functions.totalSupply().call(block_identifier=block)
        return {
            "supply_raw": str(raw_supply),
            "decimals": decimals,
            "supply_native": raw_supply / (10 ** decimals),
            "block_number": block, "chain_id": chain_id,
        }

    public_rpc = {"Mantle Mainnet": "https://rpc.mantle.xyz", "BNB Smart Chain Mainnet": "https://bsc-dataseed.binance.org", "Ink Mainnet": "https://rpc-gel.inkonchain.com", "Robinhood Mainnet": "https://rpc.mainnet.chain.robinhood.com", "Tempo Mainnet": "https://rpc.tempo.xyz", "Arc Mainnet": "https://rpc.mainnet.arc.io"}.get(network)
    result = _query(Web3(Web3.HTTPProvider(public_rpc, request_kwargs={"timeout": 15}))) if public_rpc else execute_with_fallback(network, _query)
    if result is None:
        raise RuntimeError(f"totalSupply unavailable on {network}")
    return result


def _fetch_solana_token_supply(mint_address: str) -> Dict[str, Any]:
    payload = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "getTokenSupply",
        "params": [mint_address],
    }
    response = requests.post(SOLANA_RPC_URL, json=payload, timeout=15)
    response.raise_for_status()
    data = response.json()
    if "error" in data:
        raise RuntimeError(data["error"])
    value = data["result"]["value"]
    raw_supply = int(value["amount"])
    decimals = int(value["decimals"])
    return {
        "supply_raw": str(raw_supply),
        "decimals": decimals,
        "supply_native": raw_supply / (10 ** decimals),
    }


def _stub_entry(config: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "chain": config["chain"],
        "kind": config.get("kind"),
        "token_address": config.get("token_address"),
        "supply_native": None,
        "supply_usd": None,
        "share_pct": None,
        "data_source": "stub",
        "note": config.get("note", "Phase 2"),
    }


def _unavailable_entry(config: Dict[str, Any], error: Exception) -> Dict[str, Any]:
    return {
        "chain": config["chain"],
        "kind": config.get("kind"),
        "token_address": config.get("token_address"),
        "supply_native": None,
        "supply_usd": None,
        "share_pct": None,
        "data_source": "unavailable",
        "error": str(error)[:200],
    }


def _live_entry(
    config: Dict[str, Any],
    nav: float,
    ethereum_supply_native: Optional[float],
    supply_override_native: Optional[float] = None,
    note: Optional[str] = None,
) -> Dict[str, Any]:
    if supply_override_native is not None:
        supply = {
            "supply_raw": str(int(round(supply_override_native * 10 ** 6))),
            "decimals": 6,
            "supply_native": supply_override_native,
        }
    elif config["chain"] == "ethereum" and ethereum_supply_native is not None:
        supply = {
            "supply_raw": str(int(round(ethereum_supply_native * 10 ** 6))),
            "decimals": 6,
            "supply_native": ethereum_supply_native,
        }
    elif config["kind"] == "evm":
        supply = _fetch_evm_total_supply(config["network"], config["token_address"])
    elif config["kind"] == "solana":
        supply = _fetch_solana_token_supply(config["token_address"])
    else:
        raise RuntimeError(f"Unsupported chain kind: {config.get('kind')}")

    supply_usd = supply["supply_native"] * nav
    entry = {
        "chain": config["chain"],
        "token_address": config.get("token_address"),
        "supply_native": _round_or_none(supply["supply_native"], 6),
        "supply_raw": supply["supply_raw"],
        "block_number": supply.get("block_number"),
        "chain_id": supply.get("chain_id"),
        "decimals": supply["decimals"],
        "supply_usd": _round_or_none(supply_usd, 2),
        "share_pct": None,
        "data_source": "on_chain_token_supply",
        "kind": config["kind"],
    }
    if note:
        entry["note"] = note
    return entry


def build_syrup_multi_chain_block(
    asset_slug: str,
    nav: Optional[float],
    total_assets: Optional[float],
    ethereum_supply_native: Optional[float],
) -> Dict[str, Any]:
    if not nav or nav <= 0:
        return {
            "data_source": "unavailable",
            "reason": "canonical NAV unavailable",
            "phase_2_open_items": PHASE_2_OPEN_ITEMS,
        }

    if asset_slug == "syrupusdc":
        configs = SYRUPUSDC_CHAIN_CONFIGS
        note = (
            "Plasma was investigated but no syrupUSDC deployment was found; "
            "the similarly named holdings reported by multichain wallet pages "
            "resolve to syrupUSDC on other chains, not Plasma."
        )
    elif asset_slug == "syrupusdt":
        configs = SYRUPUSDT_CHAIN_CONFIGS
        note = None
    else:
        raise ValueError(f"Unsupported Syrup asset: {asset_slug}")

    chains: List[Dict[str, Any]] = []
    ethereum_config = None

    for config in configs:
        if config["chain"] == "ethereum":
            ethereum_config = config
            continue
        if config.get("data_source") == "stub":
            chains.append(_stub_entry(config))
            continue
        try:
            chains.append(_live_entry(config, nav, ethereum_supply_native))
        except Exception as exc:
            chains.append(_unavailable_entry(config, exc))

    if ethereum_config:
        live_remote_supply_native = sum(
            c.get("supply_native") or 0
            for c in chains
            if c.get("data_source") == "on_chain_token_supply"
        )
        ethereum_resident_supply = ethereum_supply_native
        ethereum_note = "Canonical totalSupply includes bridge locks; resident decomposition unverified"
        try:
            chains.append(_live_entry(
                ethereum_config,
                nav,
                ethereum_supply_native,
                supply_override_native=ethereum_resident_supply,
                note=ethereum_note,
            ))
        except Exception as exc:
            chains.append(_unavailable_entry(ethereum_config, exc))

    total_supply_usd = sum(c.get("supply_usd") or 0 for c in chains)
    for chain in chains:
        supply_usd = chain.get("supply_usd")
        if supply_usd is not None and total_supply_usd > 0:
            chain["share_pct"] = round(supply_usd / total_supply_usd * 100, 2)

    chains.sort(
        key=lambda chain: (
            chain.get("supply_usd") is not None,
            chain.get("supply_usd") or 0,
        ),
        reverse=True,
    )

    ethereum_supply_usd = sum(
        c.get("supply_usd") or 0 for c in chains if c.get("chain") == "ethereum"
    )
    reconciliation_pct = (
        total_supply_usd / total_assets * 100
        if total_assets and total_assets > 0 else None
    )
    chains_known = [config["chain"] for config in configs]
    chains_enumerated = [
        chain["chain"] for chain in chains
        if chain.get("data_source") == "on_chain_token_supply"
    ]
    chains_unavailable = [
        chain for chain in chains_known if chain not in chains_enumerated
    ]

    output = {
        "data_source": "phase_1_supply_only",
        "total_supply_usd_across_chains": round(total_supply_usd, 2),
        "ethereum_share_pct": (
            round(ethereum_supply_usd / total_supply_usd * 100, 2)
            if total_supply_usd > 0 else None
        ),
        "non_ethereum_share_pct": (
            round((total_supply_usd - ethereum_supply_usd) / total_supply_usd * 100, 2)
            if total_supply_usd > 0 else None
        ),
        "cross_chain_supply_reconciliation_pct": _round_or_none(reconciliation_pct, 2),
        "cross_chain_supply_reconciliation_chains": chains_enumerated,
        "cross_chain_supply_reconciliation_complete": not chains_unavailable,
        "cross_chain_supply_reconciliation_denominator": "vault_state.total_assets",
        "chains_known": chains_known,
        "chains_enumerated": chains_enumerated,
        "chains_unavailable": chains_unavailable,
        "canonical_nav_source": "vault_state.nav",
        "chains": chains,
        "phase_2_open_items": PHASE_2_OPEN_ITEMS,
    }
    if asset_slug in {"syrupusdt", "syrupusdc"}:
        # Canonical shares already include bridge-locked shares. Remote minted
        # representations are observations, never additive economic liabilities.
        for chain in chains:
            chain["share_pct"] = None
            chain["supply_scope"] = "canonical_including_locked" if chain["chain"] == "ethereum" else "remote_representation"
        output.update({
            "data_source": "canonical_and_remote_observations_unreconciled",
            "phase_2_open_items": ["Verify current Ethereum locks against all remote supplies and in-flight transfers at aligned blocks", "CCT pool rate-limit and bridge headroom per chain"],
            "canonical_total_assets_usd": total_assets,
            "canonical_total_supply_native": ethereum_supply_native,
            "canonical_supply_nav_usd": ethereum_supply_native * nav if ethereum_supply_native is not None else None,
            "total_supply_usd_across_chains": None,
            "ethereum_share_pct": None, "non_ethereum_share_pct": None,
            "cross_chain_supply_reconciliation_pct": None,
            "cross_chain_supply_reconciliation_complete": False,
            "chain_resident_decomposition_complete": False,
            "bridge_lock_verification_status": "unknown_current_pool_migration_not_verified",
            "cross_chain_supply_reconciliation_denominator": "canonical vault_state.total_assets; remote representations must not be added",
            "registry_source": "https://docs.maple.finance/integrate/crosschain/syrupusd-crosschain.md",
            "registry_reviewed_at": "2026-10-29" if asset_slug == "syrupusdc" else "2026-10-28",
            "note": "Ethereum totalSupply includes bridge locks. Resident decomposition unavailable until current pool identities and locks reconcile; no excess backing or overissuance inference.",
        })
    if note:
        output["note"] = note
    if asset_slug == "syrupusdc":
        output["chains_investigated_no_deployment_found"] = ["plasma"]
    return output
