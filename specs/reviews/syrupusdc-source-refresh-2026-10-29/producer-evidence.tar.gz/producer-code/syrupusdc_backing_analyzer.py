"""
syrupUSDC (Maple Finance) Backing & Risk Analyzer

Reads syrupUSDC vault state, loan book, and governance from Ethereum mainnet
and emits data/syrupusdc_backing.json + data/syrupusdc_backing_history.json.

Architecture (Maple v2):
  Pool (ERC-4626 share token, 6 decimals, NAV ~$1.16)
    └── PoolManager
          └── strategyList
                ├── Strategy 0 — OpenTermLoanManager (verified)
                │     └── per-loan: borrower, principal, rate, due dates...
                ├── Strategy 1+ (likely additional Loan/Aave strategies)
                ...
          └── WithdrawalManager (cycle-based exit queue)

Headline metric: Pool Coverage Ratio (PCR)
    PCR = (free_USDC + sum(strategy.assetsUnderManagement)) / pool.totalAssets * 100

Loan enumeration (Phase 2):
  Scan OpenTermLoanFactory.InstanceDeployed events via dRPC (10k-block chunks),
  cache loan addresses, then filter to active loans for the current LoanManager
  via paymentFor(loan).startDate > 0 + principal() > 0.

Reference (verified 2026-04-30):
  Pool                          0x80ac24aA929eaF5013f6436cdA2a7ba190f5Cc0b
  PoolManager                   0x7aD5fFa5fdF509E30186F4609c2f6269f4B6158F
  WithdrawalManager             0x1bc47a0Dd0FdaB96E9eF982fdf1F34DC6207cfE3
  MapleGlobals                  0x804a6F5F667170F545Bf14e5DDB48C70B788390C
  Strategy 0 (OpenTermLM)       0x6ACEb4cAbA81Fa6a8065059f3A944fb066A10fAc
  OpenTermLoanFactory           0x6Fad515Fc046DD17166453A79725f50b917b7cF6
  Pool Delegate (EOA)           0xC1e18FFD8825FfB286D177DDEbeba345EC70B49f
  PoolDelegateCover             0x9e62FE15d0E99cE2b30CE0D256e9Ab7b6893AfF5

Output schema additions (handoff 2, 2026-05-04):
  governance.pool_delegate              object {address, firm_name, is_eoa}.
                                        firm_name is null when unverified
                                        (no "TBD" placeholders); resolved via
                                        SYRUP_POOL_DELEGATE_FIRM static map.
  loan_book.concentration.borrowers[].borrower_meta_tag
                                        Structural classifier from
                                        BORROWER_META_TAG (loanMeta.type +
                                        on-chain interaction analysis); null
                                        when unmapped.
  withdrawal_queue.last_filled_*        Latest RequestProcessed event
                                        timestamp + age. Scans WithdrawalManager
                                        logs in 10k-block chunks (early-exit on
                                        first hit, ~30d window).
  withdrawal_queue.next_request_age_seconds
                                        Age of the next pending request, derived
                                        from RequestCreated event for the queue
                                        head. Null when queue is empty.
  withdrawal_queue.current_cycle_*      Always null — Maple Syrup pools use the
                                        QUEUE-based WithdrawalManager (impl
                                        0xF95E…e967), not the cyclical variant.
                                        Field reserved for future cyclical pools.
  yield.apy_history.entries[]           30 daily {timestamp, core_apy_pct,
                                        boost_apy_pct, total_apy_pct} points
                                        from syrupGlobals.apyTimeSeries(MONTH).
  multi_chain                           Phase 1 supply-only CCT view. Reads
                                        per-chain totalSupply for Ethereum,
                                        Solana, Arbitrum, and Base; Plasma and
                                        DEX/bridge headroom remain Phase 2.

Usage:
    python3 syrupusdc_backing_analyzer.py
"""

import argparse
import json
import os
import uuid
import random
import sys
import time
from datetime import datetime, timezone

import requests
from eth_utils import keccak, to_checksum_address
from web3 import Web3
from web3.exceptions import ContractLogicError

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from special_assets.web3_manager import execute_with_fallback
from special_assets.price_fetcher import DRPC_API_KEY
from syrup_multichain_supply import build_syrup_multi_chain_block
from liquidity_tracker import ladder_history_row
from syrup_position_classification import classify_usdc, coverage, USDC_VERSION

# ---------------------------------------------------------------------------
# Contract addresses (Ethereum mainnet) — verified 2026-04-30
# ---------------------------------------------------------------------------
POOL                = "0x80ac24aA929eaF5013f6436cdA2a7ba190f5Cc0b"
POOL_MANAGER        = "0x7aD5fFa5fdF509E30186F4609c2f6269f4B6158F"
WITHDRAWAL_MANAGER  = "0x1bc47a0Dd0FdaB96E9eF982fdf1F34DC6207cfE3"
MAPLE_GLOBALS       = "0x804a6F5F667170F545Bf14e5DDB48C70B788390C"
STRATEGY_0          = "0x6ACEb4cAbA81Fa6a8065059f3A944fb066A10fAc"  # OpenTermLoanManager
OPEN_TERM_FACTORY   = "0x6Fad515Fc046DD17166453A79725f50b917b7cF6"
USDC                = "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48"

# EIP1967 implementation slot — Maple proxies use the standard slot.
EIP1967_IMPL_SLOT = 0x360894A13BA1A3210667C828492DB98DCA3E2076CC3735A920A3CA505D382BBC

# Strategy implementation address → human-readable name. Verified on-chain
# 2026-05-03 by reading the EIP1967 impl slot of every proxy in
# syrupUSDC.PoolManager.strategyList; same impls also back the syrupUSDT pool
# (different proxies, identical bytecode).
STRATEGY_IMPL_NAMES = {
    "0xbAD003DA1e107f537Ae2f687f5FE7a7aFFe9B241".lower(): "OpenTermLoanManager",
    "0x5b97c9DccE2693844b90Cea40ba1fD15Bf99Eb01".lower(): "FixedTermLoanManager",
    "0xFc8F7F97165d446B02Cc95363d2cA31154BBe9F9".lower(): "MapleAaveStrategy",
    "0xBBEe42621499005Ff0dDEF947BBDeFfBBeE77730".lower(): "MapleSkyStrategy",
}

# A sleeve at the 10-wei placeholder is dormant; only flag once the delegate
# has actually redeployed material capital into the wrapped protocol.
SLEEVE_ACTIVATION_THRESHOLD_USD = 100_000

GOVERNOR            = "0x2eFFf88747EB5a3FF00d4d8d0f0800E306C0426b"  # 24h timelock
OPS_ADMIN_SAFE      = "0xCe1cE7c7F436DCc4E28Bc8bf86115514d3DC34E8"  # 3-of-5
SEC_ADMIN_SAFE      = "0x6b1A78C1943b03086F7Ee53360f9b0672bD60818"  # 3-of-6
POOL_DELEGATE       = "0xC1e18FFD8825FfB286D177DDEbeba345EC70B49f"  # EOA (single-key)
POOL_DELEGATE_COVER = "0x9e62FE15d0E99cE2b30CE0D256e9Ab7b6893AfF5"

# Pool delegate firm identity. Static map keyed on lower-cased EOA address,
# sourced from Maple's published delegate roster. Values are surfaced as
# governance.pool_delegate.firm_name. Unmapped delegates render as null —
# never use "TBD" placeholders. Quarterly review cadence.
SYRUP_POOL_DELEGATE_FIRM: dict[str, str] = {
    "0xc1e18ffd8825ffb286d177ddebeba345ec70b49f": "Maven 11 Capital",  # syrupUSDC
    # syrupUSDT delegate 0x93aA…501A: unverified, intentionally absent.
}

# OpenTermLoanFactory deployment block (approximate — early scan can be wide;
# get_logs_with_retry handles empty ranges gracefully).
FACTORY_DEPLOY_BLOCK = 17_500_000  # mid-2023; conservative

NETWORK = "Ethereum Mainnet"
USDC_DEC = 6
SHARE_DEC = 6  # syrupUSDC pool token has 6 decimals (verified)

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
DATA_DIR            = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
JSON_OUTPUT         = os.path.join(DATA_DIR, "syrupusdc_backing.json")
LAST_GOOD_JSON      = os.path.join(DATA_DIR, "syrupusdc_backing_last_good.json")
HISTORY_DB_PATH     = os.path.join(DATA_DIR, "backing_history.json")
HISTORY_EXPORT_PATH = os.path.join(DATA_DIR, "syrupusdc_backing_history.json")
HISTORY_EXPORT_DAYS = 30
LOAN_CACHE_PATH     = os.path.join(DATA_DIR, "syrupusdc_loan_cache.json")
PEG_TRACKER_LATEST  = os.path.join(DATA_DIR, "peg_tracker_latest_usd.json")

# ---------------------------------------------------------------------------
# Minimal ABIs — only view functions we call
# ---------------------------------------------------------------------------
ABI_ERC20 = [
    {"name": "balanceOf", "type": "function", "stateMutability": "view",
     "inputs": [{"name": "a", "type": "address"}], "outputs": [{"type": "uint256"}]},
    {"name": "totalSupply", "type": "function", "stateMutability": "view",
     "inputs": [], "outputs": [{"type": "uint256"}]},
    {"name": "decimals", "type": "function", "stateMutability": "view",
     "inputs": [], "outputs": [{"type": "uint8"}]},
]

ABI_POOL = ABI_ERC20 + [
    {"name": "totalAssets", "type": "function", "stateMutability": "view",
     "inputs": [], "outputs": [{"type": "uint256"}]},
    {"name": "asset", "type": "function", "stateMutability": "view",
     "inputs": [], "outputs": [{"type": "address"}]},
]

ABI_POOL_MANAGER = [
    {"name": "liquidityCap", "type": "function", "stateMutability": "view",
     "inputs": [], "outputs": [{"type": "uint256"}]},
    {"name": "delegateManagementFeeRate", "type": "function", "stateMutability": "view",
     "inputs": [], "outputs": [{"type": "uint256"}]},
    {"name": "unrealizedLosses", "type": "function", "stateMutability": "view",
     "inputs": [], "outputs": [{"type": "uint128"}]},
    {"name": "strategyList", "type": "function", "stateMutability": "view",
     "inputs": [{"name": "i", "type": "uint256"}], "outputs": [{"type": "address"}]},
    {"name": "strategyListLength", "type": "function", "stateMutability": "view",
     "inputs": [], "outputs": [{"type": "uint256"}]},
    {"name": "active", "type": "function", "stateMutability": "view",
     "inputs": [], "outputs": [{"type": "bool"}]},
    {"name": "configured", "type": "function", "stateMutability": "view",
     "inputs": [], "outputs": [{"type": "bool"}]},
    {"name": "poolDelegate", "type": "function", "stateMutability": "view",
     "inputs": [], "outputs": [{"type": "address"}]},
]

ABI_GLOBALS = [
    {"name": "protocolPaused", "type": "function", "stateMutability": "view",
     "inputs": [], "outputs": [{"type": "bool"}]},
    {"name": "governor", "type": "function", "stateMutability": "view",
     "inputs": [], "outputs": [{"type": "address"}]},
    {"name": "operationalAdmin", "type": "function", "stateMutability": "view",
     "inputs": [], "outputs": [{"type": "address"}]},
    {"name": "securityAdmin", "type": "function", "stateMutability": "view",
     "inputs": [], "outputs": [{"type": "address"}]},
    {"name": "minCoverAmount", "type": "function", "stateMutability": "view",
     "inputs": [{"name": "a", "type": "address"}], "outputs": [{"type": "uint256"}]},
]

ABI_STRATEGY = [
    {"name": "assetsUnderManagement", "type": "function", "stateMutability": "view",
     "inputs": [], "outputs": [{"type": "uint256"}]},
    {"name": "principalOut", "type": "function", "stateMutability": "view",
     "inputs": [], "outputs": [{"type": "uint128"}]},
    {"name": "accountedInterest", "type": "function", "stateMutability": "view",
     "inputs": [], "outputs": [{"type": "uint112"}]},
    {"name": "unrealizedLosses", "type": "function", "stateMutability": "view",
     "inputs": [], "outputs": [{"type": "uint128"}]},
    {"name": "paymentFor", "type": "function", "stateMutability": "view",
     "inputs": [{"name": "l", "type": "address"}],
     "outputs": [{"type": "uint24"}, {"type": "uint24"}, {"type": "uint40"}, {"type": "uint168"}]},
    {"name": "impairmentFor", "type": "function", "stateMutability": "view",
     "inputs": [{"name": "l", "type": "address"}],
     "outputs": [{"type": "uint40"}, {"type": "bool"}]},
    {"name": "fundsAsset", "type": "function", "stateMutability": "view",
     "inputs": [], "outputs": [{"type": "address"}]},
]

ABI_LOAN = [
    {"name": "borrower", "type": "function", "stateMutability": "view",
     "inputs": [], "outputs": [{"type": "address"}]},
    {"name": "principal", "type": "function", "stateMutability": "view",
     "inputs": [], "outputs": [{"type": "uint256"}]},
    {"name": "interestRate", "type": "function", "stateMutability": "view",
     "inputs": [], "outputs": [{"type": "uint256"}]},
    {"name": "paymentInterval", "type": "function", "stateMutability": "view",
     "inputs": [], "outputs": [{"type": "uint256"}]},
    {"name": "paymentDueDate", "type": "function", "stateMutability": "view",
     "inputs": [], "outputs": [{"type": "uint256"}]},
    {"name": "dateFunded", "type": "function", "stateMutability": "view",
     "inputs": [], "outputs": [{"type": "uint256"}]},
    {"name": "isImpaired", "type": "function", "stateMutability": "view",
     "inputs": [], "outputs": [{"type": "bool"}]},
    {"name": "isCalled", "type": "function", "stateMutability": "view",
     "inputs": [], "outputs": [{"type": "bool"}]},
    {"name": "isInDefault", "type": "function", "stateMutability": "view",
     "inputs": [], "outputs": [{"type": "bool"}]},
    {"name": "noticePeriod", "type": "function", "stateMutability": "view",
     "inputs": [], "outputs": [{"type": "uint256"}]},
    {"name": "gracePeriod", "type": "function", "stateMutability": "view",
     "inputs": [], "outputs": [{"type": "uint256"}]},
    {"name": "lateInterestPremiumRate", "type": "function", "stateMutability": "view",
     "inputs": [], "outputs": [{"type": "uint256"}]},
    {"name": "lateFeeRate", "type": "function", "stateMutability": "view",
     "inputs": [], "outputs": [{"type": "uint256"}]},
    {"name": "platformServiceFeeRate", "type": "function", "stateMutability": "view",
     "inputs": [], "outputs": [{"type": "uint256"}]},
    {"name": "delegateServiceFeeRate", "type": "function", "stateMutability": "view",
     "inputs": [], "outputs": [{"type": "uint256"}]},
]

ABI_WM_QUEUE = [
    # WithdrawalManager.queue() returns (nextRequestId, lastRequestId).
    # Empty when nextRequestId > lastRequestId.
    {"name": "queue", "type": "function", "stateMutability": "view",
     "inputs": [], "outputs": [{"type": "uint256"}, {"type": "uint256"}]},
]

# Multicall3 (deployed at the same address on every EVM chain)
MULTICALL3 = "0xcA11bde05977b3631167028862bE2a173976CA11"
MULTICALL3_ABI = [
    {"name": "aggregate3", "type": "function", "stateMutability": "payable",
     "inputs": [{"name": "calls", "type": "tuple[]",
                 "components": [{"name": "target", "type": "address"},
                                {"name": "allowFailure", "type": "bool"},
                                {"name": "callData", "type": "bytes"}]}],
     "outputs": [{"name": "returnData", "type": "tuple[]",
                  "components": [{"name": "success", "type": "bool"},
                                 {"name": "returnData", "type": "bytes"}]}]},
]
MULTICALL_CHUNK = 200  # calls per aggregate3 batch

# Borrower → firm name map (lower-cased addresses).
# Populate as Maple publishes delegate/borrower disclosures or identities are
# confirmed via Etherscan/labelling services. Unmapped borrowers render as null.
BORROWER_FIRM_MAP: dict[str, str] = {
    # "0x1fcc47ee0f19ca0f07f8b987f0ad32ac204c03a7": "Wintermute",
}

# Borrower → structural meta tag (lower-cased addresses). Sourced from Maple
# loanMeta.type GraphQL classifier + on-chain interaction analysis. Tag wording
# is intentionally structural — does not assert legal-entity relationships.
# Surfaced as concentration.borrowers[].borrower_meta_tag; null when unmapped.
BORROWER_META_TAG: dict[str, str] = {
    "0x1fcc47ee0f19ca0f07f8b987f0ad32ac204c03a7": "Multi-product credit (PYUSD/USTB)",
    "0x2570faf7c8a0da87d3f123b35cc722ec3fcc3e08": "Maple-affiliated (AMM-classified)",
}

# Withdrawal queue event topics (Maple WithdrawalManagerQueue impl
# 0xF95E5722226a1018d058CD757B75F1D10289e967). Verified on-chain 2026-05-04
# against live USDC pool logs — request IDs are uint256 in the deployed
# implementation despite some Maple docs using uint128.
T_REQUEST_PROCESSED = "0x" + keccak(b"RequestProcessed(uint256,address,uint256,uint256)").hex()
T_REQUEST_CREATED   = "0x" + keccak(b"RequestCreated(uint256,address,uint256)").hex()
WQ_HISTORY_BLOCK_WINDOW = 250_000  # ~30 days at 12s/block
# Withdrawal-queue timing is peripheral enrichment — it must never consume the
# whole 300s analyzer budget. Bound the event-scan to this many seconds; on
# breach we emit the core backing snapshot with null timing + a degraded flag.
WQ_TIMING_BUDGET_SECONDS = 60

SECONDS_PER_YEAR = 31_536_000

# ---------------------------------------------------------------------------
# Maple GraphQL collateral enrichment (Phase 2.5)
# ---------------------------------------------------------------------------
MAPLE_GRAPHQL = "https://api.maple.finance/v2/graphql"
AT_PAR_INIT_LEVEL_THRESHOLD_PCT = 105.0  # init_level_pct ≤ 105 → Set B (at par)

# Set A (overcollateralized crypto) collateralization-health floors. Measured
# against current_level_pct (= collateral_usd / principal × 100), an ABSOLUTE
# floor — NOT against the funding-time init level. A Set A loan drifting below
# its high init margin (e.g. 333% → 270%) is still deeply overcollateralized and
# is not a risk event; what matters is proximity to principal (100%).
#   < 100%  → CRIT  (collateral worth less than principal — genuinely underwater)
#   < 120%  → WARN  (thin buffer above principal)
# Set B (at-par) is intentionally excluded: it sits at ~100% by construction
# (collateral priced at $1.00 peg_assumed), so an absolute floor can't apply —
# its peg/issuer risk is covered by the at-par concentration flags instead.
SET_A_CRIT_LEVEL_PCT = 100.0
SET_A_WARN_LEVEL_PCT = 120.0

# Chainlink USD aggregators (Ethereum mainnet). XRP feed reverts on latestAnswer
# in practice (verified 2026-05-01) — CoinGecko fallback handles that case.
CHAINLINK_FEEDS = {
    "BTC": "0xF4030086522a5bEEa4988F8cA5B36dbC97BeE88c",
    "ETH": "0x5f4eC3Df9cbd43714FE2740f5E3616155c5b8419",
    "XRP": "0xCed2660c6Dd1Ffd856A5A82C67f3482d88C50b12",
}
ABI_AGG = [
    {"name": "latestAnswer", "type": "function", "stateMutability": "view",
     "inputs": [], "outputs": [{"type": "int256"}]},
    {"name": "decimals", "type": "function", "stateMutability": "view",
     "inputs": [], "outputs": [{"type": "uint8"}]},
]

# CoinGecko fallback IDs for assets without a working Chainlink feed (or as
# backup if Chainlink ever fails). Free-tier rate limit is comfortable at one
# batched call per cron cycle.
COINGECKO_IDS = {
    "BTC": "bitcoin",
    "cbBTC": "bitcoin",   # 1:1 BTC peg
    "LBTC": "bitcoin",    # 1:1 BTC peg via Lombard
    "ETH": "ethereum",
    "XRP": "ripple",
    "HYPE": "hyperliquid",
    "SOL": "solana",
    "jitoSOL": "jito-staked-sol",
}
COINGECKO_URL = "https://api.coingecko.com/api/v3/simple/price"

# Token decimals for collateral-asset enum values returned by Maple GraphQL.
COLLATERAL_DECIMALS = {
    "BTC": 8, "cbBTC": 8, "LBTC": 8,
    "ETH": 18, "weETH": 18, "tETH": 18,
    "XRP": 6,
    "HYPE": 18, "SOL": 9, "jitoSOL": 9,
    "USDC": 6, "USDT": 6, "PYUSD": 6, "USTB": 6,
    "USR": 18, "LP_USR": 18, "sUSDS": 18,
    "PT_sUSDE": 18, "PT_USDE": 18,
}

# Coarse classification for the renderer's Set A / Set B split.
COLLATERAL_CATEGORY = {
    "BTC": "crypto", "cbBTC": "crypto", "LBTC": "crypto",
    "ETH": "crypto", "weETH": "crypto", "tETH": "crypto",
    "XRP": "crypto", "SOL": "crypto", "jitoSOL": "crypto",
    "HYPE": "crypto",
    "USDC": "stablecoin", "USDT": "stablecoin", "PYUSD": "stablecoin",
    "USR": "stablecoin", "LP_USR": "stablecoin", "sUSDS": "stablecoin",
    "USTB": "rwa",
    "PT_sUSDE": "yield_token", "PT_USDE": "yield_token",
}

# Issuer attribution. "—" = decentralized / no single issuer.
COLLATERAL_ISSUER = {
    "PYUSD": "Paxos", "USTB": "Superstate", "USDC": "Circle",
    "USDT": "Tether", "BTC": "—", "cbBTC": "Coinbase", "ETH": "—",
    "XRP": "—", "HYPE": "—", "SOL": "—", "jitoSOL": "Jito",
    "weETH": "Ether.fi", "tETH": "Treehouse", "LBTC": "Lombard",
    "USR": "Resolv", "LP_USR": "Resolv", "sUSDS": "Sky",
    "PT_sUSDE": "Pendle", "PT_USDE": "Pendle",
}

# Assets we treat as $1 ± peg deviation when no Chainlink feed is available.
STABLECOIN_ASSETS = {"USDC", "USDT", "PYUSD", "USTB", "USR", "LP_USR", "sUSDS"}

# ---------------------------------------------------------------------------
# Loans vs Liquidity classification
# ---------------------------------------------------------------------------
# Maple's own AUM Details page (app.maple.finance/earn/details) splits Syrup
# family AUM into Loans vs Liquidity. Strategy 0's LoanManager wraps both —
# Liquidity positions are pool-owned strategies recorded as loans for
# accounting purposes (init_level=100, stablecoin/RWA collateral, often tagged
# loanMeta.type ∈ {amm,strategy,intercompany,defi}).
LIQUIDITY_LOAN_META_TYPES = {"amm", "strategy", "intercompany", "defi"}
LIQUIDITY_COLLATERAL_CATEGORIES = {"stablecoin", "rwa"}

# Asset NAV snapshot for Liquidity-position custody balances. USTB is
# NAV-accruing (Superstate); other entries default to 1.0. Live oracle pull is
# out of scope for this iteration — refresh quarterly or when NAV moves >1%.
LIQUIDITY_NAV_USD = {
    "USTB": 10.10,  # Superstate NAV snapshot 2026-05-04
}

# Liquidity-position custody addresses, keyed on
# (asset_slug, collateral_asset, loan_borrower_lower). The loan-record
# `borrower` field is the on-chain accounting account; the actual asset
# custody can be a separate EOA. Verified 2026-05-04.
SYRUP_LIQUIDITY_CUSTODY = {
    ("syrupusdc", "PYUSD", "0x1fcc47ee0f19ca0f07f8b987f0ad32ac204c03a7"):
        {"custody_addr": "0xe7F0FdD40472775A659C3e42bda605A88642657b",
         "chain": "ethereum"},
    ("syrupusdc", "USTB", "0x1fcc47ee0f19ca0f07f8b987f0ad32ac204c03a7"):
        {"custody_addr": "0x1FcC47Ee0F19CA0f07F8b987F0aD32ac204C03a7",
         "chain": "ethereum"},
    ("syrupusdc", "USDC", "0x2570faf7c8a0da87d3f123b35cc722ec3fcc3e08"):
        {"custody_addr": "0x2570fAF7C8A0da87d3F123B35cC722EC3fCC3e08",
         "chain": "ethereum", "venue": "AMM-LP-pair"},
    # Solana $20M USDC/syrupUSDC LP custody at GNHCaFw4z3wmFtKGbuaZwiPzit3ebx2NVRtD8sxRJkx5
    # — Solana RPC reads deferred; Maple UI value trusted for now.
    ("syrupusdt", "PYUSD", "0x1fcc47ee0f19ca0f07f8b987f0ad32ac204c03a7"):
        {"custody_addr": "0xe7F0FdD40472775A659C3e42bda605A88642657b",
         "chain": "ethereum"},
    ("syrupusdt", "USDC", "0x2570faf7c8a0da87d3f123b35cc722ec3fcc3e08"):
        {"custody_addr": "0x2570fAF7C8A0da87d3F123B35cC722EC3fCC3e08",
         "chain": "ethereum", "venue": "AMM-LP-pair"},
    ("syrupusdt", "USDT", "0x2570faf7c8a0da87d3f123b35cc722ec3fcc3e08"):
        {"custody_addr": "0x2570fAF7C8A0da87d3F123B35cC722EC3fCC3e08",
         "chain": "ethereum", "venue": "AMM-LP-pair"},
}

# Token contract addresses for Liquidity custody balanceOf reads.
LIQUIDITY_ASSET_TOKENS = {
    "PYUSD": "0x6c3ea9036406852006290770BEdFcAbA0e23A0e8",
    "USTB":  "0x43415eB6ff9DB7E26A15b704e7A3eDCe97d31C4e",
    "USDC":  "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",
    "USDT":  "0xdAC17F958D2ee523a2206206994597C13D831ec7",
}
LIQUIDITY_ASSET_DECIMALS = {"PYUSD": 6, "USTB": 6, "USDC": 6, "USDT": 6}

# This analyzer's own asset_slug — used by classifier for custody lookups.
ASSET_SLUG = "syrupusdc"


def classify_position_type(init_level_pct, collateral_category, loan_meta_type):
    """Return "liquidity" or "loan" per the handoff heuristic.

    Liquidity positions are pool-owned strategies routed through Strategy 0's
    LoanManager as accounting wrappers. Two independent signals catch them:
      1. init_level_pct == 100.0 AND collateral category in {stablecoin, rwa}
         (these can never be true overcollateralized credit lines)
      2. loanMeta.type ∈ {amm, strategy, intercompany, defi} — Maple's own
         GraphQL classifier (verified 2026-05-04 against syrupUSDC pool)
    Either signal alone is sufficient; absence of both → "loan".
    """
    if loan_meta_type and loan_meta_type.lower() in LIQUIDITY_LOAN_META_TYPES:
        return "liquidity"
    if (init_level_pct == 100.0
            and collateral_category in LIQUIDITY_COLLATERAL_CATEGORIES):
        return "liquidity"
    return "loan"

# ---------------------------------------------------------------------------
# Formatting helpers
# ---------------------------------------------------------------------------
def fmt_usd(v):
    if v is None:
        return "n/a"
    if abs(v) >= 1e9:
        return f"${v / 1e9:.2f}B"
    if abs(v) >= 1e6:
        return f"${v / 1e6:.2f}M"
    if abs(v) >= 1e3:
        return f"${v / 1e3:.1f}K"
    return f"${v:,.2f}"


def fmt_pct(v, dp=2):
    if v is None:
        return "n/a"
    return f"{v:.{dp}f}%"


def now_iso():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


# ---------------------------------------------------------------------------
# Phase 1 — Vault state, strategies, withdrawal queue, governance
# ---------------------------------------------------------------------------
def _optional_strategy_read(fn):
    """Return the value, or None if THIS STRATEGY TYPE does not implement it.

    ⚠️ Only a revert means "not implemented". A transport failure propagates,
    because "the RPC timed out" and "this contract has no such field" are
    different facts and only one of them is safe to treat as zero.
    """
    try:
        return fn().call()
    except ContractLogicError:
        return None


def fetch_vault_state():
    """Read Pool, PoolManager, MapleGlobals, all strategies, WithdrawalManager.queue."""
    print("\n--- Vault state + strategies ---")

    def _query(w3):
        pool = w3.eth.contract(Web3.to_checksum_address(POOL), abi=ABI_POOL)
        pm = w3.eth.contract(Web3.to_checksum_address(POOL_MANAGER), abi=ABI_POOL_MANAGER)
        g = w3.eth.contract(Web3.to_checksum_address(MAPLE_GLOBALS), abi=ABI_GLOBALS)
        usdc = w3.eth.contract(Web3.to_checksum_address(USDC), abi=ABI_ERC20)
        wm = w3.eth.contract(Web3.to_checksum_address(WITHDRAWAL_MANAGER), abi=ABI_WM_QUEUE)

        total_assets = pool.functions.totalAssets().call()
        total_supply_raw = pool.functions.totalSupply().call()
        free_usdc_raw = usdc.functions.balanceOf(Web3.to_checksum_address(POOL)).call()

        liquidity_cap = pm.functions.liquidityCap().call()
        delegate_fee_rate = pm.functions.delegateManagementFeeRate().call()
        pm_unrealized = pm.functions.unrealizedLosses().call()
        pm_active = pm.functions.active().call()
        pm_configured = pm.functions.configured().call()
        try:
            pool_delegate_addr = pm.functions.poolDelegate().call()
        except Exception:
            pool_delegate_addr = POOL_DELEGATE

        protocol_paused = g.functions.protocolPaused().call()
        gov = g.functions.governor().call()
        op_admin = g.functions.operationalAdmin().call()
        sec_admin = g.functions.securityAdmin().call()
        min_cover = g.functions.minCoverAmount(Web3.to_checksum_address(POOL_MANAGER)).call()

        # ⚠️ Strategy 0 holds 100% of AUM in this pool ($973.6M syrupUSDC /
        # $406.8M syrupUSDT as of 2026-08-27). PCR is
        # (free_usdc + sum(strategy AUM)) / pool.totalAssets(), and the
        # denominator is an independent read — so ONE failed
        # assetsUnderManagement() call used to drop the whole numerator and take
        # PCR from 100% to ~0.05%.
        #
        # ⚠️ That is not a silent understatement, it is a fabricated insolvency:
        # syrup_risk_alerter fires CRITICAL below 100%, so an RPC hiccup would
        # have paged that a held position was uncollateralized. A plausible
        # number gets rated; this one would have been acted on.
        #
        # Every read below raises instead of defaulting. Raising rotates to the
        # next RPC first, and if all of them fail fetch_vault_state() returns
        # None and the analyzer exits without writing — stale beats wrong.
        # ⚠️ Enumerate against the CONTRACT'S OWN length, never by walking until
        # a call reverts. `for i in range(20): except: break` cannot tell "end of
        # list" from "this RPC just failed", so a hiccup at index 0 silently
        # yielded ZERO strategies — and index 0 is the one holding all the AUM.
        # An empty result is the dangerous output: it looks like an answer.
        strategies = []
        n_strategies = pm.functions.strategyListLength().call()
        for i in range(n_strategies):
            addr = pm.functions.strategyList(i).call()
            strategies.append(Web3.to_checksum_address(addr))
        if len(strategies) != n_strategies:
            raise RuntimeError(
                f"strategyList returned {len(strategies)} of {n_strategies} entries")

        # Per-strategy AUM/principal/UL
        strat_data = []
        for addr in strategies:
            s = w3.eth.contract(addr, abi=ABI_STRATEGY)
            # ⚠️ Three outcomes, not two. `except: = 0` collapsed all of them.
            #
            #   answered        -> the number
            #   NOT IMPLEMENTED -> a revert; this strategy type genuinely has no
            #                      such field, which is an ANSWER
            #   unread          -> transport failure; we know nothing, so raise
            #
            # Verified 2026-08-27: assetsUnderManagement() and unrealizedLosses()
            # are implemented by every strategy, while principalOut() and
            # accountedInterest() revert on the non-loan-manager strategies (the
            # Aave/Sky-style ones holding dust). The old blanket `= 0` was
            # therefore masking a legitimate interface difference AND a real
            # failure with the same value — which is why nobody noticed either.
            aum = s.functions.assetsUnderManagement().call()
            ul = s.functions.unrealizedLosses().call()
            principal = _optional_strategy_read(s.functions.principalOut)
            interest = _optional_strategy_read(s.functions.accountedInterest)
            try:
                impl_raw = w3.eth.get_storage_at(addr, EIP1967_IMPL_SLOT)
                impl_addr = "0x" + impl_raw.hex()[-40:]
            except Exception:
                impl_addr = None
            strat_data.append({
                "address": addr,
                "implementation": impl_addr,
                "is_loan_manager": addr.lower() == STRATEGY_0.lower(),
                "aum_raw": aum,
                "principal_out_raw": principal,
                "accounted_interest_raw": interest,
                "unrealized_losses_raw": ul,
            })

        # Pool delegate cover balance
        pd_cover_usdc = usdc.functions.balanceOf(Web3.to_checksum_address(POOL_DELEGATE_COVER)).call()
        pd_cover_eth = w3.eth.get_balance(Web3.to_checksum_address(POOL_DELEGATE_COVER))

        # Withdrawal queue
        try:
            next_id, last_id = wm.functions.queue().call()
        except Exception:
            next_id, last_id = (0, 0)

        # Detect if pool delegate is EOA vs contract
        pd_code = w3.eth.get_code(Web3.to_checksum_address(pool_delegate_addr))
        pd_is_eoa = len(pd_code) == 0

        return {
            "total_assets_raw": total_assets,
            "total_supply_raw": total_supply_raw,
            "free_usdc_raw": free_usdc_raw,
            "liquidity_cap_raw": liquidity_cap,
            "delegate_fee_rate_raw": delegate_fee_rate,
            "pm_unrealized_raw": pm_unrealized,
            "pm_active": pm_active,
            "pm_configured": pm_configured,
            "pool_delegate": pool_delegate_addr,
            "pool_delegate_is_eoa": pd_is_eoa,
            "protocol_paused": protocol_paused,
            "governor": gov,
            "operational_admin": op_admin,
            "security_admin": sec_admin,
            "min_cover_amount_raw": min_cover,
            "strategies": strat_data,
            "pd_cover_usdc_raw": pd_cover_usdc,
            "pd_cover_eth_wei": pd_cover_eth,
            "wq_next_request_id": next_id,
            "wq_last_request_id": last_id,
        }

    raw = execute_with_fallback(NETWORK, _query)
    if not raw:
        return None

    # Convert raw values to human-readable
    total_assets = raw["total_assets_raw"] / 10**USDC_DEC
    total_supply = raw["total_supply_raw"] / 10**SHARE_DEC
    free_usdc = raw["free_usdc_raw"] / 10**USDC_DEC

    strategy_aum = sum(s["aum_raw"] for s in raw["strategies"]) / 10**USDC_DEC
    # None means "this strategy type has no principalOut", not "it is zero" —
    # the sum treats it as nothing lent, which is true, but the count travels
    # with it so a reader can tell an incomplete book from a small one.
    principal_out = sum(
        s["principal_out_raw"] or 0 for s in raw["strategies"]) / 10**USDC_DEC
    strategies_without_principal = sum(
        1 for s in raw["strategies"] if s["principal_out_raw"] is None)
    unrealized_losses = sum(s["unrealized_losses_raw"] for s in raw["strategies"]) / 10**USDC_DEC

    nav = total_assets / total_supply if total_supply > 0 else None
    pcr_principal_pct = (
        (free_usdc + strategy_aum) / total_assets * 100 if total_assets > 0 else None
    )
    deployment_ratio_pct = (
        principal_out / total_assets * 100 if total_assets > 0 else None
    )
    free_liquidity = total_assets - principal_out  # USDC + accrued interest in strategies
    cap_utilization_pct = (
        total_assets / (raw["liquidity_cap_raw"] / 10**USDC_DEC) * 100
        if raw["liquidity_cap_raw"] > 0 else None
    )

    print(f"  totalAssets:    {fmt_usd(total_assets)}")
    print(f"  totalSupply:    {total_supply:,.2f} shares")
    print(f"  NAV:            ${nav:.6f}" if nav else "  NAV: n/a")
    print(f"  free_USDC:      {fmt_usd(free_usdc)}")
    print(f"  strategy_AUM:   {fmt_usd(strategy_aum)}  (principal_out={fmt_usd(principal_out)})")
    print(f"  PCR:            {fmt_pct(pcr_principal_pct)}")
    print(f"  Deployment:     {fmt_pct(deployment_ratio_pct)}")
    print(f"  Free liquidity: {fmt_usd(free_liquidity)}")
    print(f"  UL:             {fmt_usd(unrealized_losses)}")
    print(f"  Cap util:       {fmt_pct(cap_utilization_pct)} ({fmt_usd(raw['liquidity_cap_raw']/10**USDC_DEC)} cap)")
    print(f"  Paused:         {raw['protocol_paused']}")
    print(f"  Strategies:     {len(raw['strategies'])}")
    print(f"  Queue:          next={raw['wq_next_request_id']} last={raw['wq_last_request_id']}")

    return {
        # Vault state
        "total_assets": total_assets,
        "total_supply": total_supply,
        "nav": nav,
        "free_usdc": free_usdc,
        "strategy_aum": strategy_aum,
        "principal_out": principal_out,
        "unrealized_losses": unrealized_losses,
        "free_liquidity": free_liquidity,
        "pcr_principal_pct": pcr_principal_pct,
        "deployment_ratio_pct": deployment_ratio_pct,
        "liquidity_cap": raw["liquidity_cap_raw"] / 10**USDC_DEC,
        "cap_utilization_pct": cap_utilization_pct,
        "delegate_fee_pct": raw["delegate_fee_rate_raw"] / 1e6 * 100,

        # Per-strategy
        "strategies": [
            {
                "address": s["address"],
                "implementation": s.get("implementation"),
                "strategy_impl_name": STRATEGY_IMPL_NAMES.get(
                    (s.get("implementation") or "").lower(), "Unknown"
                ),
                "is_loan_manager": s["is_loan_manager"],
                "aum_usd": s["aum_raw"] / 10**USDC_DEC,
                "principal_out_usd": (s["principal_out_raw"] / 10**USDC_DEC
                                      if s["principal_out_raw"] is not None else None),
                "accounted_interest_usd": (s["accounted_interest_raw"] / 10**USDC_DEC
                                           if s["accounted_interest_raw"] is not None else None),
                # ⚠️ null here means the field does not exist on this strategy
                # type. It is not a zero and it is not a failed read.
                "principal_fields_supported": s["principal_out_raw"] is not None,
                "unrealized_losses_usd": s["unrealized_losses_raw"] / 10**USDC_DEC,
            } for s in raw["strategies"]
        ],

        # Governance
        "protocol_paused": raw["protocol_paused"],
        "governor": raw["governor"],
        "operational_admin": raw["operational_admin"],
        "security_admin": raw["security_admin"],
        "pool_delegate": raw["pool_delegate"],
        "pool_delegate_is_eoa": raw["pool_delegate_is_eoa"],
        "pool_delegate_firm_name": SYRUP_POOL_DELEGATE_FIRM.get(
            (raw["pool_delegate"] or "").lower()
        ),
        "pm_active": raw["pm_active"],
        "pm_configured": raw["pm_configured"],
        "min_cover_amount": raw["min_cover_amount_raw"] / 10**USDC_DEC,
        "pool_delegate_cover_usdc": raw["pd_cover_usdc_raw"] / 10**USDC_DEC,
        "pool_delegate_cover_eth": raw["pd_cover_eth_wei"] / 1e18,

        # Withdrawal queue (cycle-based; depth is in request slots)
        "wq_next_request_id": raw["wq_next_request_id"],
        "wq_last_request_id": raw["wq_last_request_id"],
    }


# ---------------------------------------------------------------------------
# Headline APY: syrupGlobals.apyTimeSeries → Maple REST → DefiLlama → constant
# ---------------------------------------------------------------------------
SEASON_CONSTANT_APY_PCT = 16.4  # last-resort fallback if every live source fails
APY_RAW_SCALE = 1e28             # Maple stores apy values percent-scaled by 1e28

def fetch_headline_apy(base_apy_pct):
    """Return (headline_apy_pct, source, breakdown).

    breakdown is {"core_apy_pct": float, "boost_apy_pct": float, "as_of": int}
    when source == "syrup_graphql"; None otherwise.

    Resolution order:
      1. syrupGlobals.apyTimeSeries(range:WEEK) — most-recent core+boost.
         Authoritative; matches Maple's app.
      2. Maple REST poolV2 endpoints — undocumented, fallback only.
      3. DefiLlama — only catches morpho-blue/fluid re-supplies (apy=0).
      4. Manual season constant — last resort.
    """
    # 1. syrupGlobals.apyTimeSeries — primary
    query = """
    {
      syrupGlobals {
        apyTimeSeries(range: WEEK) {
          coreApy
          boostApy
          timestamp
        }
      }
    }
    """
    try:
        r = requests.post(MAPLE_GRAPHQL, json={"query": query}, timeout=15,
                          headers={"User-Agent": "PegTracker/1.0"})
        r.raise_for_status()
        d = r.json()
        if "errors" not in d:
            ts = (((d.get("data") or {}).get("syrupGlobals") or {})
                  .get("apyTimeSeries") or [])
            if ts:
                latest = max(ts, key=lambda p: p.get("timestamp") or 0)
                core = int(latest.get("coreApy") or 0) / APY_RAW_SCALE
                boost = int(latest.get("boostApy") or 0) / APY_RAW_SCALE
                if core > 0:
                    return (
                        round(core + boost, 4),
                        "syrup_graphql",
                        {
                            "core_apy_pct": round(core, 4),
                            "boost_apy_pct": round(boost, 4),
                            "as_of": latest.get("timestamp"),
                        },
                    )
    except Exception as e:
        print(f"  syrupGlobals.apyTimeSeries fetch failed: "
              f"{type(e).__name__}: {str(e)[:120]}")

    # 2. Maple REST API — undocumented, kept as a hedge if GraphQL changes.
    candidates = [
        f"https://api.maple.finance/v2/poolV2/{POOL.lower()}",
        f"https://api.maple.finance/v2/pools/{POOL.lower()}",
        f"https://api.maple.finance/poolV2/{POOL.lower()}",
    ]
    for url in candidates:
        try:
            r = requests.get(url, timeout=10, headers={"User-Agent": "PegTracker/1.0"})
            if r.ok and r.headers.get("content-type", "").startswith("application/json"):
                d = r.json()
                for key in ("totalApy", "apy", "headlineApy"):
                    if isinstance(d.get(key), (int, float)) and d[key] > 0:
                        return d[key] * (100 if d[key] < 1.5 else 1), "maple_api", None
        except Exception:
            pass

    # 3. DefiLlama
    try:
        r = requests.get("https://yields.llama.fi/pools", timeout=15)
        if r.ok:
            for p in r.json().get("data", []):
                if p.get("symbol", "").lower() == "syrupusdc" and p.get("chain") == "Ethereum":
                    if p.get("project") in ("maple", "maple-finance", "syrup"):
                        apy = p.get("apy") or 0
                        if apy and apy > 0:
                            return apy, "defillama", None
    except Exception:
        pass

    # 4. Manual season constant — last resort
    return SEASON_CONSTANT_APY_PCT, "manual_season_constant", None


def fetch_apy_history():
    """Pull 30 daily syrupGlobals.apyTimeSeries entries for the sparkline.

    Returns {"range": "MONTH", "entries": [{timestamp, timestamp_iso,
    core_apy_pct, boost_apy_pct, total_apy_pct}], "source": ...}, or None on
    failure. syrupGlobals is brand-wide (same series shared by syrupUSDC and
    syrupUSDT — consistent with how the headline APY is sourced today)."""
    query = """
    {
      syrupGlobals {
        apyTimeSeries(range: MONTH) {
          coreApy
          boostApy
          timestamp
        }
      }
    }
    """
    try:
        r = requests.post(MAPLE_GRAPHQL, json={"query": query}, timeout=15,
                          headers={"User-Agent": "PegTracker/1.0"})
        r.raise_for_status()
        d = r.json()
        if "errors" in d:
            return None
        ts = (((d.get("data") or {}).get("syrupGlobals") or {})
              .get("apyTimeSeries") or [])
        ts = sorted(ts, key=lambda p: p.get("timestamp") or 0)
        entries = []
        for p in ts:
            t = p.get("timestamp")
            core = int(p.get("coreApy") or 0) / APY_RAW_SCALE
            boost = int(p.get("boostApy") or 0) / APY_RAW_SCALE
            entries.append({
                "timestamp": t,
                "timestamp_iso": (
                    datetime.fromtimestamp(t, tz=timezone.utc).isoformat()
                    if t else None
                ),
                "core_apy_pct": round(core, 4),
                "boost_apy_pct": round(boost, 4),
                "total_apy_pct": round(core + boost, 4),
            })
        return {"range": "MONTH", "entries": entries, "source": "syrup_graphql"}
    except Exception as e:
        print(f"  apy_history fetch failed: {type(e).__name__}: {str(e)[:120]}")
        return None


def fetch_withdrawal_queue_timing(vault):
    """Derive withdrawal-queue time-context from WithdrawalManager events.

    Returns dict with last_filled_*, next_request_age_seconds, and cycle_*.
    Cycle fields are always null because Maple Syrup pools use the QUEUE-based
    WithdrawalManager (impl 0xF95E…e967) — cycles don't apply. The field is
    kept in the schema so a future cyclical pool can populate it without
    breaking the renderer.

    Performance: walks back in CHUNK-block windows (10k each) and early-exits
    on the first chunk that contains a RequestProcessed log; in steady state
    the most-recent fill is in the latest chunk so this is one log call. For
    the next-request lookup, we filter by indexed requestId so a single wide
    range query is cheap."""
    print("\n--- Withdrawal queue timing ---")
    next_id = vault["wq_next_request_id"]
    last_id = vault["wq_last_request_id"]
    queue_empty = next_id > last_id
    wm = Web3.to_checksum_address(WITHDRAWAL_MANAGER)
    deadline = time.time() + WQ_TIMING_BUDGET_SECONDS

    # Degraded payload: same schema as the success result but all-null, plus a
    # flag so the renderer/downstream can show "timing unavailable" instead of
    # silently treating it as fresh-but-empty. Emitting this keeps the core
    # backing snapshot from being lost when the event scan is rate-limited.
    def _degraded(reason):
        print(f"  timing unavailable ({reason}) — emitting null timing fields", flush=True)
        return {
            "last_filled_timestamp_iso": None,
            "last_filled_age_seconds": None,
            "next_request_age_seconds": None,
            "current_cycle_start_timestamp_iso": None,
            "current_cycle_end_timestamp_iso": None,
            "cycle_duration_seconds": None,
            "timing_unavailable": True,
        }

    def _scan(w3):
        head = w3.eth.block_number
        out = {"last_filled_block": None, "last_filled_timestamp": None,
               "next_request_block": None, "next_request_timestamp": None}

        # 1. Reverse-scan for latest RequestProcessed; early-exit on first hit.
        cursor_end = head
        floor = max(head - WQ_HISTORY_BLOCK_WINDOW, 0)
        while cursor_end >= floor:
            if time.time() > deadline:
                raise RuntimeError("wq timing scan over budget (part 1)")
            cursor_start = max(cursor_end - CHUNK + 1, floor)
            logs = _get_logs_with_retry(w3, {
                "address": wm, "fromBlock": cursor_start, "toBlock": cursor_end,
                "topics": [T_REQUEST_PROCESSED],
            }, deadline=deadline)
            if logs:
                latest = max(
                    logs,
                    key=lambda l: (l["blockNumber"], l.get("logIndex") or 0),
                )
                blk = w3.eth.get_block(latest["blockNumber"])
                out["last_filled_block"] = latest["blockNumber"]
                out["last_filled_timestamp"] = blk["timestamp"]
                break
            cursor_end = cursor_start - 1
            time.sleep(CHUNK_SLEEP)

        # 2. If queue non-empty, find creation time of the head-of-queue request
        # via indexed requestId topic filter. Walk forward in CHUNK windows
        # (the filtered requestId is unique, so first hit is the answer); this
        # stays under provider getLogs range caps — a single floor→head call
        # exceeds PublicNode's 50k-block cap over the 250k history window.
        if not queue_empty:
            topic_id = "0x" + format(next_id, "064x")
            cursor_start = floor
            while cursor_start <= head:
                if time.time() > deadline:
                    raise RuntimeError("wq timing scan over budget (part 2)")
                cursor_end = min(cursor_start + CHUNK - 1, head)
                logs = _get_logs_with_retry(w3, {
                    "address": wm, "fromBlock": cursor_start, "toBlock": cursor_end,
                    "topics": [T_REQUEST_CREATED, topic_id],
                }, deadline=deadline)
                if logs:
                    first = min(
                        logs,
                        key=lambda l: (l["blockNumber"], l.get("logIndex") or 0),
                    )
                    blk = w3.eth.get_block(first["blockNumber"])
                    out["next_request_block"] = first["blockNumber"]
                    out["next_request_timestamp"] = blk["timestamp"]
                    break
                cursor_start = cursor_end + 1
                time.sleep(CHUNK_SLEEP)
        return out

    # Never let this peripheral enrichment fail the whole run: on a rate-limit /
    # exhausted-fallback (execute_with_fallback returns None and now propagates
    # the raised getLogs error after Fix A) or an over-budget scan, degrade to
    # null timing fields with a flag instead of aborting the backing snapshot.
    try:
        raw = execute_with_fallback(NETWORK, _scan)
    except Exception as e:
        return _degraded(f"{type(e).__name__}: {str(e)[:100]}")
    if not raw:
        return _degraded("event scan returned no data (all RPCs failed)")

    now = int(time.time())
    last_ts = raw.get("last_filled_timestamp")
    next_ts = raw.get("next_request_timestamp")

    result = {
        "last_filled_timestamp_iso": (
            datetime.fromtimestamp(last_ts, tz=timezone.utc).isoformat()
            if last_ts else None
        ),
        "last_filled_age_seconds": (now - last_ts) if last_ts else None,
        "next_request_age_seconds": (now - next_ts) if next_ts else None,
        # Maple Syrup uses queue-based WithdrawalManager (no cycles).
        "current_cycle_start_timestamp_iso": None,
        "current_cycle_end_timestamp_iso": None,
        "cycle_duration_seconds": None,
        "timing_unavailable": False,
    }
    print(f"  last_filled: {result['last_filled_timestamp_iso']} "
          f"(age={result['last_filled_age_seconds']}s)")
    print(f"  next_request_age: {result['next_request_age_seconds']}s "
          f"({'queue empty' if queue_empty else f'request #{next_id}'})")
    return result


# ---------------------------------------------------------------------------
# Peg / liquidity passthrough from PegTracker latest
# ---------------------------------------------------------------------------
def fetch_peg_and_liquidity():
    """Pull peg + DEX liquidity from peg_tracker_latest_usd.json (already collected)."""
    try:
        with open(PEG_TRACKER_LATEST, "r") as f:
            latest = json.load(f)
    except Exception:
        return None
    entry = latest.get("syrupUSDC")
    if not entry:
        return None

    market_price = entry.get("market_price")
    theoretical_price = entry.get("theoretical_price")
    peg_dev_pct = entry.get("peg_deviation")  # already percent (e.g. -0.034)

    return {
        "peg": {
            "market_price": market_price,
            "theoretical_price": theoretical_price,
            "premium_discount_pct": peg_dev_pct,
            "source": entry.get("source"),
            "timestamp": entry.get("timestamp"),
        },
        "yield_7d_apr_pct": (entry.get("7d_apr") or 0) * 100,
        "yield_24h_apr_pct": (entry.get("apr_24h") or 0) * 100,
        "total_supply_token_count": entry.get("total_supply"),
        "pool_tvl_usd": entry.get("pool_tvl"),
        "pool_count": entry.get("pool_count"),
        "liquidity": entry.get("liquidity"),
    }


# ---------------------------------------------------------------------------
# Phase 2 — Per-loan enumeration via OpenTermLoanFactory event scan
# ---------------------------------------------------------------------------
# ⚠️ ORDERED BY CAPABILITY, NOT LIVENESS — and the previous note here described
# a world that stopped existing. It said PublicNode serves wide getLogs and dRPC
# backs it up. Measured 2026-09-09, all three of the old providers refuse, each
# for a DIFFERENT reason, which is why they failed together and stalled both
# syrup feeds for two days:
#
#   publicnode   403 "Archive requests require a personal token"  (policy change)
#   drpc keyed   400 "Can't route your request to suitable provider"
#   alchemy      400 "…up to a 10 block range" on the free tier
#
# None of those is a rate limit. A rate limit eventually succeeds; a range cap
# and an access policy never do.
#
# Verified working over the OpenTerm factory, 18 public endpoints tried:
#   onfinality  500,000-block ranges     mevblocker  10,000-block cap
# Cross-checked by comparing (transactionHash, logIndex) SETS on one window, not
# counts — a provider that quietly returns FEWER logs would let discovery
# advance its checkpoint past loans it never saw. The sets matched.
GETLOGS_URLS = [
    "https://eth.api.onfinality.io/public",
    "https://rpc.mevblocker.io",
    "https://ethereum-rpc.publicnode.com",   # kept: may regain access, harmless last
]
CHUNK = 10_000  # onfinality serves far more; mevblocker caps here
MANAGER_CHUNK = 10_000  # ⚠️ was 10 — see below
# ⚠️ 10 BLOCKS WAS SIZED FOR A PROVIDER WE NO LONGER USE. The old note read
# "compatible with the narrowest configured provider", and that provider was
# Alchemy's free tier with its 10-block getLogs cap. Every endpoint in
# GETLOGS_URLS now serves at least 10,000.
#
# The cost of leaving it was not slowness, it was NEVER FINISHING:
# run_backing_analyzers.sh gives each analyzer `timeout 300`, and a 12,344-block
# backlog at 10 blocks per request is ~1,235 sequential calls. Observed live —
# the factory stream cleared its whole backlog in one call while the manager
# stream advanced 100 blocks before the timeout. Fixing the RPCs alone would
# have left the feed stalled with a green-looking cause.
#
# Verified on the live manager address at this size: 10,000 blocks returns 2
# PaymentAdded logs, so the range is nowhere near a response-size limit.
CHUNK_SLEEP = 0.05
# Retry budget for a single getLogs call before we give up on the current
# provider and let execute_with_fallback rotate. Kept small on purpose: once a
# working wide-getLogs fallback exists (dRPC), hammering a rate-limited primary
# (PublicNode 403s) is low-value — better to yield fast. 2 attempts (1 retry)
# with capped+jittered backoff gives a ~1.5s worst-case give-up vs the old ~15s.
GETLOGS_MAX_RETRIES = 2
GETLOGS_BACKOFF_CAP = 3  # seconds, before jitter
T_INSTANCE_DEPLOYED = "0x" + keccak(b"InstanceDeployed(uint256,address,bytes)").hex()
T_PAYMENT_ADDED = "0x" + keccak(b"PaymentAdded(address,uint256,uint256,uint256,uint256)").hex()
MANAGER_BASELINE_BLOCK = 25_918_000
MANAGER_BASELINE_LOANS = [
    "0x9888486E7547B50F0366A8Ca262f20D4BABD1735",
    "0xeB1284bf810631eFa9AC913944095b5d8180D9F5",
    "0xeb9aCf026fcD39A580A80A232cED1361d50201f6",
    "0x43D2329DBd53F801eE8CEee3E86bd0882F244a07",
]


def _get_logs_with_retry(w3, params, max_retries=GETLOGS_MAX_RETRIES, deadline=None):
    """Fetch logs with bounded retries.

    Contract: a SUCCESSFUL call returns the (possibly empty) log list — an empty
    list means "no matching logs in this range". An EXHAUSTED-retry failure
    RAISES the last exception so callers can distinguish a rate-limited/failed
    chunk from a genuinely empty one (e.g. so execute_with_fallback can rotate
    providers instead of silently marching a forward walk to timeout). Callers
    that want the old swallow-and-continue behaviour must catch explicitly.

    Backoff is capped and jittered, and we never sleep after the final attempt —
    a rate-limited primary should yield to the fallback fast rather than burning
    an escalating retry ladder. If `deadline` (epoch seconds) is given, we stop
    retrying and raise as soon as it is exceeded rather than sleeping into it.
    """
    last_exc = None
    for attempt in range(max_retries):
        try:
            return w3.eth.get_logs(params)
        except Exception as e:
            last_exc = e
            # Final attempt: don't sleep, just raise so the manager rotates now.
            if attempt == max_retries - 1:
                break
            # Capped exponential backoff + jitter (avoid lockstep re-tripping the
            # per-IP rate limit on the next call).
            wait = min(2 ** attempt, GETLOGS_BACKOFF_CAP) + random.uniform(0, 0.5)
            if deadline is not None and time.time() + wait > deadline:
                print(f"    getLogs failed and over time budget — aborting: "
                      f"{type(e).__name__}: {str(e)[:100]}", flush=True)
                raise
            print(f"    retry {attempt + 1}/{max_retries} in {wait:.1f}s: {type(e).__name__}: {str(e)[:100]}",
                  flush=True)
            time.sleep(wait)
    # Retries exhausted: surface the failure rather than masking it as "no logs".
    raise last_exc


def _getlogs_rotating(params, deadline=None):
    """eth_getLogs through the rotating RPC manager so a rate-limited/failed
    primary (PublicNode) falls back to the next wide-getLogs provider.

    dRPC serves up to the 10k-block CHUNK (verified 2026-06); Alchemy free tier
    hard-caps getLogs at 10 blocks but its range error is retriable, so the
    manager rotates over it rather than stalling. Returns the (possibly empty)
    log list on success, or None if every provider failed (the
    execute_with_fallback contract)."""
    # ⚠️ Rotates over GETLOGS-CAPABLE endpoints rather than the generic Ethereum
    # pool. Routing wide log reads through providers chosen for eth_call is what
    # stalled this feed: all three refused, correctly, and the analyzer refused
    # to publish — the failure handling was right and the doors were wrong.
    last = None
    for url in GETLOGS_URLS:
        try:
            w3 = Web3(Web3.HTTPProvider(url, request_kwargs={"timeout": 30}))
            return _get_logs_with_retry(w3, params, deadline=deadline)
        except Exception as e:
            last = e
            print(f"    getLogs via {url.split('//')[1][:34]} failed: {str(e)[:80]}")
    if last:
        print(f"    all {len(GETLOGS_URLS)} getLogs endpoints failed")
    # ⚠️ None, never []. An empty list reads as "no loans here" and would let the
    # checkpoint advance past a range nobody actually read.
    return None


def load_loan_cache():
    if os.path.exists(LOAN_CACHE_PATH):
        try:
            with open(LOAN_CACHE_PATH, "r") as f:
                cache = json.load(f)
                cache.setdefault("factory_last_block", cache.get("last_block", FACTORY_DEPLOY_BLOCK - 1))
                cache.setdefault("manager_last_block", MANAGER_BASELINE_BLOCK)
                cache.setdefault("manager_loans", [])
                if cache["manager_last_block"] < MANAGER_BASELINE_BLOCK:
                    cache["manager_last_block"] = MANAGER_BASELINE_BLOCK
                known = {a.lower() for a in cache["manager_loans"]}
                cache["manager_loans"].extend(
                    a for a in MANAGER_BASELINE_LOANS if a.lower() not in known)
                return cache
        except Exception:
            pass
    return {"last_block": FACTORY_DEPLOY_BLOCK - 1,
            "factory_last_block": FACTORY_DEPLOY_BLOCK - 1,
            "manager_last_block": MANAGER_BASELINE_BLOCK,
            "loans": [], "manager_loans": list(MANAGER_BASELINE_LOANS)}


def save_loan_cache(cache):
    tmp = LOAN_CACHE_PATH + ".tmp"
    with open(tmp, "w") as f:
        json.dump(cache, f, indent=2)
    os.replace(tmp, LOAN_CACHE_PATH)


def discover_loans():
    """Union factory deployments with authoritative LoanManager PaymentAdded events."""
    print("\n--- Loan discovery (event scan) ---")
    cache = load_loan_cache()
    head = execute_with_fallback(NETWORK, lambda w3: w3.eth.block_number)
    if not head:
        print("  could not fetch head block from any RPC — skipping loan discovery this run", flush=True)
        return cache
    streams = (
        ("factory", Web3.to_checksum_address(OPEN_TERM_FACTORY), T_INSTANCE_DEPLOYED, 2,
         "factory_last_block", "loans"),
        ("manager", Web3.to_checksum_address(STRATEGY_0), T_PAYMENT_ADDED, 1,
         "manager_last_block", "manager_loans"),
    )
    for label, address, topic, address_topic, checkpoint_key, loans_key in streams:
        b = cache[checkpoint_key] + 1
        if b > head:
            continue
        chunk_size = MANAGER_CHUNK if label == "manager" else CHUNK
        total_chunks = max(1, (head - b) // chunk_size + 1)
        print(f"  Scanning {label} blocks {b:,} → {head:,} ({total_chunks} chunks)")
        while b <= head:
            end = min(b + chunk_size - 1, head)
            params = {"address": address, "fromBlock": b, "toBlock": end, "topics": [topic]}
            try:
                logs = _getlogs_rotating(params)
                if logs is None:
                    raise RuntimeError("all RPCs failed for chunk")
            except Exception as e:
                save_loan_cache(cache)
                raise RuntimeError(
                    f"{label} loan discovery failed at blocks {b}-{end}; checkpoint remains "
                    f"{cache[checkpoint_key]}"
                ) from e
            known = {a.lower() for a in cache[loans_key]}
            for log in logs:
                raw = log["topics"][address_topic]
                topic_hex = raw.hex() if hasattr(raw, "hex") else raw
                if not topic_hex.startswith("0x"):
                    topic_hex = "0x" + topic_hex
                addr = Web3.to_checksum_address("0x" + topic_hex[-40:])
                if addr.lower() not in known:
                    cache[loans_key].append(addr)
                    known.add(addr.lower())
            cache[checkpoint_key] = end
            if label == "factory":
                cache["last_block"] = end
            save_loan_cache(cache)
            b = end + 1
            time.sleep(CHUNK_SLEEP)
    union = {a.lower(): a for a in cache["loans"]}
    union.update({a.lower(): a for a in cache["manager_loans"]})
    cache["loans"] = list(union.values())
    save_loan_cache(cache)
    print(f"  COMPLETE: {len(cache['manager_loans'])} manager-event loans; {len(cache['loans'])} union loans")
    return cache


def _encode_call(target, abi, fn_name, args=None):
    """Build a Multicall3 tuple (target, allowFailure=True, callData)."""
    c = Web3().eth.contract(address=Web3.to_checksum_address(target), abi=abi)
    # web3.py renamed encodeABI → encode_abi in v6. Support both.
    if hasattr(c, "encode_abi"):
        data = c.encode_abi(fn_name, args=args or [])
    else:
        data = c.encodeABI(fn_name=fn_name, args=args or [])
    return (Web3.to_checksum_address(target), True, bytes.fromhex(data[2:]))


def _multicall(w3, calls):
    """Execute a batch of multicall tuples; auto-chunk to MULTICALL_CHUNK per call."""
    mc = w3.eth.contract(address=Web3.to_checksum_address(MULTICALL3), abi=MULTICALL3_ABI)
    results = []
    for i in range(0, len(calls), MULTICALL_CHUNK):
        chunk = calls[i:i + MULTICALL_CHUNK]
        results.extend(mc.functions.aggregate3(chunk).call())
    return results


def _decode_single(abi, fn_name, raw):
    """Decode a single multicall3 returnData using web3's contract decoder."""
    c = Web3().eth.contract(abi=abi)
    return c.decode_function_result(fn_name, raw) if False else c.functions[fn_name]().decode_output(raw)


# Per-loan view methods we want for each active loan, in the order the
# multicall returns are decoded. Keeping the type-only schema here lets us
# decode without re-creating contract objects per call.
LOAN_VIEW_METHODS = [
    ("borrower", "address"),
    ("principal", "uint256"),
    ("interestRate", "uint256"),
    ("paymentInterval", "uint256"),
    ("paymentDueDate", "uint256"),
    ("dateFunded", "uint256"),
    ("isImpaired", "bool"),
    ("isCalled", "bool"),
    ("isInDefault", "bool"),
    ("noticePeriod", "uint256"),
    ("gracePeriod", "uint256"),
    ("lateInterestPremiumRate", "uint256"),
]


def filter_active_loans(cache):
    """Filter cached loans to those active in Strategy 0 (current LoanManager).

    Uses Multicall3.aggregate3 to batch RPC calls — drops what would be
    thousands of serial requests to a handful of batched ones.
    """
    if not cache["loans"]:
        return []

    print("\n--- Filtering active loans (Multicall3 batched) ---")
    loan_addrs = list(cache["loans"])
    print(f"  Checking {len(loan_addrs)} cached loans against Strategy 0.paymentFor()")

    from eth_abi import decode as abi_decode

    def _filter(w3):
        # Stage 1: batch all paymentFor() calls
        calls = [_encode_call(STRATEGY_0, ABI_STRATEGY, "paymentFor", [a]) for a in loan_addrs]
        results = _multicall(w3, calls)
        active_addrs = []
        for addr, (success, ret) in zip(loan_addrs, results):
            if not success or not ret:
                continue
            try:
                _pf, _df, start_date, _ir = abi_decode(["uint24", "uint24", "uint40", "uint168"], ret)
            except Exception:
                continue
            if start_date > 0:
                active_addrs.append(addr)
        print(f"  Stage 1 (paymentFor filter): {len(active_addrs)} loans active in Strategy 0")
        return active_addrs

    active_addrs = execute_with_fallback(NETWORK, _filter) or []
    if not active_addrs:
        return []

    def _read_loans(w3):
        # Stage 2: batched per-loan reads
        calls = []
        for addr in active_addrs:
            for fn_name, _t in LOAN_VIEW_METHODS:
                calls.append(_encode_call(addr, ABI_LOAN, fn_name))
        results = _multicall(w3, calls)
        n_methods = len(LOAN_VIEW_METHODS)
        records = []
        for i, addr in enumerate(active_addrs):
            chunk = results[i * n_methods:(i + 1) * n_methods]
            decoded = {}
            ok = True
            for (fn_name, t), (success, ret) in zip(LOAN_VIEW_METHODS, chunk):
                if not success or not ret:
                    ok = False
                    break
                try:
                    val = abi_decode([t], ret)[0]
                except Exception:
                    ok = False
                    break
                decoded[fn_name] = val
            if not ok:
                continue
            principal = decoded["principal"]
            if principal == 0:
                continue  # repaid
            record = {
                "loan_addr": Web3.to_checksum_address(addr),
                "borrower": Web3.to_checksum_address(decoded["borrower"]),
                "principal": principal / 10**USDC_DEC,
                "rate_pct": decoded["interestRate"] / 1e6 * 100,
                "payment_interval_days": decoded["paymentInterval"] / 86400,
                "payment_due_date": decoded["paymentDueDate"],
                "date_funded": decoded["dateFunded"],
                "is_impaired": decoded["isImpaired"],
                "is_called": decoded["isCalled"],
                "is_in_default": decoded["isInDefault"],
                "notice_period_h": decoded["noticePeriod"] / 3600,
                "grace_period_h": decoded["gracePeriod"] / 3600,
                "late_interest_premium_rate_pct": decoded["lateInterestPremiumRate"] / 1e6 * 100,
            }
            if record["is_in_default"]:
                record["status"] = "default"
            elif record["is_called"]:
                record["status"] = "called"
            elif record["is_impaired"]:
                record["status"] = "impaired"
            else:
                record["status"] = "healthy"
            records.append(record)
        return records

    active = execute_with_fallback(NETWORK, _read_loans) or []
    print(f"  Stage 2 (loan reads): {len(active)} active loans (after principal>0 filter)")
    return active


def fetch_aum_history():
    """Pool-scoped 30-day AUM time series via Maple GraphQL.

    Returns a dict suitable for direct emission as `asset_specific.aum_history`,
    or None on any failure (renderer should graceful-degrade).

    Field shape uses the pool-scoped poolV2(id:..).aumTimeSeries — note the
    Amount type requires `{ usd }` selectors (8-decimal-scaled USD), distinct
    from syrupGlobals.aumTimeSeries which exposes a flat *Usd field shape.
    """
    print("\n--- Maple GraphQL AUM history ---")
    query = """
    {
      poolV2(id:"%s") {
        aumTimeSeries(range: MONTH) {
          timestamp
          assets { usd }
          assetsInStrategies { usd }
          loans { usd }
          collateral { usd }
        }
      }
    }
    """ % POOL.lower()

    try:
        r = requests.post(MAPLE_GRAPHQL, json={"query": query}, timeout=15,
                          headers={"User-Agent": "PegTracker/1.0"})
        r.raise_for_status()
        d = r.json()
        if "errors" in d:
            print(f"  GraphQL errors: {d['errors'][:1]}")
            return None
        pts = (((d.get("data") or {}).get("poolV2") or {})
               .get("aumTimeSeries") or [])
        if not pts:
            print("  no AUM points returned")
            return None
    except Exception as e:
        print(f"  fetch failed: {type(e).__name__}: {str(e)[:120]}")
        return None

    entries = []
    for p in pts:
        def _u(field):
            obj = p.get(field) or {}
            raw = obj.get("usd")
            return int(raw) / 1e8 if raw else 0.0

        a = _u("assets")
        s = _u("assetsInStrategies")
        l = _u("loans")
        c = _u("collateral")
        denom = a + s + l
        entries.append({
            "timestamp": p["timestamp"],
            "assets_usd": round(a, 2),
            "assets_in_strategies_usd": round(s, 2),
            "loans_usd": round(l, 2),
            "collateral_usd": round(c, 2),
            "collateral_ratio_pct": round(c / l * 100, 2) if l > 0 else None,
            "deployment_pct": round(l / denom * 100, 2) if denom > 0 else None,
        })

    entries.sort(key=lambda e: e["timestamp"])
    latest = entries[-1]
    print(f"  {len(entries)} daily points, latest "
          f"loans=${latest['loans_usd']/1e6:.1f}M  collat=${latest['collateral_usd']/1e6:.1f}M  "
          f"cr={latest['collateral_ratio_pct']}%  deploy={latest['deployment_pct']}%")

    return {
        "source": "syrup_graphql_aum_time_series",
        "range": "MONTH",
        "as_of": latest["timestamp"],
        "entries": entries,
    }


def fetch_loan_collateral_map():
    """GraphQL → ({loan_addr_lower: collateral_dict}, pool_aggregates, source_status).

    source_status is 'maple_graphql' on success, 'unavailable' on any failure.
    Pool aggregates carry collateralRatio (×1e6) and collateralValue (USDC's 6 dec)
    for cross-checking against per-loan computations.
    """
    print("\n--- Maple GraphQL collateral enrichment ---")
    query = """
    {
      poolV2(id:"%s") {
        collateralRatio
        collateralValue
        numActiveLoans
        openTermLoans(first:500) {
          id
          collateral {
            asset
            assetAmount
            currentAssetAmount
            initialAssetAmount
            initialLevel
          }
          loanMeta { type }
        }
      }
    }
    """ % POOL.lower()
    try:
        r = requests.post(MAPLE_GRAPHQL, json={"query": query}, timeout=15,
                          headers={"User-Agent": "PegTracker/1.0"})
        r.raise_for_status()
        d = r.json()
        if "errors" in d:
            print(f"  GraphQL errors: {d['errors'][:1]}")
            return {}, {}, "unavailable"
        pool = (d.get("data") or {}).get("poolV2") or {}
        loans_raw = pool.get("openTermLoans") or []
        coll_map = {}
        for l in loans_raw:
            if not l.get("collateral"):
                continue
            entry = dict(l["collateral"])
            entry["loan_meta_type"] = ((l.get("loanMeta") or {}).get("type"))
            entry["metadata_observed_at"] = now_iso()
            coll_map[l["id"].lower()] = entry
        agg = {
            "collateral_ratio_raw": pool.get("collateralRatio"),
            "collateral_value_raw": pool.get("collateralValue"),
            "num_active_loans": pool.get("numActiveLoans"),
        }
        print(f"  GraphQL: {len(loans_raw)} loans returned, {len(coll_map)} with collateral; "
              f"poolCR={agg['collateral_ratio_raw']}, poolCV={agg['collateral_value_raw']}")
        return coll_map, agg, "maple_graphql"
    except Exception as e:
        print(f"  GraphQL fetch failed: {type(e).__name__}: {str(e)[:120]}")
        return {}, {}, "unavailable"


def _fetch_chainlink_prices(feed_assets):
    """Try latestAnswer/decimals on each Chainlink feed. Returns {asset: price}
    for successes only — failures are silently dropped so the caller can fall
    back to CoinGecko."""
    if not feed_assets:
        return {}

    def _q(w3):
        out = {}
        for asset in feed_assets:
            try:
                agg = w3.eth.contract(
                    Web3.to_checksum_address(CHAINLINK_FEEDS[asset]), abi=ABI_AGG)
                ans = agg.functions.latestAnswer().call()
                dec = agg.functions.decimals().call()
                if ans > 0:
                    out[asset] = ans / 10**dec
            except Exception as e:
                print(f"  Chainlink {asset}: {type(e).__name__}: {str(e)[:80]}")
        return out

    return execute_with_fallback(NETWORK, _q) or {}


def _fetch_coingecko_prices(assets):
    """Single batched call to CoinGecko simple/price for assets with known IDs.
    Returns {asset: price}. Free-tier compatible; one call per cron cycle."""
    cg_pairs = [(a, COINGECKO_IDS[a]) for a in assets if a in COINGECKO_IDS]
    if not cg_pairs:
        return {}
    ids = ",".join(sorted({cg_id for _, cg_id in cg_pairs}))
    try:
        r = requests.get(
            COINGECKO_URL,
            params={"ids": ids, "vs_currencies": "usd"},
            timeout=10,
            headers={"User-Agent": "PegTracker/1.0"},
        )
        r.raise_for_status()
        data = r.json()
        out = {}
        for asset, cg_id in cg_pairs:
            v = (data.get(cg_id) or {}).get("usd")
            if isinstance(v, (int, float)) and v > 0:
                out[asset] = float(v)
        return out
    except Exception as e:
        print(f"  CoinGecko fetch failed: {type(e).__name__}: {str(e)[:120]}")
        return {}


def fetch_collateral_oracle_prices(needed_assets):
    """Returns {asset: (price, source)} for needed_assets.

    Source ∈ {"chainlink", "coingecko", "unavailable"}. Stablecoin handling
    happens inline in enrich_loans_with_collateral (source "peg_assumed").
    Resolution order per asset: Chainlink feed → CoinGecko → unavailable.
    """
    needed = {a for a in needed_assets if a and a not in STABLECOIN_ASSETS}
    if not needed:
        return {}

    chainlink = _fetch_chainlink_prices([a for a in needed if a in CHAINLINK_FEEDS])
    out = {a: (p, "chainlink") for a, p in chainlink.items()}

    # Apply BTC-peg aliases BEFORE CoinGecko fallback so cbBTC/LBTC inherit a
    # working Chainlink price instead of each issuing their own CoinGecko call.
    if "BTC" in out:
        out.setdefault("cbBTC", out["BTC"])
        out.setdefault("LBTC", out["BTC"])

    # Fall back to CoinGecko for anything still missing (Chainlink revert, no
    # feed, or feed returned 0).
    missing = [a for a in needed if a not in out]
    coingecko = _fetch_coingecko_prices(missing)
    for a, p in coingecko.items():
        out[a] = (p, "coingecko")

    if out:
        summary = ", ".join(f"{a}=${p:,.2f}({s})" for a, (p, s) in sorted(out.items()))
        print(f"  oracle prices: {summary}")
    unavailable = [a for a in needed if a not in out]
    if unavailable:
        print(f"  oracle prices unavailable: {', '.join(sorted(unavailable))}")
    return out


def _stablecoin_prices_from_peg(peg):
    """Derive {asset: $1.00 ± peg deviation} from peg_tracker_latest_usd entries.

    Only used as a refinement; defaults to $1.00 for known stablecoins below.
    """
    out = {}
    if not peg or not isinstance(peg, dict):
        return out
    # peg passthrough only carries this pool's own peg, not arbitrary stables.
    # Future: lift other entries from peg_tracker_latest_usd if needed.
    return out


def enrich_loans_with_collateral(loans, coll_map, oracle_prices):
    """Attach `collateral` sub-object to each loan in-place.

    `oracle_prices` maps asset → (price, source). Stablecoins resolve inline
    to ($1.00, "peg_assumed"). Sets collateral=None when GraphQL has no
    record for the loan — renderer should display a placeholder for those.
    """
    for loan in loans:
        coll = coll_map.get(loan["loan_addr"].lower())
        if not coll or not coll.get("asset"):
            loan["collateral"] = None
            loan["loan_meta_type"] = (coll or {}).get("loan_meta_type")
            loan["position_type"] = "loan"
            continue
        asset = coll["asset"]
        decimals = COLLATERAL_DECIMALS.get(asset, 18)
        raw = int(coll.get("currentAssetAmount") or 0)
        amount = raw / (10 ** decimals)

        # Detect Maple GraphQL data anomaly: currentAssetAmount near-zero while
        # assetAmount (required posting) is sized for the loan. Observed on some
        # at-par USTB/USDC loans where the per-loan collateral schema doesn't
        # reflect actual on-chain state. Treat as data-unavailable so the loan
        # is excluded from buffer-health stats rather than scoring as -100pp.
        required_raw = int(coll.get("assetAmount") or 0)
        usd_anomaly = required_raw > 0 and raw < required_raw * 0.05

        if usd_anomaly:
            price, usd_source = None, "data_anomaly"
        elif asset in STABLECOIN_ASSETS:
            price, usd_source = 1.0, "peg_assumed"
        else:
            entry = oracle_prices.get(asset)
            if entry is None:
                price, usd_source = None, "unavailable"
            else:
                price, usd_source = entry
        usd = amount * price if price is not None else None

        # initialLevel is scaled ×1e6 (1_000_000 = 100%). Convert to percent.
        init_level_pct = (coll.get("initialLevel") or 0) / 10000.0
        principal = loan["principal"]
        current_level_pct = (
            usd / principal * 100 if (usd is not None and principal > 0) else None
        )
        is_at_par = (
            init_level_pct > 0
            and init_level_pct <= AT_PAR_INIT_LEVEL_THRESHOLD_PCT
        )
        category = COLLATERAL_CATEGORY.get(asset, "unknown")

        # buffer_pp = headroom against funding-time required collateralization.
        # Negative values flag loans below their init level (delegate discretion
        # to call hasn't been exercised — see buffer-health risk flag).
        buffer_pp = (
            round(current_level_pct - init_level_pct, 2)
            if current_level_pct is not None and init_level_pct
            else None
        )

        loan["metadata_observed_at"] = coll.get("metadata_observed_at")
        loan_meta_type = coll.get("loan_meta_type")
        loan["loan_meta_type"] = loan_meta_type
        loan["collateral"] = {
            "asset": asset,
            "amount": round(amount, 6),
            "amount_decimal_unit": asset,
            "usd": round(usd, 2) if usd is not None else None,
            "usd_source": usd_source,
            "init_level_pct": round(init_level_pct, 2),
            "current_level_pct": round(current_level_pct, 2)
                if current_level_pct is not None else None,
            "buffer_pp": buffer_pp,
            "is_at_par": is_at_par,
            "category": category,
            "issuer": COLLATERAL_ISSUER.get(asset),
            "data_source": "maple_graphql",
            "source_observed_at": coll.get("metadata_observed_at"),
            "raw_source": {k: coll.get(k) for k in ("assetAmount", "currentAssetAmount", "initialAssetAmount", "initialLevel")},
            "decimals_used": decimals,
            "price_usd_used": price,
            "valuation_observed_at": now_iso(),
            "valuation_scope": "GraphQL currentAssetAmount times producer price; no matched custodian allocation",
        }
        loan["position_type"] = classify_position_type(
            init_level_pct, category, loan_meta_type
        )


def fetch_liquidity_custody(loans):
    """Attach `custody` block to each loan classified as Liquidity.

    Looks up SYRUP_LIQUIDITY_CUSTODY by (asset_slug, collateral_asset,
    borrower_lower). For each match, reads on-chain:
      - eth_getCode(custody) → is_eoa (== 0x)
      - ERC20.balanceOf(custody) → asset_balance_native
      - asset_balance_usd = native * LIQUIDITY_NAV_USD.get(asset, 1.0)

    Solana-chain custodies are emitted with a stub (chain="solana", live read
    deferred). Loans with no custody mapping get custody=None.
    """
    targets = []  # list of (loan, custody_meta)
    for loan in loans:
        if loan.get("position_type") != "liquidity":
            continue
        coll = loan.get("collateral") or {}
        asset = coll.get("asset")
        borrower = (loan.get("borrower") or "").lower()
        meta = SYRUP_LIQUIDITY_CUSTODY.get((ASSET_SLUG, asset, borrower))
        if not meta:
            loan["custody"] = None
            continue
        targets.append((loan, asset, meta))

    if not targets:
        return

    # On-chain reads only for ethereum-chain custodies; defer solana.
    eth_targets = [(l, a, m) for (l, a, m) in targets
                   if m.get("chain") == "ethereum"]
    sol_targets = [(l, a, m) for (l, a, m) in targets
                   if m.get("chain") == "solana"]

    print(f"\n--- Liquidity custody verification ({len(eth_targets)} eth, "
          f"{len(sol_targets)} sol-deferred) ---")

    def _q(w3):
        out = {}
        for (loan, asset, meta) in eth_targets:
            cust = Web3.to_checksum_address(meta["custody_addr"])
            token_addr = LIQUIDITY_ASSET_TOKENS.get(asset)
            decimals = LIQUIDITY_ASSET_DECIMALS.get(asset, 6)
            try:
                is_eoa = len(w3.eth.get_code(cust)) == 0
            except Exception:
                is_eoa = None
            try:
                token = w3.eth.contract(
                    Web3.to_checksum_address(token_addr), abi=ABI_ERC20)
                bal_raw = token.functions.balanceOf(cust).call()
                bal_native = bal_raw / (10 ** decimals)
            except Exception:
                bal_native = None
            out[id(loan)] = {"is_eoa": is_eoa, "bal_native": bal_native}
        return out

    measurements = execute_with_fallback(NETWORK, _q) or {}

    for (loan, asset, meta) in eth_targets:
        m = measurements.get(id(loan), {})
        nav = LIQUIDITY_NAV_USD.get(asset, 1.0)
        bal = m.get("bal_native")
        loan["custody"] = {
            "address": meta["custody_addr"],
            "chain": meta["chain"],
            "venue": meta.get("venue"),
            "is_eoa": m.get("is_eoa"),
            "asset_balance_native": (round(bal, 6)
                                     if bal is not None else None),
            "asset_balance_usd": (round(bal * nav, 2)
                                  if bal is not None else None),
            "asset_nav_usd": nav,
        }
        print(f"  {asset} @ {meta['custody_addr'][:10]}...: "
              f"is_eoa={m.get('is_eoa')} bal={bal} → "
              f"${(bal or 0) * nav:,.0f}")

    for (loan, asset, meta) in sol_targets:
        loan["custody"] = {
            "address": meta["custody_addr"],
            "chain": meta["chain"],
            "venue": meta.get("venue"),
            "is_eoa": None,
            "asset_balance_native": None,
            "asset_balance_usd": None,
            "asset_nav_usd": LIQUIDITY_NAV_USD.get(asset, 1.0),
            "note": "Solana RPC read deferred; trust Maple UI for balance",
        }


def build_collateral_summary(loans, pool_agg, source_status, unrealized_losses=0):
    """Aggregate loan-level collateral into the dashboard summary block.

    `unrealized_losses` is the pool-level on-chain loss figure — the
    authoritative loss-recognition alarm. It's threaded in so the Set A
    "below 100%" tier can be split into corroborated (concurrent protocol flags)
    vs uncorroborated (unresolved source disagreement) buckets.
    """
    timestamp = now_iso()

    if source_status == "unavailable":
        return {
            "by_asset": [],
            "set_a_overcollateralized": None,
            "set_b_at_par": None,
            "pool_collateral_ratio_pct": None,
            "pool_collateral_value_usd": None,
            "data_source": "unavailable",
            "data_source_timestamp": timestamp,
        }

    from collections import defaultdict
    by_asset = defaultdict(lambda: {"loans": 0, "principal_usd": 0.0,
                                    "init_levels": []})
    for l in loans:
        c = l.get("collateral")
        if not c:
            continue
        a = c["asset"]
        by_asset[a]["loans"] += 1
        by_asset[a]["principal_usd"] += l["principal"]
        if c["init_level_pct"]:
            by_asset[a]["init_levels"].append(c["init_level_pct"])

    enriched = [l for l in loans if l.get("collateral")]
    total_principal = sum(l["principal"] for l in enriched)

    by_asset_list = []
    for a, d in by_asset.items():
        levels = d["init_levels"]
        by_asset_list.append({
            "asset": a,
            "loans": d["loans"],
            "principal_usd": round(d["principal_usd"], 2),
            "pct_of_book": round(d["principal_usd"] / total_principal * 100, 2)
                if total_principal > 0 else 0,
            "init_level_pct_min": round(min(levels), 2) if levels else None,
            "init_level_pct_max": round(max(levels), 2) if levels else None,
            "category": COLLATERAL_CATEGORY.get(a, "unknown"),
            "issuer": COLLATERAL_ISSUER.get(a),
        })
    by_asset_list.sort(key=lambda x: -x["principal_usd"])

    set_a = [l for l in enriched if not l["collateral"]["is_at_par"]]
    set_b = [l for l in enriched if l["collateral"]["is_at_par"]]
    set_a_principal = sum(l["principal"] for l in set_a)
    set_b_principal = sum(l["principal"] for l in set_b)
    set_a_wavg = (
        sum(l["principal"] * l["collateral"]["init_level_pct"] for l in set_a)
        / set_a_principal
    ) if set_a_principal > 0 else None

    set_b_named_issuers = sorted({
        f"{l['collateral']['issuer']} ({l['collateral']['asset']})"
        for l in set_b
        if l["collateral"].get("issuer") and l["collateral"]["issuer"] != "—"
    })

    largest_b = max(set_b, key=lambda l: l["principal"]) if set_b else None
    largest_b_principal = largest_b["principal"] if largest_b else 0
    largest_b_pct = (
        largest_b_principal / total_principal * 100 if total_principal > 0 else 0
    )

    # Buffer-health aggregates (only loans where buffer_pp is computable —
    # i.e. current_level_pct is non-null, which requires a USD price).
    with_buffer = [l for l in enriched
                   if l["collateral"].get("buffer_pp") is not None]
    below = [l for l in with_buffer if l["collateral"]["buffer_pp"] < 0]
    if with_buffer:
        wsum = sum(l["principal"] for l in with_buffer)
        wtd_avg_buffer = (
            sum(l["principal"] * l["collateral"]["buffer_pp"]
                for l in with_buffer) / wsum
        ) if wsum > 0 else None
    else:
        wtd_avg_buffer = None

    tightest = min(
        with_buffer,
        key=lambda l: l["collateral"]["buffer_pp"],
        default=None,
    )
    tightest_block = None
    if tightest:
        tc = tightest["collateral"]
        tightest_block = {
            "loan_addr":         tightest["loan_addr"],
            "borrower":          tightest["borrower"],
            "principal_usd":     round(tightest["principal"], 2),
            "asset":             tc["asset"],
            "init_level_pct":    tc["init_level_pct"],
            "current_level_pct": tc["current_level_pct"],
            "buffer_pp":         tc["buffer_pp"],
            "points_above_par":  round(tc["current_level_pct"] - 100.0, 2),
        }

    # Set A (overcollateralized crypto) collateralization-health tiers, measured
    # against an ABSOLUTE current_level_pct floor (proximity to principal), not
    # the funding-time init level. Set B (at-par) is excluded — it sits at ~100%
    # by construction. See SET_A_*_LEVEL_PCT for rationale.
    set_a_with_level = [
        l for l in set_a
        if l["collateral"].get("current_level_pct") is not None
    ]
    set_a_crit = [l for l in set_a_with_level
                  if l["collateral"]["current_level_pct"] < SET_A_CRIT_LEVEL_PCT]
    set_a_warn = [l for l in set_a_with_level
                  if SET_A_CRIT_LEVEL_PCT <= l["collateral"]["current_level_pct"]
                  < SET_A_WARN_LEVEL_PCT]

    # Protocol loss/status flags are separate accounting evidence. Their absence
    # neither verifies custody nor resolves a low collateral reading. The legacy
    # corroboration buckets indicate concurrent protocol flags, not proved loss
    # allocation to a particular row.
    pool_has_loss = (unrealized_losses or 0) > 0

    def _loan_corroborated(l):
        return bool(l.get("is_impaired") or l.get("is_called")
                    or l.get("is_in_default"))

    # Stamp the same verdict on each source row so consumers do not have to
    # reconstruct this gate from pool state plus three loan flags.
    for loan in loans:
        collateral = loan.get("collateral")
        if not collateral:
            continue
        level = collateral.get("current_level_pct")
        suspect_read = (
            isinstance(level, (int, float))
            and level < 100.0
            and not collateral.get("is_at_par")
        )
        loan_flagged = _loan_corroborated(loan)
        corroborated = not suspect_read or pool_has_loss or loan_flagged
        collateral["read_corroborated"] = corroborated
        if not suspect_read:
            basis = "read is not a below-par Set A collateral read"
        elif pool_has_loss:
            basis = "pool unrealizedLosses > 0"
        elif loan_flagged:
            basis = "loan is impaired, called, or in default"
        else:
            basis = ("pool unrealizedLosses = 0; loan is not impaired, "
                     "called, or in default")
        collateral["read_corroboration_basis"] = basis

    set_a_crit_corr = [l for l in set_a_crit
                       if pool_has_loss or _loan_corroborated(l)]
    set_a_crit_uncorr = [l for l in set_a_crit
                         if not (pool_has_loss or _loan_corroborated(l))]

    set_a_health = {
        "crit_level_pct": SET_A_CRIT_LEVEL_PCT,
        "warn_level_pct": SET_A_WARN_LEVEL_PCT,
        # crit_count / crit_principal_usd remain the TOTAL below-100 set for
        # renderer back-compat; the corroborated/uncorroborated split below is
        # what the pager keys on.
        "crit_count":         len(set_a_crit),
        "crit_principal_usd": round(sum(l["principal"] for l in set_a_crit), 2),
        "crit_corroborated_count":         len(set_a_crit_corr),
        "crit_corroborated_principal_usd": round(
            sum(l["principal"] for l in set_a_crit_corr), 2),
        "crit_uncorroborated_count":         len(set_a_crit_uncorr),
        "crit_uncorroborated_principal_usd": round(
            sum(l["principal"] for l in set_a_crit_uncorr), 2),
        "warn_count":         len(set_a_warn),
        "warn_principal_usd": round(sum(l["principal"] for l in set_a_warn), 2),
    }

    return {
        "by_asset": by_asset_list,
        "loans_below_init_count":   len(below),
        "principal_below_init_usd": round(sum(l["principal"] for l in below), 2),
        "set_a_collateral_health":  set_a_health,
        "weighted_avg_buffer_pp":   round(wtd_avg_buffer, 2)
                                       if wtd_avg_buffer is not None else None,
        "tightest_loan":            tightest_block,
        "set_a_overcollateralized": {
            "loans": len(set_a),
            "principal_usd": round(set_a_principal, 2),
            "pct_of_book": round(set_a_principal / total_principal * 100, 2)
                if total_principal > 0 else 0,
            "weighted_avg_init_level_pct": round(set_a_wavg, 2)
                if set_a_wavg is not None else None,
        },
        "set_b_at_par": {
            "loans": len(set_b),
            "principal_usd": round(set_b_principal, 2),
            "pct_of_book": round(set_b_principal / total_principal * 100, 2)
                if total_principal > 0 else 0,
            "named_issuers": set_b_named_issuers,
            "largest_position_usd": round(largest_b_principal, 2),
            "largest_position_asset": largest_b["collateral"]["asset"]
                if largest_b else None,
            "largest_position_pct_of_book": round(largest_b_pct, 2),
        },
        # collateralRatio is scaled ×1e6 → percent (1e6 = 1%, e.g. 1.49e8 = 149.26%).
        # Distinct from initialLevel's ×1e4 = percent scaling, despite being on the
        # same API. Verified 2026-05-01 against Maple's app showing ~150% pool CR.
        # GraphQL returns these as JSON strings; coerce to int.
        "pool_collateral_ratio_pct": round(
            int(pool_agg["collateral_ratio_raw"]) / 1e6, 2
        ) if pool_agg.get("collateral_ratio_raw") else None,
        "pool_collateral_value_usd": round(
            int(pool_agg["collateral_value_raw"]) / 10**USDC_DEC, 2
        ) if pool_agg.get("collateral_value_raw") else None,
        "loans_missing_collateral": len(loans) - len(enriched),
        "row_aggregate_reconciliation": {
            "status": "unresolved_scope_and_valuation_mismatch",
            "row_numeric_collateral_usd": round(sum(l["collateral"]["usd"] for l in loans if isinstance((l.get("collateral") or {}).get("usd"), (int, float))), 2),
            "row_numeric_count": sum(isinstance((l.get("collateral") or {}).get("usd"), (int, float)) for l in loans),
            "row_total_count": len(loans),
            "aggregate_units": "collateralValue / 1e6 USD; collateralRatio / 1e6 percent",
            "aggregate_scope": "Maple poolV2 aggregate; underlying allocation/valuation time not supplied",
            "row_scope": "enumerated positions joined by exact loan address; GraphQL currentAssetAmount / configured decimals times independent producer prices",
            "custody_allocation_verified": False,
            "limitation": "Issuer UI and GraphQL disagree on exact loan collateral values; neither accounting PCR nor zero recognized losses resolves custody or shortfall",
        },
        "data_source": source_status,
        "data_source_timestamp": timestamp,
    }


def _build_concentration(loans, total_principal):
    """Borrower concentration rollup with its denominator made explicit."""
    from collections import defaultdict

    borrower_principal: dict[str, float] = defaultdict(float)
    borrower_loan_count: dict[str, int] = defaultdict(int)
    for l in loans:
        # Lower-case key for stable dedup; keep checksum address for output.
        key = l["borrower"].lower()
        borrower_principal[key] += l["principal"]
        borrower_loan_count[key] += 1

    sorted_borrowers = sorted(borrower_principal.items(), key=lambda kv: -kv[1])

    def top_n_share(n):
        return sum(p for _, p in sorted_borrowers[:n]) / total_principal * 100

    shares = [p / total_principal * 100 for _, p in sorted_borrowers]
    hhi = sum(s * s for s in shares)
    if hhi < 1500:
        hhi_bucket = "unconcentrated"
    elif hhi < 2500:
        hhi_bucket = "moderate"
    else:
        hhi_bucket = "concentrated"

    borrowers = [
        {
            "address": Web3.to_checksum_address(addr),
            "principal_usd": round(principal, 2),
            "loan_count": borrower_loan_count[addr],
            "share_pct": round(principal / total_principal * 100, 2),
            "firm": BORROWER_FIRM_MAP.get(addr),
            "borrower_meta_tag": BORROWER_META_TAG.get(addr),
        }
        for addr, principal in sorted_borrowers
    ]

    return {
        "total_borrowers": len(borrower_principal),
        "top_1_share_pct": round(top_n_share(1), 2),
        "top_3_share_pct": round(top_n_share(3), 2),
        "top_5_share_pct": round(top_n_share(5), 2),
        "top_10_share_pct": round(top_n_share(10), 2),
        "hhi": round(hhi),
        "hhi_bucket": hhi_bucket,
        "denominator_usd": round(total_principal, 2),
        "denominator_basis": "all_enumerated_active_position_principal",
        "member_loan_addresses": [l["loan_addr"] for l in loans if l.get("loan_addr")],
        "borrowers_listed": len(borrowers),
        "borrowers_total": len(sorted_borrowers),
        "borrowers": borrowers,
    }


def _build_payment_ladder(loans, now):
    """6 × 30-day expected interest-only inflow buckets out to 180 days."""
    def expected_interest_per_payment(loan):
        rate_decimal = loan["rate_pct"] / 100
        interval_seconds = loan["payment_interval_days"] * 86400
        return loan["principal"] * rate_decimal * (interval_seconds / SECONDS_PER_YEAR)

    buckets = []
    for days_offset in (30, 60, 90, 120, 150, 180):
        bucket_end = now + days_offset * 86400
        bucket_start = now + (days_offset - 30) * 86400
        loans_in_bucket = [
            l for l in loans
            if bucket_start <= l["payment_due_date"] < bucket_end
        ]
        buckets.append({
            "days_from_now_start": days_offset - 30,
            "days_from_now_end": days_offset,
            "period_end_iso": datetime.fromtimestamp(bucket_end, tz=timezone.utc).date().isoformat(),
            "loan_count": len(loans_in_bucket),
            "expected_inflow_usd": round(
                sum(expected_interest_per_payment(l) for l in loans_in_bucket), 2
            ),
        })

    def cumulative(max_day):
        return round(
            sum(b["expected_inflow_usd"] for b in buckets if b["days_from_now_end"] <= max_day), 2
        )

    overdue = [l for l in loans if l["payment_due_date"] < now]

    return {
        "horizon_days": 180,
        "bucket_size_days": 30,
        "now_unix": now,
        "buckets": buckets,
        "totals": {
            "expected_inflow_30d_usd": cumulative(30),
            "expected_inflow_60d_usd": cumulative(60),
            "expected_inflow_90d_usd": cumulative(90),
            "expected_inflow_180d_usd": cumulative(180),
        },
        "overdue_loan_count": len(overdue),
        "overdue_principal_usd": round(sum(l["principal"] for l in overdue), 2),
        "method": "rate_estimate",
    }


def aggregate_loan_book(loans, principal_out=0):
    """Compute summaries and explicit manager-principal reconciliation."""
    if not loans:
        empty_concentration = {
            "total_borrowers": 0,
            "top_1_share_pct": 0,
            "top_3_share_pct": 0,
            "top_5_share_pct": 0,
            "top_10_share_pct": 0,
            "hhi": 0,
            "hhi_bucket": "unconcentrated",
            "denominator_usd": 0,
            "denominator_basis": "all_enumerated_active_position_principal",
            "member_loan_addresses": [],
            "borrowers_listed": 0,
            "borrowers_total": 0,
            "borrowers": [],
        }
        empty_ladder = {
            "horizon_days": 180,
            "bucket_size_days": 30,
            "now_unix": int(time.time()),
            "buckets": [],
            "totals": {
                "expected_inflow_30d_usd": 0,
                "expected_inflow_60d_usd": 0,
                "expected_inflow_90d_usd": 0,
                "expected_inflow_180d_usd": 0,
            },
            "overdue_loan_count": 0,
            "overdue_principal_usd": 0,
            "method": "rate_estimate",
        }
        return {
            "active_loan_count": 0,
            "borrower_count": 0,
            "weighted_avg_rate_pct": 0,
            "weighted_avg_remaining_days_to_due": 0,
            "impaired_count": 0,
            "called_count": 0,
            "default_count": 0,
            "top_borrower_concentration_pct": 0,
            "concentration": empty_concentration,
            "payment_ladder": empty_ladder,
            "loans": [],
            "enumerated_principal": 0.0,
            "principal_out": round(principal_out, 2),
            "enumeration_residual": round(principal_out, 2),
            "enumeration_coverage_pct": round(0 if principal_out else 100, 8),
        }

    now = int(time.time())
    total_principal = sum(l["principal"] for l in loans)
    if total_principal <= 0:
        return {
            "active_loan_count": len(loans),
            "borrower_count": len(set(l["borrower"] for l in loans)),
            "weighted_avg_rate_pct": 0,
            "weighted_avg_remaining_days_to_due": 0,
            "impaired_count": sum(1 for l in loans if l["is_impaired"]),
            "called_count": sum(1 for l in loans if l["is_called"]),
            "default_count": sum(1 for l in loans if l["is_in_default"]),
            "top_borrower_concentration_pct": 0,
            "concentration": {
                "total_borrowers": len(set(l["borrower"].lower() for l in loans)),
                "top_1_share_pct": 0,
                "top_3_share_pct": 0,
                "top_5_share_pct": 0,
                "top_10_share_pct": 0,
                "hhi": 0,
                "hhi_bucket": "unconcentrated",
                "borrowers": [],
            },
            "payment_ladder": _build_payment_ladder(loans, now),
            "loans": sorted(loans, key=lambda l: -l["principal"]),
            "enumerated_principal": round(total_principal, 2),
            "principal_out": round(principal_out, 2),
            "enumeration_residual": round(principal_out - total_principal, 2),
            "enumeration_coverage_pct": round(total_principal / principal_out * 100, 8) if principal_out else 100.0,
        }

    weighted_rate = sum(l["principal"] * l["rate_pct"] for l in loans) / total_principal
    weighted_due = sum(l["principal"] * max(0, (l["payment_due_date"] - now) / 86400) for l in loans) / total_principal

    borrower_totals = {}
    for l in loans:
        borrower_totals[l["borrower"]] = borrower_totals.get(l["borrower"], 0) + l["principal"]
    top_borrower_pct = max(borrower_totals.values()) / total_principal * 100

    concentration = _build_concentration(loans, total_principal)
    payment_ladder = _build_payment_ladder(loans, now)

    # Loans/Liquidity split — see classify_position_type.
    for loan in loans:
        classify_usdc(loan)
    loans_only = [l for l in loans if l.get("position_type") == "loan"]
    liquidity = [l for l in loans if l.get("position_type") == "liquidity"]
    principal_loans_only = sum(l["principal"] for l in loans_only)
    principal_liquidity = sum(l["principal"] for l in liquidity)
    concentration_loans_only = (
        _build_concentration(loans_only, principal_loans_only)
        if principal_loans_only > 0
        else {"total_borrowers": 0, "top_1_share_pct": 0, "top_3_share_pct": 0,
              "top_5_share_pct": 0, "top_10_share_pct": 0, "hhi": 0,
              "hhi_bucket": "unconcentrated", "borrowers": []}
    )

    return {
        "active_loan_count": len(loans),
        "borrower_count": len(borrower_totals),
        "weighted_avg_rate_pct": round(weighted_rate, 2),
        "weighted_avg_remaining_days_to_due": round(weighted_due, 1),
        "impaired_count": sum(1 for l in loans if l["is_impaired"]),
        "called_count": sum(1 for l in loans if l["is_called"]),
        "default_count": sum(1 for l in loans if l["is_in_default"]),
        "top_borrower_concentration_pct": round(top_borrower_pct, 2),
        "concentration": concentration,
        "classification_version": USDC_VERSION,
        "classification_definition": "loan=reviewed credit; liquidity=identified non-credit strategy, not immediately withdrawable cash; unknown excluded from both",
        "principal_unknown_usd": round(sum(l["principal"] for l in loans if l.get("position_type") == "unknown"), 2),
        "unknown_count": sum(l.get("position_type") == "unknown" for l in loans),
        "credit_coverage": coverage(loans),
        "concentration_loans_only": {**concentration_loans_only,
            "denominator_usd": round(principal_loans_only, 2),
            "denominator_basis": "classified_credit_principal",
            "classification_version": USDC_VERSION,
            "member_loan_addresses": [l["loan_addr"] for l in loans_only if l.get("loan_addr")],
            "excluded_loan_addresses": [l["loan_addr"] for l in loans if l not in loans_only and l.get("loan_addr")]},
        "principal_loans_only_usd": round(principal_loans_only, 2),
        "principal_liquidity_usd": round(principal_liquidity, 2),
        "principal_total_usd": round(total_principal, 2),
        "loans_only_count": len(loans_only),
        "liquidity_count": len(liquidity),
        "payment_ladder": payment_ladder,
        "loans": sorted(loans, key=lambda l: -l["principal"]),
        "enumerated_principal": round(total_principal, 2),
        "principal_out": round(principal_out, 2),
        "enumeration_residual": round(principal_out - total_principal, 2),
        "enumeration_coverage_pct": round(total_principal / principal_out * 100, 8) if principal_out else 100.0,
    }


# ---------------------------------------------------------------------------
# Risk flags (handoff §2)
# ---------------------------------------------------------------------------
def build_risk_flags(vault, peg, headline_apy_source, loan_book=None):
    flags = []
    deployment_ratio_pct = vault["deployment_ratio_pct"] or 0
    unrealized_losses = vault["unrealized_losses"]
    pd_cover = vault["pool_delegate_cover_usdc"]
    pd_eoa = vault["pool_delegate_is_eoa"]
    paused = vault["protocol_paused"]

    if deployment_ratio_pct > 98:
        flags.append({"severity": "warning",
                      "message": "Free liquidity <2% — exits forced into queue"})
    elif deployment_ratio_pct > 95:
        flags.append({"severity": "info",
                      "message": "Free liquidity 2-5% — large exits will queue"})

    if unrealized_losses > 0:
        flags.append({"severity": "critical",
                      "message": f"Unrealized losses {fmt_usd(unrealized_losses)}"})

    pd_pct = peg.get("peg", {}).get("premium_discount_pct") if peg else None
    if pd_pct is not None and pd_pct < -0.5:
        flags.append({"severity": "warning",
                      "message": f"Peg discount {pd_pct:.2f}%"})

    if pd_cover < 1:
        flags.append({"severity": "warning",
                      "message": "Pool Delegate first-loss cover: $0"})

    if pd_eoa:
        # Per Maple's 2026-05-04 attestation, Pool Delegate addresses are MPC
        # wallets with strict policy controls — not single-key. The risk axis
        # is discretionary credit-judgment + single-firm operational control,
        # not custody-primitive weakness.
        flags.append({"severity": "info",
                      "message": "Pool Delegate has discretionary loan-funding authority (MPC + policy per Maple, but single-firm operational control)"})

    if paused:
        flags.append({"severity": "critical", "message": "Protocol PAUSED"})

    # DeFi sleeve activation — fires when a non-LoanManager strategy holds
    # material capital. Catches the moment the delegate redeploys into Aave
    # (MapleAaveStrategy) or Sky (MapleSkyStrategy). Dormant sleeves sit at the
    # ~10-wei placeholder and stay quiet.
    for s in vault.get("strategies", []):
        if s.get("is_loan_manager"):
            continue
        aum = s.get("aum_usd") or 0
        if aum >= SLEEVE_ACTIVATION_THRESHOLD_USD:
            name = s.get("strategy_impl_name") or (s["address"][:12] + "...")
            flags.append({
                "severity": "warning",
                "message": (
                    f"DeFi sleeve {name} has ${aum/1e6:.1f}M deployed — "
                    f"depositor risk surface has expanded into the wrapped "
                    f"protocol's counterparty risk (delegate-discretionary, "
                    f"no timelock)"
                ),
            })

    if headline_apy_source == "manual_season_constant":
        flags.append({"severity": "warning",
                      "message": "Headline APY using hardcoded constant — syrupGlobals + Maple REST + DefiLlama all unavailable"})

    # Collateral mix flags (Set B = at-par stablecoin/RWA collateral).
    # Tiered thresholds: 25% info / 35% warning / 50% critical.
    summary = (loan_book or {}).get("collateral_summary") if loan_book else None
    if summary and summary.get("data_source") == "maple_graphql":
        set_b = summary.get("set_b_at_par") or {}
        at_par_pct = set_b.get("pct_of_book") or 0
        largest_pct = set_b.get("largest_position_pct_of_book") or 0
        largest_asset = set_b.get("largest_position_asset")

        if at_par_pct >= 50:
            flags.append({"severity": "critical",
                          "message": f"At-par (Set B) collateral dominates the book ({at_par_pct:.0f}%) — depositor risk is collateral-asset peg/issuer risk, not crypto-cycle"})
        elif at_par_pct >= 35:
            flags.append({"severity": "warning",
                          "message": f"At-par (Set B) collateral: {at_par_pct:.0f}% of book — stablecoin/RWA issuer/peg surface is a primary risk axis"})
        elif at_par_pct >= 25:
            flags.append({"severity": "info",
                          "message": f"At-par (Set B) collateral: {at_par_pct:.0f}% of book — stablecoin/RWA peg risk distinct from crypto-cycle"})

        if largest_pct >= 20 and largest_asset:
            flags.append({"severity": "warning",
                          "message": f"Largest single loan ({largest_pct:.0f}% of book) collateralized at par by {largest_asset}"})

        # Set A collateralization health — measured against an absolute floor
        # (proximity to principal), NOT the funding-time init level. A Set A loan
        # drifting below its high init margin (e.g. 333% → 270%) is still deeply
        # overcollateralized and is not alertable; what matters is closeness to
        # principal. Set B (at-par) is excluded — it sits at ~100% by design.
        #   < 100% → CRIT (collateral worth less than principal)
        #   < 120% → WARN (thin buffer above principal)
        health = summary.get("set_a_collateral_health") or {}
        # Use by_asset totals (full active book) for the denominator — loan_book.loans
        # is truncated to top-25 and would understate it.
        book_principal = sum(
            a.get("principal_usd", 0) for a in (summary.get("by_asset") or [])
        )
        # Preserve existing protocol-flag severity routing. Low readings without
        # concurrent protocol flags remain unresolved, not proved artifacts.
        crit_corr_n = health.get("crit_corroborated_count") or 0
        crit_corr_usd = health.get("crit_corroborated_principal_usd") or 0
        if crit_corr_n >= 1:
            pct = (crit_corr_usd / book_principal * 100) if book_principal > 0 else 0
            flags.append({"severity": "critical",
                          "message": f"{crit_corr_n} Set A loans (${crit_corr_usd/1e6:.0f}M, {pct:.1f}% of book) below 100% collateralization — crypto collateral worth less than principal"})
        crit_unc_n = health.get("crit_uncorroborated_count") or 0
        crit_unc_usd = health.get("crit_uncorroborated_principal_usd") or 0
        if crit_unc_n >= 1:
            pct = (crit_unc_usd / book_principal * 100) if book_principal > 0 else 0
            flags.append({"severity": "info",
                          "message": f"{crit_unc_n} Set A loans (${crit_unc_usd/1e6:.0f}M, {pct:.1f}% of book) read below 100% collateralization in Maple GraphQL but are uncorroborated (unrealizedLosses=0, none impaired/called/defaulted) — source disagreement unresolved; zero recognized losses and accounting PCR do not establish collateral custody or rule out shortfall"})
        warn_n = health.get("warn_count") or 0
        warn_usd = health.get("warn_principal_usd") or 0
        if warn_n >= 1:
            pct = (warn_usd / book_principal * 100) if book_principal > 0 else 0
            flags.append({"severity": "warning",
                          "message": f"{warn_n} Set A loans (${warn_usd/1e6:.0f}M, {pct:.1f}% of book) at 100-120% collateralization — thin buffer above principal"})
    elif summary and summary.get("data_source") == "unavailable":
        flags.append({"severity": "info",
                      "message": "Collateral data temporarily unavailable from Maple GraphQL"})

    return flags


# ---------------------------------------------------------------------------
# Build report JSON (schema_version 1)
# ---------------------------------------------------------------------------
def build_custody_topology(vault, active_loans):
    """Inventory of single-key EOAs across this pool's trust stack.

    Combines the pool delegate (discretionary control over loan funding) with
    the Liquidity-position custody EOAs visible to this pool. Emits a per-pool
    view; the family aggregator unions across both pools for the brand-wide
    single_key_eoa_count.

    Each entry surfaces:
      capital_under_control_usd   — this pool's per-pool slice (the
                                    loan-book accounting principal). Shared
                                    custody addresses (PYUSD 0xe7F0...,
                                    USTB 0x1FcC...) hold capital from BOTH
                                    syrup pools; balanceOf returns the union,
                                    so emitting it here would double-count
                                    once the family aggregator address-merges
                                    across pools.
      loan_book_principal_usd     — sum of Liquidity loan-record principals
                                    attributed to this custody (Maple's
                                    accounting view). Same value as
                                    capital_under_control_usd.
      custody_balance_usd         — raw on-chain balanceOf (cross-pool union
                                    for shared custodies), when readable.
                                    Kept for transparency; dashboards can
                                    show "this pool's slice" alongside "raw
                                    on-chain balance" without conflating.
    """
    entries = []

    # Pool Delegate (always single-key EOA per current verification).
    pd_addr = vault.get("pool_delegate")
    if pd_addr and vault.get("pool_delegate_is_eoa"):
        entries.append({
            "role": f"Pool Delegate ({ASSET_SLUG})",
            "address": pd_addr,
            "is_eoa": True,
            "chain": "ethereum",
            "capital_under_control_usd": round(vault.get("total_assets") or 0, 2),
            "control_type": "discretionary",
        })

    # Liquidity custody EOAs (deduped by custody_addr; aggregate across loans).
    by_custody = {}
    for loan in (active_loans or []):
        if loan.get("position_type") != "liquidity":
            continue
        cust = loan.get("custody")
        if not cust or cust.get("is_eoa") is not True:
            continue
        addr = cust["address"]
        coll = loan.get("collateral") or {}
        asset = coll.get("asset")
        rec = by_custody.setdefault(addr, {
            "address": addr,
            "chain": cust.get("chain"),
            "venue": cust.get("venue"),
            "loan_book_principal_usd": 0.0,
            "custody_balance_usd": cust.get("asset_balance_usd"),
            "asset_label": asset,
        })
        rec["loan_book_principal_usd"] += (loan.get("principal") or 0)

    for addr, rec in by_custody.items():
        if rec.get("venue") == "AMM-LP-pair":
            role = "AMM Liquidity operator"
        else:
            role = f"{rec['asset_label']} Liquidity custody"
        # Per-pool slice for both asset and AMM custodies. Asset balanceOf
        # returns the cross-pool union for shared addresses (PYUSD, USTB);
        # AMM stable balanceOf is dust because LP capital lives in pair
        # contracts. The loan-book accounting principal is the right
        # per-pool number in both cases. Raw balanceOf is still surfaced
        # in the entry's custody_balance_usd field for transparency.
        capital = rec["loan_book_principal_usd"]
        entries.append({
            "role": role,
            "address": rec["address"],
            "chain": rec["chain"],
            "venue": rec.get("venue"),
            "is_eoa": True,
            "capital_under_control_usd": round(capital, 2),
            "loan_book_principal_usd": round(rec["loan_book_principal_usd"], 2),
            "custody_balance_usd": (round(rec["custody_balance_usd"], 2)
                                    if rec["custody_balance_usd"] is not None
                                    else None),
            "control_type": "custody",
        })

    total = sum(e.get("capital_under_control_usd") or 0 for e in entries)
    return {
        "scope": "per_pool",
        "single_key_eoa_count": len(entries),
        "total_capital_under_eoa_control_usd": round(total, 2),
        "entries": entries,
    }


def build_report(vault, peg, headline_apy, headline_apy_source, apy_breakdown,
                 loan_book, aum_history=None, apy_history=None,
                 wq_timing=None, custody_topology=None):
    base_apy_pct = peg.get("yield_7d_apr_pct", 0) if peg else 0
    # Season/Drips incentive is the GraphQL boost leg (authoritative). Maple moved
    # Drips to quarterly SYRUP distributions + buybacks in 2026, so boostApy is
    # typically 0 — do NOT infer an incentive from (headline - base), which is only
    # the measurement drift between Maple's coreApy and PegTracker's NAV-derived 7d
    # APR. Fall back to the residual only when no GraphQL breakdown is available
    # (maple_api / defillama / manual_season_constant sources).
    if apy_breakdown:
        season_incentive_apy_pct = apy_breakdown.get("boost_apy_pct", 0) or 0
    else:
        season_incentive_apy_pct = max(0, headline_apy - base_apy_pct) if headline_apy else 0

    pcr = vault["pcr_principal_pct"]
    deployment = vault["deployment_ratio_pct"] or 0
    free_liq = vault["free_liquidity"]

    queue_depth_slots = max(0, vault["wq_last_request_id"] - vault["wq_next_request_id"] + 1)

    backing_breakdown = [
        {"label": "Free USDC", "value": round(vault["free_usdc"], 2),
         "pct": round(vault["free_usdc"] / vault["total_assets"] * 100, 2) if vault["total_assets"] else 0,
         "tags": ["liquid"]},
        {"label": "Strategy AUM (deployed)", "value": round(vault["strategy_aum"], 2),
         "pct": round(vault["strategy_aum"] / vault["total_assets"] * 100, 2) if vault["total_assets"] else 0,
         "tags": ["deployed"]},
    ]

    risk_flags = build_risk_flags(vault, peg, headline_apy_source, loan_book)
    multi_chain = build_syrup_multi_chain_block(
        "syrupusdc",
        nav=vault.get("nav"),
        total_assets=vault.get("total_assets"),
        ethereum_supply_native=vault.get("total_supply"),
    )
    reconciliation = multi_chain.get("cross_chain_supply_reconciliation_pct")
    if reconciliation is not None and abs(reconciliation - 100) > 2:
        risk_flags.append({
            "severity": "warning",
            "message": (
                "Cross-chain supply reconciliation outside 98-102%: "
                f"{reconciliation:.2f}% of vault assets"
            ),
        })

    report = {
        "schema_version": 2,
        "asset": "syrupUSDC",
        "asset_slug": "syrupusdc",
        "chain": "Ethereum",
        "timestamp": now_iso(),

        "summary": {
            "total_supply": round(vault["total_supply"], 2),  # share count
            "supply_unit": "shares",  # tells frontend to format without $ prefix
            "total_backing": round(vault["total_assets"], 2),
            "collateral_ratio": round(pcr, 2) if pcr is not None else None,
            "collateral_ratio_alt": {
                "label": "Free Liquidity",
                "value": round(free_liq, 2),
                "note": "Pool USDC + accrued interest in strategies (not in active loans)",
                "is_currency": True,
            },
            "surplus_deficit": round(
                (vault["free_usdc"] + vault["strategy_aum"]) - vault["total_assets"], 2
            ),
            "deployment_ratio_pct": round(deployment, 2),
            "unrealized_losses": round(vault["unrealized_losses"], 2),
            "nav": round(vault["nav"], 6) if vault["nav"] else None,
            "liquidity_cap": round(vault["liquidity_cap"], 2),
            "cap_utilization_pct": round(vault["cap_utilization_pct"], 2)
                if vault["cap_utilization_pct"] is not None else None,
        },

        "backing_breakdown": backing_breakdown,
        "risk_flags": risk_flags,
        "vault_status": None,

        "asset_specific": {
            "type": "syrupusdc",

            # Frontend hooks: prepend a NAV card and rebrand "Collateral Ratio" → PCR
            # with an explainer subtext. Read by CommonRenderer.renderSummaryCards.
            "extra_summary_cards": [
                {
                    "label": "NAV",
                    "value": (f"${vault['nav']:.4f}" if vault.get("nav") else "-"),
                    "subtext": "USDC per share",
                }
            ],
            "card_overrides": {
                "Collateral Ratio": {
                    "label": "Pool Coverage Ratio",
                    "subtext": "100% = every share fully backed at NAV. <100% = unrealized losses.",
                }
            },

            "vault_state": {
                "pool": POOL,
                "pool_manager": POOL_MANAGER,
                "share_token_decimals": SHARE_DEC,
                "asset_token": USDC,
                "total_assets": round(vault["total_assets"], 2),
                "total_supply": round(vault["total_supply"], 2),
                "nav": round(vault["nav"], 6) if vault["nav"] else None,
                "free_usdc": round(vault["free_usdc"], 2),
                "strategy_aum": round(vault["strategy_aum"], 2),
                "principal_out": round(vault["principal_out"], 2),
                "free_liquidity": round(free_liq, 2),
                "deployment_ratio_pct": round(deployment, 2),
                "pcr_principal_pct": round(pcr, 2) if pcr is not None else None,
                "unrealized_losses": round(vault["unrealized_losses"], 2),
                "liquidity_cap": round(vault["liquidity_cap"], 2),
                "cap_utilization_pct": round(vault["cap_utilization_pct"], 2)
                    if vault["cap_utilization_pct"] is not None else None,
                "strategies": [
                    {
                        "address": s["address"],
                        "implementation": s.get("implementation"),
                        "strategy_impl_name": s.get("strategy_impl_name", "Unknown"),
                        "is_loan_manager": s["is_loan_manager"],
                        "aum_usd": round(s["aum_usd"], 2),
                        # ⚠️ Stays null when the strategy type has no such
                        # field. Rounding it to 0.00 would restore exactly the
                        # ambiguity this change removed.
                        "principal_out_usd": (round(s["principal_out_usd"], 2)
                                              if s["principal_out_usd"] is not None else None),
                        "accounted_interest_usd": (round(s["accounted_interest_usd"], 2)
                                                   if s["accounted_interest_usd"] is not None else None),
                        "principal_fields_supported": s.get("principal_fields_supported"),
                        "unrealized_losses_usd": round(s["unrealized_losses_usd"], 2),
                    } for s in vault["strategies"]
                ],
            },

            "yield": {
                "base_apy_pct": round(peg.get("yield_7d_apr_pct", 0), 2) if peg else None,
                "base_apy_source": "pegtracker_nav_7d" if peg else None,
                "headline_apy_pct": round(headline_apy, 2) if headline_apy else None,
                "core_apy_pct": round(apy_breakdown["core_apy_pct"], 2)
                    if apy_breakdown else None,
                "boost_apy_pct": round(apy_breakdown["boost_apy_pct"], 2)
                    if apy_breakdown else None,
                "apy_as_of": apy_breakdown.get("as_of") if apy_breakdown else None,
                "season_incentive_apy_pct": round(season_incentive_apy_pct, 2),
                "delegate_fee_pct": round(vault["delegate_fee_pct"], 2),
                "headline_apy_source": headline_apy_source,
                "apy_history": apy_history,
            },

            "external_collateral_verification": {
                "source": "https://dashboard.ledgerlens.io/c/maple",
                "reviewed_at": "2026-10-29",
                "source_verified_at": "2026-10-27T01:00:00Z",
                "scope": "combined syrupUSDC and syrupUSDT",
                "summary_retrievable": True,
                "per_pool_allocation_verified": False,
                "per_loan_attestation_retrieved": False,
                "limitation": "Combined summary only; no matched per-pool/per-loan custody allocation",
            },
            "loan_book": loan_book,

            "aum_history": aum_history,

            "withdrawal_queue": {
                "withdrawal_manager": WITHDRAWAL_MANAGER,
                "next_request_id": vault["wq_next_request_id"],
                "last_request_id": vault["wq_last_request_id"],
                "queue_depth_slots": queue_depth_slots,
                # Slot count is requests in queue; share/USDC depth requires
                # iterating requests(slot) — defer to v2.
                "queue_depth_shares": None,
                "queue_depth_usdc_est": None,
                "is_empty": queue_depth_slots == 0,
                **(wq_timing or {
                    "last_filled_timestamp_iso": None,
                    "last_filled_age_seconds": None,
                    "next_request_age_seconds": None,
                    "current_cycle_start_timestamp_iso": None,
                    "current_cycle_end_timestamp_iso": None,
                    "cycle_duration_seconds": None,
                }),
            },

            "liquidity": peg.get("liquidity") if peg else None,
            "peg": peg.get("peg") if peg else None,

            "multi_chain": multi_chain,

            "governance": {
                "governor": vault["governor"],
                "operational_admin": vault["operational_admin"],
                "security_admin": vault["security_admin"],
                "pool_delegate": {
                    "address": vault["pool_delegate"],
                    "firm_name": vault["pool_delegate_firm_name"],
                    "is_eoa": vault["pool_delegate_is_eoa"],
                },
                "pool_delegate_cover": POOL_DELEGATE_COVER,
                "pool_delegate_cover_usdc": round(vault["pool_delegate_cover_usdc"], 2),
                "pool_delegate_cover_eth": round(vault["pool_delegate_cover_eth"], 6),
                "min_cover_amount": round(vault["min_cover_amount"], 2),
                "protocol_paused": vault["protocol_paused"],
                "pm_active": vault["pm_active"],
                "pm_configured": vault["pm_configured"],
                "timelock_hours": 72,
                "timelock_floor_hours": 24,
                "custody_topology": custody_topology,
            },

            "chart_bands": {
                "pcr": [99.0, 99.8, 100.0, 100.5],
            },
        },
    }
    return report


# ---------------------------------------------------------------------------
# Validation guard (copied pattern from usdd_backing_analyzer)
# ---------------------------------------------------------------------------
def validate_data(report):
    summary = report["summary"]
    total_supply = summary.get("total_supply", 0)
    total_backing = summary.get("total_backing", 0)

    # Basic sanity
    if total_supply < 1_000 or total_backing < 1_000:
        print("  VALIDATION FAIL: supply or backing near zero")
        return False

    # Compare against last-good
    try:
        baseline_path = LAST_GOOD_JSON if os.path.exists(LAST_GOOD_JSON) else JSON_OUTPUT
        with open(baseline_path, "r") as f:
            prev = json.load(f)
        prev_backing = prev.get("summary", {}).get("total_backing", 0)
        prev_supply = prev.get("summary", {}).get("total_supply", 0)
        if prev_backing > 0:
            backing_change = abs(total_backing - prev_backing) / prev_backing * 100
            supply_change = abs(total_supply - prev_supply) / prev_supply * 100 if prev_supply > 0 else 0
            # Skip history append if backing moved >5% with stable supply (data-validation guard)
            if backing_change > 5 and supply_change < 1:
                print(f"  VALIDATION FAIL: backing moved {backing_change:.1f}% but supply only {supply_change:.1f}%")
                print(f"    prev: backing={fmt_usd(prev_backing)} supply={prev_supply:,.2f}")
                print(f"    curr: backing={fmt_usd(total_backing)} supply={total_supply:,.2f}")
                return False
    except (FileNotFoundError, json.JSONDecodeError, KeyError):
        pass
    return True


# ---------------------------------------------------------------------------
# Persistence
# ---------------------------------------------------------------------------
# ⚠️ This analyzer writes a STAGING path, not the published filename.
#
# syrup_family_analyzer.py enriches this report with the five axis blocks and
# publishes the real name. While the base wrote the published path directly,
# there was a ~2-minute window each hour where that file existed, parsed, and
# carried ZERO axis blocks — and backing-monitor's sync at :45 landed inside it,
# copying a fresh-but-incomplete payload. The dashboard then showed a migrated
# asset as unmigrated, with nothing anywhere reporting an error.
#
# Staging makes the incomplete state UNREPRESENTABLE at the published path
# rather than merely unlikely: no schedule change, slow RPC or retry can expose
# a partial file, because a partial file never has that name. If the enricher
# fails, the published path keeps last hour's COMPLETE payload — stale beats
# partial, and the runner's freshness check is what surfaces it.
STAGING_SUFFIX = ".staging"


def staging_path():
    return JSON_OUTPUT + STAGING_SUFFIX


def save_json_report(report):
    os.makedirs(DATA_DIR, exist_ok=True)
    dest = staging_path()
    # Unique temp per writer: a fixed "<path>.tmp" is atomic against a crash but
    # not against a second writer, which is how backing_history.json lost 33.7MB.
    tmp = f"{dest}.{os.getpid()}.{uuid.uuid4().hex[:8]}.tmp"
    with open(tmp, "w") as f:
        json.dump(report, f, indent=2)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, dest)
    print(f"\nWrote {dest} (staging — syrup_family_analyzer publishes {JSON_OUTPUT})")


def save_history(report):
    from json_database import JSONDatabase

    summary = report["summary"]
    # Real secondary market-vs-NAV peg (CoinGecko), logged FLAT into history so
    # the common Layer-2 peg chart can read entries[].peg_market_price.
    peg = (report.get("asset_specific") or {}).get("peg") or {}
    db = JSONDatabase(HISTORY_DB_PATH)
    db.append_datapoint(
        asset_name="syrupUSDC",
        market_price=summary["collateral_ratio"],
        theoretical_price=100.0,
        peg_deviation=((summary["collateral_ratio"] - 100.0)
                       if summary["collateral_ratio"] is not None else None),
        chain="ethereum",
        timestamp=report["timestamp"],
    )
    latest_dp = db.get_latest_datapoint("syrupUSDC")
    if latest_dp:
        latest_dp["classification_version"] = (report.get("asset_specific", {}).get("loan_book") or {}).get("classification_version")
        latest_dp["collateral_ratio"] = summary["collateral_ratio"]
        latest_dp["collateral_ratio_alt"] = summary["collateral_ratio_alt"]["value"]
        latest_dp["total_supply"] = summary["total_supply"]
        latest_dp["total_backing"] = summary["total_backing"]
        latest_dp["nav"] = summary["nav"]
        latest_dp["deployment_ratio_pct"] = summary.get("deployment_ratio_pct")
        latest_dp["unrealized_losses"] = summary.get("unrealized_losses")
        latest_dp["peg_market_price"] = peg.get("market_price")
        latest_dp["peg_theoretical_price"] = peg.get("theoretical_price")
        latest_dp["peg_premium_discount_pct"] = peg.get("premium_discount_pct")
        # The exit-mark ladder, retained per run (it used to be the one field
        # history dropped). Always a row — unmeasured is written, not omitted.
        latest_dp["exit_mark"] = ladder_history_row(
            (report.get("asset_specific") or {}).get("liquidity"),
            unmeasured_reason="no_ladder_in_tracker_output")
    db.save()
    print(f"Appended to {HISTORY_DB_PATH}")

    history = db.get_asset_history("syrupUSDC", days=HISTORY_EXPORT_DAYS)
    export = {
        "exit_mark_note": (
            "exit_mark is the exit-quote ladder retained per run since 2026-10-01. "
            "null = the entry predates retention (not measured-and-missing); "
            "status 'unmeasured' = no ladder that run, with a reason. "
            "measured_at is the quote time — the tracker caches up to 2h, so "
            "dedupe on measured_at, not on the entry timestamp."),
        "asset": "syrupUSDC",
        "entries": [
            {
                "timestamp": dp["timestamp"],
                **({"classification_version": dp["classification_version"]} if "classification_version" in dp else {}),
                "collateral_ratio": dp.get("collateral_ratio"),
                "collateral_ratio_alt": dp.get("collateral_ratio_alt"),
                "nav": dp.get("nav"),
                "total_supply": dp.get("total_supply"),
                "total_backing": dp.get("total_backing"),
                "deployment_ratio_pct": dp.get("deployment_ratio_pct"),
                "unrealized_losses": dp.get("unrealized_losses"),
                "peg_market_price": dp.get("peg_market_price"),
                "peg_theoretical_price": dp.get("peg_theoretical_price"),
                "peg_premium_discount_pct": dp.get("peg_premium_discount_pct"),
                "exit_mark": dp.get("exit_mark"),
            }
            for dp in history
        ],
    }
    tmp = HISTORY_EXPORT_PATH + ".tmp"
    with open(tmp, "w") as f:
        json.dump(export, f, indent=2)
    os.replace(tmp, HISTORY_EXPORT_PATH)
    print(f"Exported {HISTORY_EXPORT_PATH} ({len(export['entries'])} entries, {HISTORY_EXPORT_DAYS}d window)")


def save_last_good(report):
    # Unique temp per writer — a fixed "<path>.tmp" is atomic against a crash
    # but not against a second writer, which is how backing_history.json lost
    # 33.7MB. Same defect, different file.
    tmp = f"{LAST_GOOD_JSON}.{os.getpid()}.{uuid.uuid4().hex[:8]}.tmp"
    with open(tmp, "w") as f:
        json.dump(report, f, indent=2)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, LAST_GOOD_JSON)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(description="syrupUSDC Backing & Risk Analyzer")
    parser.add_argument("--skip-loan-scan", action="store_true",
                        help="Skip Phase 2 event scan + per-loan reads (Phase 1 only)")
    parser.add_argument("--skip-history", action="store_true",
                        help="Skip writing history (debugging)")
    args = parser.parse_args()

    # 1. Vault state, strategies, governance, withdrawal queue
    vault = fetch_vault_state()
    if not vault:
        print("ERROR: vault state read failed", file=sys.stderr)
        sys.exit(1)

    # 2. Peg + DEX liquidity (passthrough from peg_tracker_latest_usd.json)
    peg = fetch_peg_and_liquidity()
    if not peg:
        print("WARNING: peg passthrough unavailable")
        peg = {}

    # 3. Headline APY (syrupGlobals → Maple REST → DefiLlama → manual constant)
    base_apy_pct = peg.get("yield_7d_apr_pct", 0)
    headline_apy, headline_apy_source, apy_breakdown = fetch_headline_apy(base_apy_pct)
    print(f"\n--- Yield ---")
    print(f"  base_7d_apr_pct:  {base_apy_pct:.2f}%")
    print(f"  headline_apy_pct: {headline_apy:.2f}% (source: {headline_apy_source})")
    if apy_breakdown:
        print(f"  core_apy_pct:     {apy_breakdown['core_apy_pct']:.2f}%")
        print(f"  boost_apy_pct:    {apy_breakdown['boost_apy_pct']:.2f}%")

    # 4. Loan enumeration (Phase 2)
    if args.skip_loan_scan:
        print("\n--- Skipping loan scan (--skip-loan-scan) ---")
        loan_book = aggregate_loan_book([], vault["principal_out"])
    else:
        cache = discover_loans()
        active_loans = filter_active_loans(cache)

        # 4a. Phase 2.5 — collateral enrichment via Maple GraphQL + Chainlink
        coll_map, pool_agg, source_status = fetch_loan_collateral_map()
        oracle_prices = {}
        if source_status == "maple_graphql":
            needed = {coll_map[a.lower()].get("asset")
                      for a in (l["loan_addr"] for l in active_loans)
                      if a.lower() in coll_map}
            oracle_prices = fetch_collateral_oracle_prices(needed)
            enrich_loans_with_collateral(active_loans, coll_map, oracle_prices)
            # 4a.i — Liquidity custody verification (on-chain EOA + balance).
            for loan in active_loans:
                classify_usdc(loan)
            fetch_liquidity_custody(active_loans)
        else:
            for loan in active_loans:
                loan["collateral"] = None
                loan["loan_meta_type"] = None
                loan["position_type"] = "loan"
                loan["custody"] = None

        loan_book = aggregate_loan_book(active_loans, vault["principal_out"])
        loan_book["collateral_summary"] = build_collateral_summary(
            active_loans, pool_agg, source_status,
            unrealized_losses=vault["unrealized_losses"])

        print(f"  active loans: {loan_book['active_loan_count']}, "
              f"borrowers: {loan_book['borrower_count']}, "
              f"top concentration: {loan_book['top_borrower_concentration_pct']:.1f}%")
        cs = loan_book["collateral_summary"]
        if cs.get("set_b_at_par"):
            print(f"  collateral mix: Set A {cs['set_a_overcollateralized']['pct_of_book']:.1f}% "
                  f"({fmt_usd(cs['set_a_overcollateralized']['principal_usd'])}) / "
                  f"Set B {cs['set_b_at_par']['pct_of_book']:.1f}% "
                  f"({fmt_usd(cs['set_b_at_par']['principal_usd'])})  "
                  f"[source={cs['data_source']}]")

    # 5. Build + persist
    # 4b. AUM history (pool-scoped, 30 daily points) — graceful degrade to None.
    aum_history = fetch_aum_history()

    # 4c. APY sparkline (30 daily points) — brand-wide syrupGlobals series.
    apy_history = fetch_apy_history()

    # 4d. Withdrawal queue time-context (event scan). Peripheral enrichment —
    # fetch_withdrawal_queue_timing is internally time-bounded and degrades to a
    # flagged null payload, but guard the call too so nothing here can ever block
    # the core backing snapshot from being written.
    try:
        wq_timing = fetch_withdrawal_queue_timing(vault)
    except Exception as e:
        print(f"  withdrawal-queue timing raised unexpectedly, continuing "
              f"without it: {type(e).__name__}: {str(e)[:120]}", flush=True)
        wq_timing = {
            "last_filled_timestamp_iso": None,
            "last_filled_age_seconds": None,
            "next_request_age_seconds": None,
            "current_cycle_start_timestamp_iso": None,
            "current_cycle_end_timestamp_iso": None,
            "cycle_duration_seconds": None,
            "timing_unavailable": True,
        }

    # 4e. Custody topology — single-key EOAs across this pool's trust stack.
    # Built from active_loans (full set), not loan_book["loans"] (top-25 only),
    # so smaller Liquidity custodies aren't dropped.
    custody_topology = build_custody_topology(
        vault,
        active_loans if not args.skip_loan_scan else [],
    )

    report = build_report(vault, peg, headline_apy, headline_apy_source,
                          apy_breakdown, loan_book, aum_history,
                          apy_history=apy_history, wq_timing=wq_timing,
                          custody_topology=custody_topology)

    if args.skip_history:
        save_json_report(report)
        return

    if validate_data(report):
        save_json_report(report)
        save_last_good(report)
        save_history(report)
    else:
        print("\nWARNING: validation failed — skipping dashboard snapshot, last-good, and history append")


if __name__ == "__main__":
    main()
