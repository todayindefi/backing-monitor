"""Versioned issuer-economic overlay; never changes loan-manager principal."""
from datetime import datetime, timezone

VERSION = "issuer_economic_v2_2026-10-28"
ISSUER = "https://maple.finance/transparency/products/syrupusdt"
GRAPHQL = "https://api.maple.finance/v2/graphql"
REVIEWED_AT = "2026-10-28"
CREDIT = set("""0x8a44ff7b9e755a9ea6a4ee0708b7d46c79eace4f
0x0d2df2bbad7744ea7fae8f8f7be7bc3221e02b9a
0x01a30de2836db8e3fce3168e33215018601c728f
0x79c1fce425ed3ff66ddab70f6691a5dedb1cdb9c
0xe37aaf037b87a3161efa4443cb190ff4deffe218
0x7fc443dd02ed6a0355cd3949c62abbd910cd87f0
0xa959fed92c3c5183222f1e3f726420756c632477""".split())


def classify_usdt(loan):
    """Exact reviewed addresses or address-specific Maple metadata, else unknown."""
    address = (loan.get('loan_addr') or '').lower()
    meta = loan.get('loan_meta_type')
    asset = (loan.get('collateral') or {}).get('asset')
    category, basis, source = 'unknown', 'No reviewed address or economic metadata', GRAPHQL
    if address in CREDIT:
        category, basis, source = 'credit', 'Exact loan address in issuer credit table', ISSUER
    elif address == '0x77e5c78e896fd74a3e5abcdef642129d48ee141f':
        category, basis, source = 'trading', 'Exact address: BTC basis trade, CME/Coinbase', ISSUER
    elif address == '0xe6b86b4b2499f9c8c2e9d32e725f75869c9b4688' and meta == 'tBills' and asset == 'USDtb' and loan.get('borrower', '').lower() == '0x8df6721f643e796c456ee080929e01c7f18e6122':
        category, basis = 'treasuries', 'Exact loan metadata tBills/USDtb; borrower 0x8DF6...6122 matches issuer USDtb custody'
    elif meta in {'amm', 'defi', 'tBills', 'termBasis', 'intercompany'}:
        category = {'amm': 'dex_lp', 'defi': 'defi', 'tBills': 'treasuries', 'termBasis': 'trading', 'intercompany': 'intercompany'}[meta]
        basis = 'Address-specific loanMeta.type=' + meta + '; issuer allocation equivalence not independently established'
    loan.setdefault('position_type_legacy_heuristic', loan.get('position_type'))
    loan['economic_classification'] = dict(category=category, source=source,
        evidence_basis=basis, reviewed_at=REVIEWED_AT, version=VERSION,
        assurance='issuer_assertion_not_independent_verification',
        metadata_observed_at=loan.get('metadata_observed_at'))
    loan['position_type'] = 'loan' if category == 'credit' else 'unknown' if category == 'unknown' else 'liquidity'
    # Compatibility bucket "liquidity" includes all identified non-credit strategies.
    loan['strategy_subtype'] = category if category not in {'credit', 'unknown'} else None


def coverage(loans):
    selected = [l for l in loans if l.get('position_type') == 'loan']
    measured = [l for l in selected if isinstance((l.get('collateral') or {}).get('usd'), (int, float)) and not isinstance(l['collateral']['usd'], bool) and math.isfinite(l['collateral']['usd']) and l['collateral']['usd'] >= 0]
    principal = sum(l['principal'] for l in selected)
    value = sum(l['collateral']['usd'] for l in measured)
    complete = bool(selected) and len(selected) == len(measured)
    return dict(denominator_basis='classified_credit_principal', denominator_usd=round(principal, 2),
        member_loan_addresses=[l['loan_addr'] for l in selected],
        measured_principal_usd=round(sum(l['principal'] for l in measured), 2),
        measured_collateral_usd=round(value, 2), complete=complete,
        collateral_ratio_pct=round(value / principal * 100, 2) if complete and principal else None,
        missing_loan_addresses=[l['loan_addr'] for l in selected if l not in measured])


# USDC membership is reviewed independently; never reuse USDT addresses.
import json
import math
from pathlib import Path

USDC_REVIEW = json.loads(Path(__file__).with_name('syrupusdc_position_review.json').read_text())
USDC_VERSION = USDC_REVIEW['version']


def classify_usdc(loan):
    address = (loan.get('loan_addr') or '').lower()
    reviewed = USDC_REVIEW['positions'].get(address)
    category, basis, source = 'unknown', 'No exact reviewed loan/borrower membership', GRAPHQL
    if reviewed and (loan.get('borrower') or '').lower() == reviewed['borrower']:
        required = reviewed.get('required_metadata_type')
        if required is None or loan.get('loan_meta_type') == required:
            category, basis, source = reviewed['category'], reviewed['basis'], reviewed['source']
        else:
            basis = 'Reviewed address but current metadata does not match reviewed economic type'
    loan.setdefault('position_type_legacy_heuristic', loan.get('position_type'))
    loan['economic_classification'] = dict(
        category=category, source=source, evidence_basis=basis,
        reviewed_at=USDC_REVIEW['reviewed_at'], version=USDC_VERSION,
        issuer_observed_at=USDC_REVIEW['issuer_observed_at'],
        issuer_evidence_sha256=USDC_REVIEW['issuer_sha256'],
        metadata_observed_at=loan.get('metadata_observed_at'),
        metadata_review_sha256=USDC_REVIEW['metadata_review_sha256'],
        assurance='issuer_assertion_and_address_metadata_not_independent_custody_verification')
    loan['position_type'] = 'loan' if category == 'credit' else 'unknown' if category == 'unknown' else 'liquidity'
    loan['strategy_subtype'] = category if category not in {'credit', 'unknown'} else None
