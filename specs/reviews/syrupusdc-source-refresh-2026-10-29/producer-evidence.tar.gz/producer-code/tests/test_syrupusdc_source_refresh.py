import math
from unittest.mock import patch
import syrupusdc_backing_analyzer as usdc
import syrup_multichain_supply as supply
from syrup_position_classification import classify_usdc, coverage, USDC_REVIEW


def test_usdc_review_requires_exact_address_borrower_and_strategy_metadata():
    rows=[]
    for addr, review in USDC_REVIEW['positions'].items():
        row=dict(loan_addr=addr, borrower=review['borrower'], principal=5,
                 loan_meta_type=review.get('required_metadata_type'), collateral={'usd':None})
        classify_usdc(row);rows.append(row)
        assert row['economic_classification']['category']==review['category']
    assert sum(r['position_type']=='loan' for r in rows)==24
    assert sum(r['position_type']=='liquidity' for r in rows)==9
    treasury=next(r for r in rows if r['loan_addr']=='0x00079d18bab17acb57ead11a18fc58002a0cb110')
    assert treasury['strategy_subtype']=='treasuries'
    treasury['loan_meta_type']=None;classify_usdc(treasury)
    assert treasury['position_type']=='unknown'
    row=rows[0].copy();row['borrower']='0xunreviewed';classify_usdc(row)
    assert row['position_type']=='unknown'
    unknown=dict(loan_addr='0xnew',borrower='0xnew',loan_meta_type='tBills',collateral={'asset':'PYUSD'})
    classify_usdc(unknown);assert unknown['position_type']=='unknown'


def test_credit_coverage_requires_finite_numeric_values_and_excludes_strategies():
    for value in [None, float('nan'),float('inf'),'100',True,-1]:
        rows=[dict(loan_addr='a',position_type='loan',principal=100,collateral={'usd':value}),
              dict(loan_addr='b',position_type='liquidity',principal=1000,collateral={'usd':10000})]
        c=coverage(rows)
        assert c['denominator_usd']==100 and c['collateral_ratio_pct'] is None
        assert not c['complete'] and c['missing_loan_addresses']==['a']
    rows[0]['collateral']['usd']=150
    assert coverage(rows)['collateral_ratio_pct']==150


def test_usdc_registry_is_not_resident_reconciliation_even_if_all_reads_succeed():
    raw=dict(supply_raw='1000000',decimals=6,supply_native=1)
    with patch.object(supply,'_fetch_evm_total_supply',return_value=raw),patch.object(supply,'_fetch_solana_token_supply',return_value=raw):
        result=supply.build_syrup_multi_chain_block('syrupusdc',1,100,100)
    assert set(result['chains_known'])=={'ethereum','solana','base','arbitrum','monad','ink','tempo','robinhood','arc'}
    assert result['chains_unavailable']==[]
    assert result['cross_chain_supply_reconciliation_pct'] is None
    assert result['cross_chain_supply_reconciliation_complete'] is False
    assert result['total_supply_usd_across_chains'] is None
    assert next(c for c in result['chains'] if c['chain']=='ethereum')['supply_native']==100


def test_usdc_aggregate_keeps_unknown_out_of_credit_and_preserves_raw_accounting():
    addr, review=next((a,r) for a,r in USDC_REVIEW['positions'].items() if r['category']=='credit')
    template=dict(rate_pct=5,payment_due_date=2**31,is_impaired=False,is_called=False,
                  is_in_default=False,payment_interval_days=30)
    rows=[dict(template,loan_addr=addr,borrower=review['borrower'],principal=60,collateral={'usd':None}),
          dict(template,loan_addr='0xnew',borrower='0x0000000000000000000000000000000000000002',principal=40)]
    book=usdc.aggregate_loan_book(rows,principal_out=110)
    assert book['principal_total_usd']==100 and book['enumeration_residual']==10
    assert book['principal_loans_only_usd']==60 and book['principal_unknown_usd']==40
    assert book['concentration_loans_only']['denominator_basis']=='classified_credit_principal'
    assert book['concentration_loans_only']['excluded_loan_addresses']==['0xnew']
    assert book['credit_coverage']['collateral_ratio_pct'] is None
    assert all(r['rate_pct']==5 for r in book['loans'])
