"""
Maple Syrup family aggregator — cross-pool view over syrupUSDC + syrupUSDT.

Reads the two per-pool JSONs emitted by the standalone analyzers, computes
borrower overlap + asset aggregates + shared-governance summary, and emits
data/syrup_family.json.

Loans/Liquidity reconciliation (verified 2026-05-04 against
app.maple.finance/earn/details):
  - syrupGlobals.loansValue is the brand-wide LOANS-only field (~$1.27B).
  - Per-pool TVL sum is LOANS + LIQUIDITY (~$1.61B). The two reconcile
    cleanly once positions are split via classify_position_type.
  - syrupGlobals.aumTimeSeries is a separate, still-anomalous series — see
    per-pool analyzer notes for that.

Cron position: must run AFTER both per-pool analyzers complete. If either
input is missing or stale (>2h old), emits `data_source: "incomplete"`
rather than producing wrong totals.

Usage:
    python3 syrup_family_analyzer.py
"""

import json
from liquidity_tracker import (with_fill_ratio, with_cost_conventions,
                               depth_from_ladder, IMPACT_BASIS_VENUE_SPOT)
import os
import uuid
import sys
from collections import defaultdict
from datetime import datetime, timezone

import risk_feed_client
from risk_feed_client import report_url_for
from dashboard_links import internal_link

DATA_DIR  = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
USDC_JSON = os.path.join(DATA_DIR, "syrupusdc_backing.json")
# Must match STAGING_SUFFIX in the per-pool analyzers.
STAGING_SUFFIX = ".staging"
USDT_JSON = os.path.join(DATA_DIR, "syrupusdt_backing.json")
OUTPUT    = os.path.join(DATA_DIR, "syrup_family.json")

STALE_SECONDS = 2 * 3600  # 2h freshness window per handoff §2

# Shared governance — verified from MapleGlobals reads in the per-pool analyzers.
SHARED_GOVERNANCE = {
    "governor": "0x2eFFf88747EB5a3FF00d4d8d0f0800E306C0426b",
    "min_delay_seconds": 86400,
    "operational_admin": "0xCe1cE7c7F436DCc4E28Bc8bf86115514d3DC34E8",
    "security_admin": "0x6b1A78C1943b03086F7Ee53360f9b0672bD60818",
}

# Inherited from per-pool analyzers (same module-level map). Empty until
# Maple/labelling services confirm identities; pool analyzers expose
# borrower_firm via concentration.borrowers[i].firm.
BORROWER_FIRM_MAP: dict[str, str] = {}

# ---------------------------------------------------------------------------
# 5-axis dashboard data contract (Tier-A #5, Maple credit vaults).
#
# These pools are CREDIT VAULTS, not peg assets. The per-pool analyzers
# (syrupusdc_backing_analyzer.py / syrupusdt_backing_analyzer.py) build the
# canonical backing JSONs but nest their peg/liquidity blocks under
# asset_specific.* and do NOT emit the top-level peg/liquidity/backing/
# dependencies/issuer blocks the common render layer reads. This aggregator —
# which already loads both per-pool reports — promotes those top-level blocks
# (additive, non-destructive) before re-writing each per-pool JSON, then builds
# the family roll-up. See riskAnalyst/specs/handoffs/
# dashboard-5axis-syrup-usdc-usdt.md (Part 1).
# The public issuer block uses the risk feed's ISSUER score and issuer-prefixed
# provenance. Contract structural risk is published separately by riskAnalyst's
# contract overlay; putting a structural score in this block makes the common
# renderer select the wrong axis solely because that key exists.
SYRUP_AXIS_CONFIG = {
    "syrupusdc": {
        "report_url": report_url_for("syrupusdc"),
    },
    "syrupusdt": {
        "report_url": report_url_for("syrupusdt"),
    },
}

# Backing PCR bands tuned for a credit vault: PCR caps at 100 (it only dips
# below when unrealized losses appear), so <100 is the real stress signal.
# cr_pct cutoffs are [>=5, >=4, >=3, >=2]; the leading 101 is unreachable, so
# a fully-funded 100% PCR rates 4/5 (Healthy) rather than the stablecoin
# "thin 100% = 3/5". Read by CommonRenderer via asset_specific.axis_thresholds.
SYRUP_BACKING_AXIS_THRESHOLDS = {"cr_pct": [101, 100, 98, 95]}

# free_liquidity_pct → band score (instant-exit capacity, not a depth ladder).
def _syrup_liquidity_band_score(free_liquidity_pct):
    if free_liquidity_pct is None:
        return None
    if free_liquidity_pct >= 20:
        return 5
    if free_liquidity_pct >= 10:
        return 4
    if free_liquidity_pct >= 5:
        return 3
    if free_liquidity_pct >= 2:
        return 2
    return 1


def now_iso():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _load(path):
    if not os.path.exists(path):
        return None
    try:
        with open(path, "r") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return None


def _is_fresh(d):
    """True iff `timestamp` is parseable AND within STALE_SECONDS of now."""
    ts = d.get("timestamp")
    if not ts:
        return False
    try:
        # Handles both "...Z" and "+00:00" suffixes.
        t = datetime.fromisoformat(ts.replace("Z", "+00:00"))
    except ValueError:
        return False
    age = (datetime.now(timezone.utc) - t).total_seconds()
    return age <= STALE_SECONDS


def _healthy(d):
    """Loan book + vault state present and well-shaped."""
    if not isinstance(d, dict):
        return False
    a = d.get("asset_specific") or {}
    if not isinstance(a.get("loan_book"), dict):
        return False
    if a["loan_book"].get("loans") is None:
        return False
    if not isinstance(a.get("vault_state"), dict):
        return False
    return True


def _emit_incomplete(reason):
    out = {
        "schema_version": 1,
        "timestamp": now_iso(),
        "data_source": "incomplete",
        "reason": reason,
    }
    tmp = OUTPUT + ".tmp"
    with open(tmp, "w") as f:
        json.dump(out, f, indent=2)
    os.replace(tmp, OUTPUT)
    print(f"  emitted incomplete: {reason}")


def _attach_syrup_axis_blocks(report, slug):
    """Promote the 5-axis dashboard data contract onto the top level of a
    per-pool syrup backing report: peg / liquidity / backing / dependencies /
    issuer (+ top-level report_url + asset_specific.axis_thresholds.backing).

    Additive and non-destructive — every existing summary.*, backing_breakdown,
    risk_flags, and asset_specific.* field is preserved untouched. syrup pools
    are CREDIT VAULTS, so each axis sources from the pool's own structures
    (summary + asset_specific.{vault_state, loan_book}) with a credit-vault
    frame, NOT a peg/DEX-depth frame:
      - peg        ← NAV-anchored (redeems at NAV via Maple's withdrawal queue)
      - liquidity  ← free-liquidity ratio (instant-exit capacity), NOT depth
      - backing    ← PCR + credit-quality detail + per-asset PCR threshold
      - dependencies.upstream ← top borrowers + dominant collateral + curator
      - issuer     ← Maple Finance curator, links to the retail report
    See riskAnalyst/specs/handoffs/dashboard-5axis-syrup-usdc-usdt.md (Part 1).
    """
    cfg = SYRUP_AXIS_CONFIG.get(slug, {})
    summary = report.get("summary") or {}
    asp = report.get("asset_specific") or {}
    vault_state = asp.get("vault_state") or {}
    loan_book = asp.get("loan_book") or {}
    backing_breakdown = report.get("backing_breakdown") or []

    report["report_url"] = cfg.get("report_url")

    # --- Axis 1: peg — real secondary market-price vs NAV ---------------------
    # Promote the genuine, tracked market-vs-NAV signal from asset_specific.peg
    # (CoinGecko secondary mark vs theoretical NAV). Primary redemption is still
    # full-size at NAV via Maple's withdrawal queue; the secondary market is the
    # instant-but-thin path and trades at a small discount, which we now chart.
    # The peg time series is logged FLAT into the per-pool backing-history file
    # (peg_market_price) — point Layer 2 at it via history_ref/history_field
    # (mirrors the working apxUSD pattern; the dotted peg_tracker_history path is
    # NOT readable by the common flat-entries loader).
    asp_peg = asp.get("peg") or {}
    report["peg"] = {
        "market_price": asp_peg.get("market_price"),
        "nav": asp_peg.get("theoretical_price"),
        "premium_discount_pct": asp_peg.get("premium_discount_pct"),
        "source": asp_peg.get("source"),
        "history_ref": f"{slug}_backing_history.json",
        "history_field": "peg_market_price",
        "note": "Primary redemption is full-size at NAV via Maple's withdrawal "
                "queue; secondary trades at a small discount (charted).",
    }

    # --- Axis 2: liquidity — instant-exit capacity (NOT a depth ladder) -------
    # free_liquidity / total_assets = the share of the vault that can be exited
    # immediately at NAV; larger exits queue over Maple's withdrawal cycle. We
    # deliberately suppress secondary DEX depth (total_2pct_depth=null, pools=[])
    # so the band doesn't rate off a thin, misleading secondary pool.
    free_liq = vault_state.get("free_liquidity")
    total_assets = vault_state.get("total_assets")
    free_liquidity_pct = (
        round(free_liq / total_assets * 100, 2)
        if isinstance(free_liq, (int, float))
        and isinstance(total_assets, (int, float)) and total_assets
        else None
    )
    band_score = _syrup_liquidity_band_score(free_liquidity_pct)
    report["liquidity"] = {
        "free_liquidity_pct": free_liquidity_pct,
        "band_score": band_score,
        "total_2pct_depth": None,
        "pools": [],
        "deployment_ratio_pct": summary.get("deployment_ratio_pct"),
        "note": (
            f"~{free_liquidity_pct:.0f}% free liquidity; larger exits queue at "
            "NAV over Maple's withdrawal cycle."
            if free_liquidity_pct is not None
            else "Free liquidity unavailable; exits queue at NAV over Maple's "
                 "withdrawal cycle."
        ),
    }
    if slug == "syrupusdt":
        report["liquidity"]["total_2pct_depth_note"] = (
            "Unmeasured, not zero: no exit-mark ladder reached this run. A venue "
            "IS configured (2026-10-01: Uniswap v4 syrupUSDT/USDT 0.08% on "
            "Ethereum, ~$5.0M reserve), so an absent ladder here is a failed or "
            "pending quote, not an absent market. The Maple withdrawal queue is "
            "the NAV redemption path and is not substituted for a DEX mark; TVL "
            "is not depth."
        )
    # The base analyzer stages the tracker payload under asset_specific. Promote
    # a measured ladder to the canonical axis path while retaining that copy for
    # existing consumers.
    asp_liquidity = asp.get("liquidity") or {}
    if asp_liquidity.get("quotes"):
        # ⚠️ This ladder is the TRACKER's, promoted verbatim — so it carries the
        # tracker's semantics (price impact against the venue's own smallest
        # rung) and must say so. Promoting a measurement without its basis is
        # how a figure arrives somewhere it can be compared against a differently
        # computed one.
        with_fill_ratio(asp_liquidity.get("quotes") or {})
        asp_liquidity.setdefault("slippage_bps_basis", IMPACT_BASIS_VENUE_SPOT)
        with_cost_conventions(asp_liquidity)
        # Where the ladder stops, said in the payload: `ladder_exhausted` /
        # is_floor=True means the deepest rung still cleared and the crossing
        # is ABOVE what was asked — not that one was found. The axis's
        # total_2pct_depth stays null (the band rates instant-exit capacity, not
        # secondary depth); this is the measurement beside it, not a substitute.
        quoted = [float(k) for k, q in asp_liquidity["quotes"].items()
                  if isinstance(q, dict) and "error" not in q]
        asp_liquidity["largest_rung_usd"] = max(quoted) if quoted else None
        asp_liquidity["depth"] = depth_from_ladder(asp_liquidity["quotes"])
        report["liquidity"]["exit_mark"] = asp_liquidity
        report["liquidity"]["total_2pct_depth_note"] = (
            "Null by design, not zero: this axis rates instant-exit capacity at NAV, not "
            "secondary depth. The measured DEX exit ladder is liquidity.exit_mark "
            "and its 2% crossing search (floor vs bracketed) is "
            "liquidity.exit_mark.depth."
        )

    # --- Axis 3: backing — PCR + credit quality -------------------------------
    # Headline = Pool Coverage Ratio (summary.collateral_ratio, ~100). Credit-
    # quality context rides along as detail: impairment/call/default counts (all
    # 0 today), unrealized losses, and the loans/liquidity principal split
    # (~78/22). Per-asset PCR threshold is emitted under
    # asset_specific.axis_thresholds.backing so 100% PCR rates Healthy (4/5).
    loans_principal = loan_book.get("principal_loans_only_usd")
    liq_principal = loan_book.get("principal_liquidity_usd")
    total_principal = loan_book.get("principal_total_usd")
    report["backing"] = {
        "collateral_ratio": summary.get("collateral_ratio"),
        "collateral_ratio_scale": "percent",
        # PCR = (free USDC + sum(strategy.assetsUnderManagement)) / pool.totalAssets.
        #
        # ⚠️ NOT a tautology, and the distinction was worth checking rather than
        # assuming, because a ~100 reading looks the same either way. The three
        # terms are INDEPENDENT contract reads — pool.totalAssets(),
        # usdc.balanceOf(pool), and per-strategy assetsUnderManagement() — so the
        # denominator is the vault's own accounting and the numerator is its
        # components read separately. It sits at ~100 because they AGREE, and a
        # divergence would show. Same design as sUSDS's balanceOf/totalAssets:
        # two sources for one quantity, where agreement is the evidence.
        #
        # That is what earns the tight [101,100,98,95] bands. If the denominator
        # were reconstructed from the numerator, those bands would make an
        # identity look like a finely-measured quantity — precision implying
        # movement that cannot happen.
        #
        # ⚠️ Do NOT divide total_backing by total_supply: supply is in SHARES, so
        # the quotient (~118% here) is assets-per-share — a NAV, not a coverage
        # ratio. It is 18pp from the PCR because it answers a different question.
        "collateral_ratio_basis": (
            "Principal collateral ratio: (free USDC + sum of strategy "
            "assetsUnderManagement) / pool.totalAssets(). Three INDEPENDENT "
            "contract reads, so ~100% is the vault's components agreeing with "
            "its own accounting, not an identity — a shortfall would show. "
            "⚠️ total_supply is denominated in SHARES: total_backing/total_supply "
            "is assets-per-share (a NAV, ~1.18) and NOT a coverage ratio. The "
            "two figures answer different questions."
        ),
        "total_backing": summary.get("total_backing"),
        "surplus_deficit": summary.get("surplus_deficit"),
        "surplus_deficit_basis": (
            "pool.totalAssets() minus its independently-read components — the "
            "reconciliation residual, currently a few dollars on a book of "
            "hundreds of millions. NOT backing minus supply, which would be "
            "meaningless here because supply is in shares."
        ),
        "breakdown": backing_breakdown,
        "detail": {
            "impaired_count": loan_book.get("impaired_count"),
            "called_count": loan_book.get("called_count"),
            "default_count": loan_book.get("default_count"),
            "unrealized_losses": summary.get("unrealized_losses"),
            "principal_loans_only_usd": loans_principal,
            "principal_liquidity_usd": liq_principal,
            "principal_total_usd": total_principal,
            "loans_pct": (round(loans_principal / total_principal * 100, 1)
                          if isinstance(loans_principal, (int, float))
                          and isinstance(total_principal, (int, float))
                          and total_principal else None),
            "liquidity_pct": (round(liq_principal / total_principal * 100, 1)
                              if isinstance(liq_principal, (int, float))
                              and isinstance(total_principal, (int, float))
                              and total_principal else None),
        },
    }

    # Per-asset PCR bands (credit-vault frame). The common layer reads this from
    # asset_specific.axis_thresholds; merge additively into any existing dict.
    axis_thresholds = asp.get("axis_thresholds")
    if not isinstance(axis_thresholds, dict):
        axis_thresholds = {}
    axis_thresholds["backing"] = dict(SYRUP_BACKING_AXIS_THRESHOLDS)
    asp["axis_thresholds"] = axis_thresholds
    report["asset_specific"] = asp

    # --- Axis 4: dependencies — credit deps from the loan book ----------------
    upstream = _syrup_upstream(loan_book)
    pct_sum = round(sum(
        value for row in upstream for value in row.get("percentages", [])
        if isinstance(value, (int, float))
    ), 2)
    report["dependencies"] = {
        "upstream": upstream,
        "pct_sums_to": pct_sum,
        "is_partition": False,
        "is_partition_basis": (
            f"The displayed percentages sum to {pct_sum:g}%, but they are not "
            "mutually exclusive slices. Top-1 borrower concentration is nested "
            "inside top-3, and borrower concentration and collateral composition "
            "are different dimensions."
        ),
        "downstream": [],
        "downstream_tracked": False,
        "note": (
            "These rows are non-additive and do not partition one base. Borrower "
            "concentration and collateral composition are different dimensions; "
            "top-1 is nested within top-3. Do not sum the percentages."
        ),
    }

    # --- Axis 5: issuer — Maple Finance as curator ----------------------------
    # Centralization-under-Maple custody (single-key pool delegate with
    # discretionary loan-funding authority) is detailed in the linked report.
    risk_feed_client.attach_issuer_axis(
        report, slug, cfg.get("report_url"),
        extra={
            "curator": "Maple Finance",
            "attestation_age_days": None,
        },
    )
    return report


def _syrup_upstream(loan_book):
    """Build the dependencies.upstream cards from a pool's loan_book: top
    borrowers, the dominant collateral asset(s), and the Maple curator. All
    link_type 'none' (credit counterparties have no asset dashboard) except
    collateral assets we already track on the dashboard (e.g. cbBTC)."""
    upstream = []

    # Top-borrowers card — prefer the loans-only concentration (excludes at-par
    # pool-owned liquidity positions). When a pool exposes only the COMBINED
    # concentration (e.g. syrupUSDT has no concentration_loans_only), label the
    # figure honestly: it conflates third-party borrowers with pool-owned
    # liquidity strategies, so it overstates true borrower concentration.
    conc_loans_only = loan_book.get("concentration_loans_only")
    conc = conc_loans_only or loan_book.get("concentration") or {}
    is_combined = conc_loans_only is None
    top3 = conc.get("top_3_share_pct")
    top1 = conc.get("top_1_share_pct")
    n_borrowers = conc.get("total_borrowers")
    if top3 is not None:
        scope = "AUM (incl. pool-owned liquidity)" if is_combined else "loan book"
        metric = f"top-3 ≈ {top3:.0f}% of {scope}"
        if top1 is not None:
            metric += f" · top-1 ≈ {top1:.0f}% of same {scope} (inside top-3)"
        upstream.append({
            "kind": "borrowers",
            "name": "Top borrowers",
            "metric": metric,
            "percentages": [v for v in (top3, top1) if isinstance(v, (int, float))],
            "detail": (f"{n_borrowers} counterparties"
                       if n_borrowers is not None else None),
            "link_type": "none",
        })

    # Dominant-collateral card(s) — top 1-2 collateral assets by principal.
    by_asset = ((loan_book.get("collateral_summary") or {}).get("by_asset")) or []
    # Dashboards we already host, keyed by collateral symbol → internal link.
    # Resolved through dashboard_links so an absent feed degrades to "none".
    internal_assets = {"cbBTC": internal_link("cbbtc")[0]}
    for entry in by_asset[:2]:
        asset = entry.get("asset")
        pct = entry.get("pct_of_book")
        n_loans = entry.get("loans")
        if not asset or pct is None:
            continue
        link = internal_assets.get(asset)
        upstream.append({
            "kind": "collateral",
            "name": f"{asset} collateral",
            "metric": (f"{pct:.0f}% of loan principal by collateral asset"
                       + (f" · {n_loans} loans" if n_loans is not None else "")),
            "percentages": [pct],
            "link_type": "internal" if link else "none",
            "link": link,
        })

    # Curator card.
    upstream.append({
        "kind": "curator",
        "name": "Maple Finance — curator",
        "metric": "Pool delegate / curator",
        "link_type": "none",
    })
    return upstream


def pool_summary(d, slug):
    a = d["asset_specific"]
    vs = a["vault_state"]
    lb = a["loan_book"]
    cs = lb.get("collateral_summary") or {}
    set_a = cs.get("set_a_overcollateralized") or {}
    set_b = cs.get("set_b_at_par") or {}
    gov = a.get("governance") or {}
    pd = gov.get("pool_delegate") or {}
    # Backward-compat: pool_delegate used to be a flat string.
    if isinstance(pd, str):
        delegate_addr, delegate_is_eoa = pd, gov.get("pool_delegate_is_eoa")
    else:
        delegate_addr = pd.get("address")
        delegate_is_eoa = pd.get("is_eoa")
    return {
        "slug": slug,
        "name": d["asset"],
        "pool_address": vs.get("pool"),
        "underlying": "USDC" if slug == "syrupusdc" else "USDT",
        "total_assets_usd": vs.get("total_assets"),
        "total_loans_usd": vs.get("principal_out"),
        "free_usd": vs.get("free_usdc"),
        "active_loan_count": lb.get("active_loan_count") or 0,
        "set_a_principal_usd": set_a.get("principal_usd") or 0,
        "set_b_principal_usd": set_b.get("principal_usd") or 0,
        "principal_loans_only_usd": lb.get("principal_loans_only_usd") or 0,
        "principal_liquidity_usd": lb.get("principal_liquidity_usd") or 0,
        "principal_total_usd": lb.get("principal_total_usd") or 0,
        "loans_only_count": lb.get("loans_only_count") or 0,
        "liquidity_count": lb.get("liquidity_count") or 0,
        "pool_collateral_value_usd": cs.get("pool_collateral_value_usd") or 0,
        "delegate_address": delegate_addr,
        "delegate_is_eoa": delegate_is_eoa,
        "unrealized_losses_usd": vs.get("unrealized_losses") or 0,
    }


def _build_brand_wide_custody_topology(usdc, usdt, pools):
    """Union per-pool custody_topology entries into a brand-wide inventory.

    Entries with the same address are merged: capital_under_control_usd sums
    when the role is "custody" (a custody EOA can hold liquidity from both
    pools); pool-specific delegate roles stay separate (each pool has its
    own delegate).
    """
    by_addr = {}
    for d in (usdc, usdt):
        ct = ((d.get("asset_specific") or {}).get("governance") or {}) \
            .get("custody_topology") or {}
        for entry in ct.get("entries", []):
            addr = (entry.get("address") or "").lower()
            if not addr:
                continue
            if addr in by_addr:
                existing = by_addr[addr]
                existing["capital_under_control_usd"] = round(
                    (existing.get("capital_under_control_usd") or 0)
                    + (entry.get("capital_under_control_usd") or 0), 2
                )
                if "loan_book_principal_usd" in existing:
                    existing["loan_book_principal_usd"] = round(
                        (existing.get("loan_book_principal_usd") or 0)
                        + (entry.get("loan_book_principal_usd") or 0), 2
                    )
            else:
                by_addr[addr] = dict(entry)

    entries = sorted(
        by_addr.values(),
        key=lambda e: -(e.get("capital_under_control_usd") or 0),
    )
    total = sum(e.get("capital_under_control_usd") or 0 for e in entries)
    return {
        "scope": "brand_wide",
        "single_key_eoa_count": len(entries),
        "total_capital_under_eoa_control_usd": round(total, 2),
        "entries": entries,
    }


def _build_cross_pool_concentration(by_borrower_principal, total):
    if total <= 0 or not by_borrower_principal:
        return {"total_borrowers": 0, "top_1_share_pct": 0,
                "top_3_share_pct": 0, "top_5_share_pct": 0,
                "top_10_share_pct": 0, "hhi": 0,
                "hhi_bucket": "unconcentrated", "borrowers": []}
    sorted_b = sorted(by_borrower_principal.items(), key=lambda kv: -kv[1])
    shares = [p / total * 100 for _, p in sorted_b]
    hhi = sum(s * s for s in shares)
    bucket = ("unconcentrated" if hhi < 1500
              else "moderate" if hhi < 2500 else "concentrated")
    top10 = [{"address": addr, "principal_usd": round(p, 2),
              "share_pct": round(p / total * 100, 2),
              "borrower_firm": BORROWER_FIRM_MAP.get(addr)}
             for addr, p in sorted_b[:10]]
    return {
        "denominator_usd": round(total, 2),
        "total_borrowers": len(sorted_b),
        "top_1_share_pct": round(sum(p for _, p in sorted_b[:1]) / total * 100, 2),
        "top_3_share_pct": round(sum(p for _, p in sorted_b[:3]) / total * 100, 2),
        "top_5_share_pct": round(sum(p for _, p in sorted_b[:5]) / total * 100, 2),
        "top_10_share_pct": round(sum(p for _, p in sorted_b[:10]) / total * 100, 2),
        "hhi": round(hhi),
        "hhi_bucket": bucket,
        "borrowers": top10,
    }


def loans_by_borrower(d):
    by = defaultdict(list)
    for loan in d["asset_specific"]["loan_book"]["loans"]:
        by[loan["borrower"].lower()].append(loan)
    return by


def _loan_summary(loan):
    coll = loan.get("collateral") or {}
    return {
        "loan_addr":        loan.get("loan_addr"),
        "collateral_asset": coll.get("asset"),
        "principal_usd":    loan.get("principal"),
        "init_pct":         coll.get("init_level_pct"),
    }


def main():
    print("--- Syrup family aggregator ---")
    # ⚠️ Read the STAGING file the per-pool analyzers wrote this run, not the
    # published one — which now only ever holds a COMPLETE payload and would
    # otherwise be re-enriched from last hour's data if a base analyzer failed.
    # Falling back to the published file would silently republish stale inputs
    # under a fresh timestamp, which is the failure this whole change removes.
    usdc = _load(USDC_JSON + STAGING_SUFFIX)
    usdt = _load(USDT_JSON + STAGING_SUFFIX)
    for _name, _d in (("syrupusdc", usdc), ("syrupusdt", usdt)):
        if _d is None:
            raise RuntimeError(
                f"{_name}: no staging payload from this run "
                f"({_name}_backing.json{STAGING_SUFFIX} missing or unreadable). "
                f"Refusing to publish — the existing payload keeps its last "
                f"complete version rather than being restamped from stale input."
            )

    # Refuse if either is missing core fields.
    if not _healthy(usdc):
        _emit_incomplete(f"{os.path.basename(USDC_JSON)} missing or malformed")
        return
    if not _healthy(usdt):
        _emit_incomplete(f"{os.path.basename(USDT_JSON)} missing or malformed")
        return

    # Refuse if either is stale (handoff §2).
    if not _is_fresh(usdc):
        _emit_incomplete(f"{os.path.basename(USDC_JSON)} stale (>{STALE_SECONDS//3600}h)")
        return
    if not _is_fresh(usdt):
        _emit_incomplete(f"{os.path.basename(USDT_JSON)} stale (>{STALE_SECONDS//3600}h)")
        return

    # ------------------------------------------------------------------
    # 5-axis data contract — promote the top-level peg/liquidity/backing/
    # dependencies/issuer blocks onto each per-pool report (additive) and
    # re-write the per-pool JSONs in place. The per-pool analyzers run first
    # (cron order: per-pool → family → validator), so we enrich their output
    # without touching any existing field. See _attach_syrup_axis_blocks.
    # ------------------------------------------------------------------
    # ⚠️ This is the PUBLISHER. The per-pool analyzers write <path>.staging and
    # this step is the only thing that ever creates the published filename, so a
    # consumer can never observe a valid-but-incomplete payload there — not
    # merely unlikely, unrepresentable.
    #
    # The timestamp therefore means "complete", not "started", which is what a
    # freshness check needs it to mean.
    for d, slug, path in ((usdc, "syrupusdc", USDC_JSON),
                          (usdt, "syrupusdt", USDT_JSON)):
        _attach_syrup_axis_blocks(d, slug)
        # ⚠️ Assert on the RESULT, not on the call having run. Every failure this
        # week produced an absence, and nothing asserted on absence.
        missing = [a for a in ("peg", "liquidity", "backing", "dependencies", "issuer")
                   if not isinstance(d.get(a), dict)]
        if missing:
            raise RuntimeError(
                f"{slug}: refusing to publish — axis blocks missing after "
                f"enrichment: {missing}. The staging file is left in place; the "
                f"published payload keeps its last complete version."
            )
        # Unique temp per writer — a fixed "<path>.tmp" is atomic against a
        # crash, not against a second writer.
        tmp = f"{path}.{os.getpid()}.{uuid.uuid4().hex[:8]}.tmp"
        with open(tmp, "w") as f:
            json.dump(d, f, indent=2)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
        print(f"  published 5-axis payload → {os.path.basename(path)}")

    pools = [pool_summary(usdc, "syrupusdc"), pool_summary(usdt, "syrupusdt")]

    # ------------------------------------------------------------------
    # Combined totals — computed from per-pool data only.
    #
    # Loans/Liquidity reconciliation (handoff 2026-05-04): syrupGlobals.loansValue
    # is the brand-wide LOANS-only field; per-pool TVL sum is LOANS+LIQUIDITY.
    # Both reconcile cleanly once positions are split via classify_position_type.
    # ------------------------------------------------------------------
    total_loans_usd = sum(p["total_loans_usd"] or 0 for p in pools)
    total_aum_usd   = sum(p["total_assets_usd"] or 0 for p in pools)
    set_a_principal = sum(p["set_a_principal_usd"] for p in pools)
    set_b_principal = sum(p["set_b_principal_usd"] for p in pools)

    # Loans/Liquidity split — matches Maple's AUM Details page.
    aum_loans_usd     = sum(p["principal_loans_only_usd"] for p in pools)
    aum_liquidity_usd = sum(p["principal_liquidity_usd"] for p in pools)
    aum_unknown_usd = sum(d["asset_specific"]["loan_book"].get("principal_unknown_usd", 0) for d in (usdc, usdt))
    aum_total_usd     = aum_loans_usd + aum_liquidity_usd + aum_unknown_usd

    # Credit-only coverage uses exact members and complete row measurements;
    # non-credit strategy collateral is never assumed equal to its principal.
    pool_collateral_total = sum(p["pool_collateral_value_usd"] for p in pools)
    # Pool aggregate collateral cannot be allocated by assuming strategy collateral=principal.
    credit_coverages = [(d["asset_specific"]["loan_book"].get("credit_coverage") or {}) for d in (usdc, usdt)]
    coverage_complete = all(c.get("complete") is True for c in credit_coverages)
    loans_only_collateral_usd = sum(c.get("measured_collateral_usd", 0) for c in credit_coverages) if coverage_complete else None
    collateral_ratio_loans_only_pct = (loans_only_collateral_usd / aum_loans_usd * 100
        if coverage_complete and aum_loans_usd else None)

    combined = {
        "total_aum_usd":            round(total_aum_usd, 2),
        "total_loans_usd":          round(total_loans_usd, 2),
        # Loans/Liquidity split
        "aum_loans_usd":            round(aum_loans_usd, 2),
        "aum_liquidity_usd":        round(aum_liquidity_usd, 2),
        "aum_total_usd":            round(aum_total_usd, 2),
        "loans_only_count":         sum(p["loans_only_count"] for p in pools),
        "liquidity_count":          sum(p["liquidity_count"] for p in pools),
        "collateral_ratio_loans_only_pct": (
            round(collateral_ratio_loans_only_pct, 2)
            if collateral_ratio_loans_only_pct is not None else None
        ),
        "loans_only_collateral_usd": round(loans_only_collateral_usd, 2) if loans_only_collateral_usd is not None else None,
        "loans_only_coverage_complete": coverage_complete,
        "classification_basis": "Per-pool versioned exact economic membership; issuer assertions and metadata, not independently verified custody",
        "classification_versions": {slug: d["asset_specific"]["loan_book"].get("classification_version") for slug, d in (("syrupusdc", usdc), ("syrupusdt", usdt))},
        "principal_unknown_usd": sum(d["asset_specific"]["loan_book"].get("principal_unknown_usd", 0) for d in (usdc, usdt)),
        # Combined view (kept for back-compat with existing renderer)
        "active_loan_count":        sum(p["active_loan_count"] for p in pools),
        "set_a_principal_usd":      round(set_a_principal, 2),
        "set_b_principal_usd":      round(set_b_principal, 2),
        "set_a_pct":                round(set_a_principal / total_loans_usd * 100, 2)
                                       if total_loans_usd > 0 else None,
        "set_b_pct":                round(set_b_principal / total_loans_usd * 100, 2)
                                       if total_loans_usd > 0 else None,
        "loans_below_init_count":   sum(
            (d["asset_specific"]["loan_book"].get("collateral_summary") or {}).get("loans_below_init_count") or 0
            for d in (usdc, usdt)
        ),
        "principal_below_init_usd": round(sum(
            (d["asset_specific"]["loan_book"].get("collateral_summary") or {}).get("principal_below_init_usd") or 0
            for d in (usdc, usdt)
        ), 2),
        "shared_governance":        True,
    }

    # ------------------------------------------------------------------
    # Borrower overlap — borrowers present in BOTH pools.
    # ------------------------------------------------------------------
    usdc_by_b = loans_by_borrower(usdc)
    usdt_by_b = loans_by_borrower(usdt)
    all_borrowers = set(usdc_by_b.keys()) | set(usdt_by_b.keys())
    combined["unique_borrowers"] = len(all_borrowers)

    overlap = []
    for b in all_borrowers:
        if b not in usdc_by_b or b not in usdt_by_b:
            continue
        u_loans = usdc_by_b[b]
        t_loans = usdt_by_b[b]
        u_total = sum(l.get("principal") or 0 for l in u_loans)
        t_total = sum(l.get("principal") or 0 for l in t_loans)
        comb_total = u_total + t_total
        u_assets = {(l.get("collateral") or {}).get("asset") for l in u_loans
                    if (l.get("collateral") or {}).get("asset")}
        t_assets = {(l.get("collateral") or {}).get("asset") for l in t_loans
                    if (l.get("collateral") or {}).get("asset")}
        shared = sorted(u_assets & t_assets)
        overlap.append({
            "borrower_address":          b,
            "borrower_firm":             BORROWER_FIRM_MAP.get(b),
            "syrupusdc_loans":           [_loan_summary(l) for l in u_loans],
            "syrupusdt_loans":           [_loan_summary(l) for l in t_loans],
            "syrupusdc_total_usd":       round(u_total, 2),
            "syrupusdt_total_usd":       round(t_total, 2),
            "combined_total_usd":        round(comb_total, 2),
            "combined_pct_of_family":    round(comb_total / total_loans_usd * 100, 2)
                                            if total_loans_usd > 0 else None,
            "shared_collateral_assets":  shared,
        })
    overlap.sort(key=lambda x: -x["combined_total_usd"])

    # ------------------------------------------------------------------
    # By-collateral-asset combined view
    # ------------------------------------------------------------------
    by_asset = defaultdict(lambda: {"usdc_loans": 0, "usdc_p": 0.0,
                                    "usdt_loans": 0, "usdt_p": 0.0})
    for d, key in ((usdc, "usdc"), (usdt, "usdt")):
        for l in d["asset_specific"]["loan_book"]["loans"]:
            asset = (l.get("collateral") or {}).get("asset") or "?"
            by_asset[asset][f"{key}_loans"] += 1
            by_asset[asset][f"{key}_p"] += l.get("principal") or 0

    asset_combined = []
    for asset, info in by_asset.items():
        total_p = info["usdc_p"] + info["usdt_p"]
        asset_combined.append({
            "asset":                     asset,
            "syrupusdc_loans":           info["usdc_loans"],
            "syrupusdc_principal_usd":   round(info["usdc_p"], 2),
            "syrupusdt_loans":           info["usdt_loans"],
            "syrupusdt_principal_usd":   round(info["usdt_p"], 2),
            "combined_loans":            info["usdc_loans"] + info["usdt_loans"],
            "combined_principal_usd":    round(total_p, 2),
            "combined_pct_of_family":    round(total_p / total_loans_usd * 100, 2)
                                            if total_loans_usd > 0 else None,
        })
    asset_combined.sort(key=lambda x: -x["combined_principal_usd"])

    # ------------------------------------------------------------------
    # Cross-pool concentration — combined view (existing) + Loans-only view.
    # ------------------------------------------------------------------
    by_b_combined = defaultdict(float)
    by_b_loans_only = defaultdict(float)
    for d in (usdc, usdt):
        for l in d["asset_specific"]["loan_book"]["loans"]:
            b = l["borrower"].lower()
            p = l.get("principal") or 0
            by_b_combined[b] += p
            if l.get("position_type") == "loan":
                by_b_loans_only[b] += p

    cross_pool_concentration_combined = _build_cross_pool_concentration(
        by_b_combined, total_loans_usd
    )
    cross_pool_concentration_loans_only = _build_cross_pool_concentration(
        by_b_loans_only, aum_loans_usd
    )

    cross_pool_concentration_loans_only["denominator_basis"] = "sum of per-pool versioned classified_credit_principal"
    cross_pool_concentration_loans_only["members_by_pool"] = {
        slug: [l["loan_addr"] for l in d["asset_specific"]["loan_book"]["loans"] if l.get("position_type") == "loan"]
        for slug, d in (("syrupusdc", usdc), ("syrupusdt", usdt))}

    cross_pool_concentration_loans_only["excluded_by_pool"] = {
        slug: [l["loan_addr"] for l in d["asset_specific"]["loan_book"]["loans"] if l.get("position_type") != "loan"]
        for slug, d in (("syrupusdc", usdc), ("syrupusdt", usdt))}
    cross_pool_concentration_loans_only["classification_versions"] = combined["classification_versions"]

    # ------------------------------------------------------------------
    # Brand-wide custody topology — union the per-pool inventories.
    # ------------------------------------------------------------------
    brand_custody = _build_brand_wide_custody_topology(usdc, usdt, pools)

    out = {
        "schema_version": 1,
        "timestamp": now_iso(),
        "pools": pools,
        "combined": combined,
        "borrower_overlap": overlap,
        "by_collateral_asset_combined": asset_combined,
        "cross_pool_concentration_combined": cross_pool_concentration_combined,
        "cross_pool_concentration_loans_only": cross_pool_concentration_loans_only,
        "custody_topology": brand_custody,
        "shared_governance": {
            **SHARED_GOVERNANCE,
            "delegates_per_pool": {
                "syrupusdc": pools[0]["delegate_address"],
                "syrupusdt": pools[1]["delegate_address"],
            },
        },
        "data_source": "self_computed_from_per_pool_jsons",
    }

    tmp = OUTPUT + ".tmp"
    with open(tmp, "w") as f:
        json.dump(out, f, indent=2)
    os.replace(tmp, OUTPUT)

    # Console summary for cron logs
    print(f"  pools:              {pools[0]['name']} + {pools[1]['name']}")
    print(f"  aum_loans_usd:      ${combined['aum_loans_usd']/1e6:,.1f}M")
    print(f"  aum_liquidity_usd:  ${combined['aum_liquidity_usd']/1e6:,.1f}M")
    print(f"  aum_total_usd:      ${combined['aum_total_usd']/1e6:,.1f}M")
    cr = combined.get("collateral_ratio_loans_only_pct")
    print(f"  CR (loans-only):    {cr}%" if cr is not None else "  CR (loans-only):    n/a")
    print(f"  active_loan_count:  {combined['active_loan_count']} "
          f"({combined['loans_only_count']} loans + {combined['liquidity_count']} liquidity)")
    print(f"  unique_borrowers:   {combined['unique_borrowers']}")
    print(f"  borrower_overlap:   {len(overlap)} cross-pool borrowers")
    if overlap:
        top = overlap[0]
        print(f"    top: {top['borrower_address']} "
              f"${top['combined_total_usd']/1e6:.0f}M ({top['combined_pct_of_family']}% of family)")
    print(f"  custody_topology:   {brand_custody['single_key_eoa_count']} single-key EOAs, "
          f"${brand_custody['total_capital_under_eoa_control_usd']/1e6:,.1f}M under control")
    print(f"\nWrote {OUTPUT}")


if __name__ == "__main__":
    main()
